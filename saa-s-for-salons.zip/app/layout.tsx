import type React from "react"
import type { Metadata, Viewport } from "next"
import { Inter, Plus_Jakarta_Sans } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { AuthProvider } from "@/lib/auth-context"
import "./globals.css"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const plusJakarta = Plus_Jakarta_Sans({ subsets: ["latin"], variable: "--font-plus-jakarta" })

export const metadata: Metadata = {
  title: "EsthetiFlow | Sistema de Gestão para Clínicas e Salões",
  description:
    "A plataforma nº1 para clínicas de estética e salões de beleza. Agende, atenda, venda e cresça com o EsthetiFlow.",
  keywords: ["gestão de clínicas", "salão de beleza", "agendamento online", "estética", "software para salão"],
  authors: [{ name: "EsthetiFlow" }],
  creator: "EsthetiFlow",
  openGraph: {
    type: "website",
    locale: "pt_BR",
    url: "https://esthetiflow.com.br",
    title: "EsthetiFlow | Sistema de Gestão para Clínicas e Salões",
    description: "A plataforma nº1 para clínicas de estética e salões de beleza.",
    siteName: "EsthetiFlow",
  },
  twitter: {
    card: "summary_large_image",
    title: "EsthetiFlow | Sistema de Gestão para Clínicas e Salões",
    description: "A plataforma nº1 para clínicas de estética e salões de beleza.",
  },
    generator: 'v0.app'
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0a0a0a" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className="dark">
      <body className={`${inter.variable} ${plusJakarta.variable} font-sans antialiased`}>
        <AuthProvider>{children}</AuthProvider>
        <Analytics />
      </body>
    </html>
  )
}
