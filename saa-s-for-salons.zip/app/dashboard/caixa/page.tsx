"use client"

import { useState } from "react"
import { CaixaHeader } from "@/components/caixa/caixa-header"
import { CaixaSummary } from "@/components/caixa/caixa-summary"
import { PDVPanel } from "@/components/caixa/pdv-panel"
import { TransactionsList } from "@/components/caixa/transactions-list"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function CaixaPage() {
  const [activeTab, setActiveTab] = useState("pdv")

  return (
    <div className="space-y-6">
      <CaixaHeader />
      <CaixaSummary />

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-secondary/50 p-1">
          <TabsTrigger value="pdv">PDV - Nova Venda</TabsTrigger>
          <TabsTrigger value="transactions">Movimentações</TabsTrigger>
          <TabsTrigger value="closure">Fechamento</TabsTrigger>
        </TabsList>

        <TabsContent value="pdv" className="mt-6">
          <PDVPanel />
        </TabsContent>

        <TabsContent value="transactions" className="mt-6">
          <TransactionsList />
        </TabsContent>

        <TabsContent value="closure" className="mt-6">
          <CaixaClosure />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function CaixaClosure() {
  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <div className="space-y-4">
        <h3 className="font-semibold">Resumo do Dia</h3>
        <div className="space-y-3">
          {[
            { label: "Dinheiro", value: "R$ 1.250,00" },
            { label: "PIX", value: "R$ 3.890,00" },
            { label: "Cartão Crédito", value: "R$ 2.150,00" },
            { label: "Cartão Débito", value: "R$ 890,00" },
            { label: "Boleto", value: "R$ 450,00" },
          ].map((item, i) => (
            <div key={i} className="flex justify-between p-3 bg-secondary/30 rounded-lg">
              <span className="text-muted-foreground">{item.label}</span>
              <span className="font-medium">{item.value}</span>
            </div>
          ))}
          <div className="flex justify-between p-4 bg-primary/20 rounded-lg border border-primary/50">
            <span className="font-semibold">Total do Dia</span>
            <span className="font-bold text-primary text-xl">R$ 8.630,00</span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-semibold">Conferência de Caixa</h3>
        <div className="p-6 bg-card rounded-xl border border-border/50 space-y-4">
          <p className="text-sm text-muted-foreground">
            Informe o valor em dinheiro contado no caixa para conferência.
          </p>
          <input
            type="text"
            placeholder="R$ 0,00"
            className="w-full p-4 text-2xl font-bold text-center bg-secondary/30 rounded-lg border-0"
          />
          <div className="flex gap-3">
            <button className="flex-1 p-3 bg-secondary hover:bg-secondary/80 rounded-lg font-medium transition-colors">
              Sangria
            </button>
            <button className="flex-1 p-3 bg-secondary hover:bg-secondary/80 rounded-lg font-medium transition-colors">
              Suprimento
            </button>
          </div>
          <button className="w-full p-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-colors">
            Fechar Caixa
          </button>
        </div>
      </div>
    </div>
  )
}
