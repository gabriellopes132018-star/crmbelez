import { KPICards } from "@/components/dashboard/kpi-cards"
import { AppointmentsToday } from "@/components/dashboard/appointments-today"
import { RevenueChart } from "@/components/dashboard/revenue-chart"
import { RecentClients } from "@/components/dashboard/recent-clients"
import { TeamPerformance } from "@/components/dashboard/team-performance"
import { QuickActions } from "@/components/dashboard/quick-actions"
import { NotificationsPanel } from "@/components/dashboard/notifications-panel"

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Bem-vindo de volta! Aqui está o resumo do seu negócio.</p>
      </div>

      <KPICards />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <AppointmentsToday />
          <RevenueChart />
        </div>
        <div className="space-y-6">
          <QuickActions />
          <NotificationsPanel />
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <RecentClients />
        <TeamPerformance />
      </div>
    </div>
  )
}
