"use client"

import { useState } from "react"
import { CalendarHeader } from "@/components/agenda/calendar-header"
import { CalendarDayView } from "@/components/agenda/calendar-day-view"
import { CalendarWeekView } from "@/components/agenda/calendar-week-view"
import { CalendarMonthView } from "@/components/agenda/calendar-month-view"
import { AppointmentSidebar } from "@/components/agenda/appointment-sidebar"
import { NewAppointmentModal } from "@/components/agenda/new-appointment-modal"

export type ViewType = "day" | "week" | "month"

export default function AgendaPage() {
  const [view, setView] = useState<ViewType>("week")
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedAppointment, setSelectedAppointment] = useState<number | null>(null)
  const [isNewModalOpen, setIsNewModalOpen] = useState(false)

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col">
      <CalendarHeader
        view={view}
        setView={setView}
        currentDate={currentDate}
        setCurrentDate={setCurrentDate}
        onNewAppointment={() => setIsNewModalOpen(true)}
      />

      <div className="flex-1 flex overflow-hidden mt-4">
        <div className="flex-1 overflow-auto">
          {view === "day" && <CalendarDayView currentDate={currentDate} onSelectAppointment={setSelectedAppointment} />}
          {view === "week" && (
            <CalendarWeekView currentDate={currentDate} onSelectAppointment={setSelectedAppointment} />
          )}
          {view === "month" && (
            <CalendarMonthView
              currentDate={currentDate}
              setCurrentDate={setCurrentDate}
              onSelectAppointment={setSelectedAppointment}
            />
          )}
        </div>

        {selectedAppointment && (
          <AppointmentSidebar appointmentId={selectedAppointment} onClose={() => setSelectedAppointment(null)} />
        )}
      </div>

      <NewAppointmentModal open={isNewModalOpen} onClose={() => setIsNewModalOpen(false)} />
    </div>
  )
}
