"use client"

import { useState } from "react"
import { Plus, Search, Edit2, Trash2, Phone, Mail, MoreHorizontal, Calendar, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { useProfessionals, useServices, api } from "@/lib/hooks/use-api"
import { toast } from "sonner"

interface Professional {
  id: string
  name: string
  email: string
  phone: string
  role: string
  specialties: string[]
  services: string[]
  avatar?: string
  commission: number
  workingHours: {
    [key: string]: { start: string; end: string; active: boolean }
  }
  active: boolean
}

interface Service {
  id: string
  name: string
  category: string
}

const roles = ["Dermatologista", "Esteticista", "Técnica em Depilação", "Massoterapeuta", "Recepcionista", "Outro"]
const specialties = ["Facial", "Corporal", "Injetáveis", "Depilação", "Capilar", "Massagem"]
const daysOfWeek = [
  { key: "monday", label: "Segunda" },
  { key: "tuesday", label: "Terça" },
  { key: "wednesday", label: "Quarta" },
  { key: "thursday", label: "Quinta" },
  { key: "friday", label: "Sexta" },
  { key: "saturday", label: "Sábado" },
  { key: "sunday", label: "Domingo" },
]

export default function ProfissionaisPage() {
  const { data: professionals, isLoading, revalidate } = useProfessionals()
  const { data: services } = useServices()
  const [search, setSearch] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingProfessional, setEditingProfessional] = useState<Professional | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    role: "Esteticista",
    specialties: [] as string[],
    services: [] as string[],
    commission: 40,
    workingHours: {
      monday: { start: "09:00", end: "18:00", active: true },
      tuesday: { start: "09:00", end: "18:00", active: true },
      wednesday: { start: "09:00", end: "18:00", active: true },
      thursday: { start: "09:00", end: "18:00", active: true },
      friday: { start: "09:00", end: "18:00", active: true },
      saturday: { start: "09:00", end: "13:00", active: true },
      sunday: { start: "00:00", end: "00:00", active: false },
    },
    active: true,
  })

  const filteredProfessionals = ((professionals as Professional[]) || []).filter((professional: Professional) => {
    return (
      professional.name.toLowerCase().includes(search.toLowerCase()) ||
      professional.email.toLowerCase().includes(search.toLowerCase()) ||
      professional.role.toLowerCase().includes(search.toLowerCase())
    )
  })

  const handleOpenDialog = (professional?: Professional) => {
    if (professional) {
      setEditingProfessional(professional)
      setFormData({
        name: professional.name,
        email: professional.email,
        phone: professional.phone,
        role: professional.role,
        specialties: professional.specialties,
        services: professional.services,
        commission: professional.commission,
        workingHours: professional.workingHours,
        active: professional.active,
      })
    } else {
      setEditingProfessional(null)
      setFormData({
        name: "",
        email: "",
        phone: "",
        role: "Esteticista",
        specialties: [],
        services: [],
        commission: 40,
        workingHours: {
          monday: { start: "09:00", end: "18:00", active: true },
          tuesday: { start: "09:00", end: "18:00", active: true },
          wednesday: { start: "09:00", end: "18:00", active: true },
          thursday: { start: "09:00", end: "18:00", active: true },
          friday: { start: "09:00", end: "18:00", active: true },
          saturday: { start: "09:00", end: "13:00", active: true },
          sunday: { start: "00:00", end: "00:00", active: false },
        },
        active: true,
      })
    }
    setIsDialogOpen(true)
  }

  const handleSave = async () => {
    try {
      if (editingProfessional) {
        await api.updateProfessional(editingProfessional.id, formData)
        toast.success("Profissional atualizado com sucesso!")
      } else {
        await api.createProfessional(formData)
        toast.success("Profissional criado com sucesso!")
      }
      setIsDialogOpen(false)
      revalidate()
    } catch {
      toast.error("Erro ao salvar profissional")
    }
  }

  const handleDelete = async (id: string) => {
    if (confirm("Tem certeza que deseja excluir este profissional?")) {
      try {
        await api.deleteProfessional(id)
        toast.success("Profissional excluído com sucesso!")
        revalidate()
      } catch {
        toast.error("Erro ao excluir profissional")
      }
    }
  }

  const toggleSpecialty = (specialty: string) => {
    setFormData((prev) => ({
      ...prev,
      specialties: prev.specialties.includes(specialty)
        ? prev.specialties.filter((s) => s !== specialty)
        : [...prev.specialties, specialty],
    }))
  }

  const toggleService = (serviceId: string) => {
    setFormData((prev) => ({
      ...prev,
      services: prev.services.includes(serviceId)
        ? prev.services.filter((s) => s !== serviceId)
        : [...prev.services, serviceId],
    }))
  }

  const updateWorkingHour = (day: string, field: string, value: string | boolean) => {
    setFormData((prev) => ({
      ...prev,
      workingHours: {
        ...prev.workingHours,
        [day]: {
          ...prev.workingHours[day as keyof typeof prev.workingHours],
          [field]: value,
        },
      },
    }))
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Profissionais</h1>
          <p className="text-muted-foreground">Gerencie sua equipe de profissionais</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="mr-2 h-4 w-4" />
              Novo Profissional
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingProfessional ? "Editar Profissional" : "Novo Profissional"}</DialogTitle>
            </DialogHeader>
            <Tabs defaultValue="info" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="info">Informações</TabsTrigger>
                <TabsTrigger value="services">Serviços</TabsTrigger>
                <TabsTrigger value="schedule">Horários</TabsTrigger>
              </TabsList>
              <TabsContent value="info" className="space-y-4 mt-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Nome Completo</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ex: Dra. Camila Rocha"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="email">E-mail</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="email@exemplo.com"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="phone">Telefone</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="(11) 99999-9999"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="role">Função</Label>
                    <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {roles.map((role) => (
                          <SelectItem key={role} value={role}>
                            {role}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="commission">Comissão (%)</Label>
                    <Input
                      id="commission"
                      type="number"
                      value={formData.commission}
                      onChange={(e) => setFormData({ ...formData, commission: Number.parseInt(e.target.value) || 0 })}
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label>Especialidades</Label>
                  <div className="flex flex-wrap gap-2">
                    {specialties.map((specialty) => (
                      <Badge
                        key={specialty}
                        variant={formData.specialties.includes(specialty) ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => toggleSpecialty(specialty)}
                      >
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="active">Profissional Ativo</Label>
                  <Switch
                    id="active"
                    checked={formData.active}
                    onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                  />
                </div>
              </TabsContent>
              <TabsContent value="services" className="space-y-4 mt-4">
                <p className="text-sm text-muted-foreground">
                  Selecione os serviços que este profissional pode realizar:
                </p>
                <div className="grid gap-2 max-h-[300px] overflow-y-auto">
                  {((services as Service[]) || []).map((service: Service) => (
                    <div key={service.id} className="flex items-center space-x-2 p-2 rounded-lg hover:bg-muted">
                      <Checkbox
                        id={service.id}
                        checked={formData.services.includes(service.id)}
                        onCheckedChange={() => toggleService(service.id)}
                      />
                      <label htmlFor={service.id} className="flex-1 text-sm font-medium cursor-pointer">
                        {service.name}
                        <span className="ml-2 text-muted-foreground">({service.category})</span>
                      </label>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="schedule" className="space-y-4 mt-4">
                <p className="text-sm text-muted-foreground">Configure os horários de trabalho:</p>
                <div className="space-y-3">
                  {daysOfWeek.map((day) => (
                    <div key={day.key} className="flex items-center gap-4 p-2 rounded-lg hover:bg-muted">
                      <Switch
                        checked={formData.workingHours[day.key as keyof typeof formData.workingHours].active}
                        onCheckedChange={(checked) => updateWorkingHour(day.key, "active", checked)}
                      />
                      <span className="w-24 text-sm font-medium">{day.label}</span>
                      <Input
                        type="time"
                        value={formData.workingHours[day.key as keyof typeof formData.workingHours].start}
                        onChange={(e) => updateWorkingHour(day.key, "start", e.target.value)}
                        disabled={!formData.workingHours[day.key as keyof typeof formData.workingHours].active}
                        className="w-28"
                      />
                      <span className="text-muted-foreground">até</span>
                      <Input
                        type="time"
                        value={formData.workingHours[day.key as keyof typeof formData.workingHours].end}
                        onChange={(e) => updateWorkingHour(day.key, "end", e.target.value)}
                        disabled={!formData.workingHours[day.key as keyof typeof formData.workingHours].active}
                        className="w-28"
                      />
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
            <div className="flex justify-end gap-3 mt-4">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSave}>{editingProfessional ? "Salvar" : "Criar Profissional"}</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Buscar profissionais..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Professionals Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filteredProfessionals.map((professional: Professional) => (
          <Card key={professional.id} className={`relative ${!professional.active ? "opacity-60" : ""}`}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={professional.avatar || "/placeholder.svg"} />
                    <AvatarFallback className="bg-primary/10 text-primary text-lg">
                      {professional.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")
                        .slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold text-foreground">{professional.name}</h3>
                    <p className="text-sm text-muted-foreground">{professional.role}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                      <span className="text-sm font-medium">4.9</span>
                      <span className="text-sm text-muted-foreground">(128)</span>
                    </div>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleOpenDialog(professional)}>
                      <Edit2 className="mr-2 h-4 w-4" />
                      Editar
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleDelete(professional.id)} className="text-destructive">
                      <Trash2 className="mr-2 h-4 w-4" />
                      Excluir
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              <div className="mt-4 space-y-2">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="h-4 w-4" />
                  <span className="truncate">{professional.email}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="h-4 w-4" />
                  <span>{professional.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>Comissão: {professional.commission}%</span>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-1">
                {professional.specialties.map((specialty: string) => (
                  <Badge key={specialty} variant="secondary" className="text-xs">
                    {specialty}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredProfessionals.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Nenhum profissional encontrado</p>
        </div>
      )}
    </div>
  )
}
