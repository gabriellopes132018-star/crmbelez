"use client"

import { useState } from "react"
import { ClientsHeader } from "@/components/clientes/clients-header"
import { ClientsTable } from "@/components/clientes/clients-table"
import { ClientsFilters } from "@/components/clientes/clients-filters"
import { NewClientModal } from "@/components/clientes/new-client-modal"

export default function ClientesPage() {
  const [isNewModalOpen, setIsNewModalOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div className="space-y-6">
      <ClientsHeader onNewClient={() => setIsNewModalOpen(true)} />
      <ClientsFilters searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
      <ClientsTable searchQuery={searchQuery} />
      <NewClientModal open={isNewModalOpen} onClose={() => setIsNewModalOpen(false)} />
    </div>
  )
}
