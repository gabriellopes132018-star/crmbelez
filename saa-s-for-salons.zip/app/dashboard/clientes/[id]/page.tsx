import { ClientProfile } from "@/components/clientes/client-profile"
import { ClientTabs } from "@/components/clientes/client-tabs"

export default function ClientDetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="space-y-6">
      <ClientProfile clientId={params.id} />
      <ClientTabs clientId={params.id} />
    </div>
  )
}
