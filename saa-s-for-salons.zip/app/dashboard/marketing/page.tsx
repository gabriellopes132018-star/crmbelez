"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Megaphone,
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Send,
  Users,
  MessageSquare,
  Mail,
  Smartphone,
  TrendingUp,
  Target,
  Zap,
  Calendar,
  Eye,
  MousePointer,
  Play,
  Pause,
  Copy,
  Trash2,
  Edit,
  BarChart3,
} from "lucide-react"

// Dados de exemplo
const campaigns = [
  {
    id: 1,
    name: "Promoção Dia das Mães",
    status: "active",
    type: "whatsapp",
    sent: 1250,
    delivered: 1180,
    opened: 892,
    clicked: 234,
    conversions: 45,
    startDate: "2024-05-01",
    endDate: "2024-05-12",
  },
  {
    id: 2,
    name: "Reativação de Clientes",
    status: "active",
    type: "email",
    sent: 850,
    delivered: 820,
    opened: 456,
    clicked: 123,
    conversions: 28,
    startDate: "2024-05-05",
    endDate: "2024-05-20",
  },
  {
    id: 3,
    name: "Lançamento Botox",
    status: "scheduled",
    type: "sms",
    sent: 0,
    delivered: 0,
    opened: 0,
    clicked: 0,
    conversions: 0,
    startDate: "2024-05-15",
    endDate: "2024-05-30",
  },
  {
    id: 4,
    name: "Aniversariantes do Mês",
    status: "completed",
    type: "whatsapp",
    sent: 320,
    delivered: 315,
    opened: 298,
    clicked: 156,
    conversions: 67,
    startDate: "2024-04-01",
    endDate: "2024-04-30",
  },
]

const templates = [
  {
    id: 1,
    name: "Confirmação de Agendamento",
    type: "whatsapp",
    message: "Olá, {nome}! Sua reserva em {salão} está marcada para {data} às {hora}. Responda SIM para confirmar.",
    usageCount: 1542,
  },
  {
    id: 2,
    name: "Pós-Atendimento",
    type: "whatsapp",
    message: "Obrigado pela visita! Que nota você daria ao atendimento de hoje? ⭐ 1 a 5",
    usageCount: 890,
  },
  {
    id: 3,
    name: "Recuperação de Faltas",
    type: "whatsapp",
    message: "Sentimos sua falta! Quer reagendar seu horário em {salão}? Clique aqui → {link}",
    usageCount: 456,
  },
  {
    id: 4,
    name: "Promoção Especial",
    type: "email",
    message: "Aproveite 20% de desconto em todos os procedimentos faciais. Válido até {data}.",
    usageCount: 234,
  },
]

const automations = [
  {
    id: 1,
    name: "Lembrete 24h antes",
    trigger: "24h antes do agendamento",
    action: "Enviar WhatsApp de confirmação",
    status: "active",
    executions: 4521,
  },
  {
    id: 2,
    name: "Pós-atendimento",
    trigger: "30 min após atendimento",
    action: "Solicitar avaliação",
    status: "active",
    executions: 2340,
  },
  {
    id: 3,
    name: "Aniversário do cliente",
    trigger: "No dia do aniversário",
    action: "Enviar cupom de desconto",
    status: "active",
    executions: 567,
  },
  {
    id: 4,
    name: "Cliente inativo",
    trigger: "60 dias sem visita",
    action: "Enviar campanha de reativação",
    status: "paused",
    executions: 189,
  },
]

const statusConfig = {
  active: { label: "Ativa", color: "bg-green-500/10 text-green-500 border-green-500/20" },
  scheduled: { label: "Agendada", color: "bg-blue-500/10 text-blue-500 border-blue-500/20" },
  completed: { label: "Concluída", color: "bg-gray-500/10 text-gray-500 border-gray-500/20" },
  paused: { label: "Pausada", color: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20" },
}

const typeConfig = {
  whatsapp: { label: "WhatsApp", icon: MessageSquare, color: "text-green-500" },
  email: { label: "E-mail", icon: Mail, color: "text-blue-500" },
  sms: { label: "SMS", icon: Smartphone, color: "text-purple-500" },
}

export default function MarketingPage() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Marketing</h1>
          <p className="text-muted-foreground">Gerencie campanhas, automações e mensagens</p>
        </div>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Plus className="mr-2 h-4 w-4" />
          Nova Campanha
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-border/50 bg-card/50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Mensagens Enviadas</p>
                <p className="text-2xl font-bold">12.450</p>
                <p className="text-xs text-green-500 flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3" />
                  +18% este mês
                </p>
              </div>
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Send className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Taxa de Abertura</p>
                <p className="text-2xl font-bold">68.5%</p>
                <p className="text-xs text-green-500 flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3" />
                  +5% vs média
                </p>
              </div>
              <div className="h-12 w-12 rounded-full bg-blue-500/10 flex items-center justify-center">
                <Eye className="h-6 w-6 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Taxa de Clique</p>
                <p className="text-2xl font-bold">24.3%</p>
                <p className="text-xs text-green-500 flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3" />
                  +12% vs média
                </p>
              </div>
              <div className="h-12 w-12 rounded-full bg-purple-500/10 flex items-center justify-center">
                <MousePointer className="h-6 w-6 text-purple-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Conversões</p>
                <p className="text-2xl font-bold">340</p>
                <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">R$ 45.200 gerados</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-green-500/10 flex items-center justify-center">
                <Target className="h-6 w-6 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="campaigns" className="space-y-4">
        <TabsList className="bg-secondary/50">
          <TabsTrigger value="campaigns" className="gap-2">
            <Megaphone className="h-4 w-4" />
            Campanhas
          </TabsTrigger>
          <TabsTrigger value="automations" className="gap-2">
            <Zap className="h-4 w-4" />
            Automações
          </TabsTrigger>
          <TabsTrigger value="templates" className="gap-2">
            <MessageSquare className="h-4 w-4" />
            Templates
          </TabsTrigger>
        </TabsList>

        {/* Campanhas */}
        <TabsContent value="campaigns" className="space-y-4">
          {/* Filters */}
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Buscar campanhas..."
                className="pl-10 bg-secondary/50 border-border/50"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" size="sm" className="bg-secondary/50">
              <Filter className="mr-2 h-4 w-4" />
              Filtros
            </Button>
          </div>

          {/* Campaign List */}
          <div className="grid gap-4">
            {campaigns.map((campaign) => {
              const TypeIcon = typeConfig[campaign.type as keyof typeof typeConfig].icon
              const deliveryRate = campaign.sent > 0 ? (campaign.delivered / campaign.sent) * 100 : 0
              const openRate = campaign.delivered > 0 ? (campaign.opened / campaign.delivered) * 100 : 0
              const clickRate = campaign.opened > 0 ? (campaign.clicked / campaign.opened) * 100 : 0

              return (
                <Card key={campaign.id} className="border-border/50 bg-card/50">
                  <CardContent className="p-6">
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                      <div className="flex items-start gap-4">
                        <div className={`h-10 w-10 rounded-lg flex items-center justify-center bg-secondary`}>
                          <TypeIcon
                            className={`h-5 w-5 ${typeConfig[campaign.type as keyof typeof typeConfig].color}`}
                          />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold">{campaign.name}</h3>
                            <Badge
                              variant="outline"
                              className={statusConfig[campaign.status as keyof typeof statusConfig].color}
                            >
                              {statusConfig[campaign.status as keyof typeof statusConfig].label}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {campaign.startDate} - {campaign.endDate}
                            </span>
                            <span className="flex items-center gap-1">
                              <Users className="h-3 w-3" />
                              {campaign.sent.toLocaleString()} enviados
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Metrics */}
                      <div className="grid grid-cols-3 gap-6 lg:gap-8">
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground mb-1">Entrega</p>
                          <p className="text-lg font-semibold">{deliveryRate.toFixed(1)}%</p>
                          <Progress value={deliveryRate} className="h-1 mt-1" />
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground mb-1">Abertura</p>
                          <p className="text-lg font-semibold">{openRate.toFixed(1)}%</p>
                          <Progress value={openRate} className="h-1 mt-1" />
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground mb-1">Cliques</p>
                          <p className="text-lg font-semibold">{clickRate.toFixed(1)}%</p>
                          <Progress value={clickRate} className="h-1 mt-1" />
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm" className="bg-secondary/50">
                          <BarChart3 className="h-4 w-4" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Copy className="mr-2 h-4 w-4" />
                              Duplicar
                            </DropdownMenuItem>
                            {campaign.status === "active" ? (
                              <DropdownMenuItem>
                                <Pause className="mr-2 h-4 w-4" />
                                Pausar
                              </DropdownMenuItem>
                            ) : campaign.status === "paused" ? (
                              <DropdownMenuItem>
                                <Play className="mr-2 h-4 w-4" />
                                Retomar
                              </DropdownMenuItem>
                            ) : null}
                            <DropdownMenuItem className="text-destructive">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        {/* Automações */}
        <TabsContent value="automations" className="space-y-4">
          <div className="flex justify-end">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Plus className="mr-2 h-4 w-4" />
              Nova Automação
            </Button>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {automations.map((automation) => (
              <Card key={automation.id} className="border-border/50 bg-card/50">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Zap className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">{automation.name}</h3>
                          <Badge
                            variant="outline"
                            className={
                              automation.status === "active"
                                ? "bg-green-500/10 text-green-500 border-green-500/20"
                                : "bg-yellow-500/10 text-yellow-500 border-yellow-500/20"
                            }
                          >
                            {automation.status === "active" ? "Ativa" : "Pausada"}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          <span className="font-medium">Gatilho:</span> {automation.trigger}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          <span className="font-medium">Ação:</span> {automation.action}
                        </p>
                        <p className="text-xs text-muted-foreground mt-2">
                          {automation.executions.toLocaleString()} execuções
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className={automation.status === "active" ? "text-green-500" : "text-yellow-500"}
                    >
                      {automation.status === "active" ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Templates */}
        <TabsContent value="templates" className="space-y-4">
          <div className="flex justify-end">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Plus className="mr-2 h-4 w-4" />
              Novo Template
            </Button>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {templates.map((template) => {
              const TypeIcon = typeConfig[template.type as keyof typeof typeConfig]?.icon || MessageSquare

              return (
                <Card key={template.id} className="border-border/50 bg-card/50">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-lg bg-secondary flex items-center justify-center">
                          <TypeIcon
                            className={`h-5 w-5 ${typeConfig[template.type as keyof typeof typeConfig]?.color || "text-gray-500"}`}
                          />
                        </div>
                        <div>
                          <h3 className="font-semibold">{template.name}</h3>
                          <p className="text-xs text-muted-foreground">{template.usageCount} usos</p>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Copy className="mr-2 h-4 w-4" />
                            Duplicar
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">
                            <Trash2 className="mr-2 h-4 w-4" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <div className="p-3 rounded-lg bg-secondary/50 text-sm text-muted-foreground">
                      {template.message}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
