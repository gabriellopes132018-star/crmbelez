import { type NextRequest, NextResponse } from "next/server"

const services = [
  {
    id: "s1",
    name: "Limpeza de Pele Profunda",
    description: "Limpeza completa com extração, peeling e máscara hidratante",
    category: "Facial",
    duration: 90,
    price: 180,
    commission: 40,
    active: true,
    color: "#10b981",
    createdAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "s2",
    name: "Botox",
    description: "Aplicação de toxina botulínica para redução de rugas",
    category: "Injetáveis",
    duration: 30,
    price: 1200,
    commission: 35,
    active: true,
    color: "#8b5cf6",
    createdAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "s3",
    name: "Preenchimento Labial",
    description: "Preenchimento com ácido hialurônico para volumização dos lábios",
    category: "Injetáveis",
    duration: 45,
    price: 1500,
    commission: 35,
    active: true,
    color: "#ec4899",
    createdAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "s4",
    name: "Drenagem Linfática",
    description: "Massagem especializada para redução de inchaço e retenção de líquidos",
    category: "Corporal",
    duration: 60,
    price: 150,
    commission: 45,
    active: true,
    color: "#06b6d4",
    createdAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "s5",
    name: "Microagulhamento",
    description: "Tratamento para estímulo de colágeno e renovação celular",
    category: "Facial",
    duration: 60,
    price: 350,
    commission: 40,
    active: true,
    color: "#f59e0b",
    createdAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "s6",
    name: "Depilação a Laser - Axilas",
    description: "Depilação definitiva com tecnologia laser de diodo",
    category: "Depilação",
    duration: 15,
    price: 120,
    commission: 30,
    active: true,
    color: "#ef4444",
    createdAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "s7",
    name: "Peeling Químico",
    description: "Tratamento para renovação da pele com ácidos",
    category: "Facial",
    duration: 45,
    price: 280,
    commission: 40,
    active: true,
    color: "#84cc16",
    createdAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "s8",
    name: "Massagem Relaxante",
    description: "Massagem corporal para alívio de tensões",
    category: "Corporal",
    duration: 60,
    price: 180,
    commission: 45,
    active: true,
    color: "#6366f1",
    createdAt: "2024-01-01T00:00:00.000Z",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const active = searchParams.get("active")

    let filteredServices = [...services]

    if (category) {
      filteredServices = filteredServices.filter((s) => s.category === category)
    }

    if (active !== null) {
      filteredServices = filteredServices.filter((s) => s.active === (active === "true"))
    }

    return NextResponse.json({
      success: true,
      data: filteredServices,
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao buscar serviços" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const newService = {
      id: `s${Date.now()}`,
      ...body,
      active: true,
      createdAt: new Date().toISOString(),
    }

    services.push(newService)

    return NextResponse.json(
      {
        success: true,
        data: newService,
      },
      { status: 201 },
    )
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao criar serviço" }, { status: 500 })
  }
}
