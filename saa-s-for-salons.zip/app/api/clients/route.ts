import { type NextRequest, NextResponse } from "next/server"

// Dados em memória para a API (simulando banco de dados)
const clients = [
  {
    id: "c1",
    name: "Maria Silva",
    email: "maria@email.com",
    phone: "(11) 98765-4321",
    cpf: "123.456.789-00",
    birthDate: "1990-05-15",
    gender: "F",
    tags: ["VIP", "Frequente"],
    loyaltyPoints: 850,
    totalSpent: 4250,
    lastVisit: "2024-11-25",
    createdAt: "2024-01-15T00:00:00.000Z",
    updatedAt: "2024-11-25T00:00:00.000Z",
  },
  {
    id: "c2",
    name: "Ana Costa",
    email: "ana@email.com",
    phone: "(11) 91234-5678",
    gender: "F",
    tags: ["Nova"],
    loyaltyPoints: 150,
    totalSpent: 750,
    lastVisit: "2024-11-20",
    createdAt: "2024-10-01T00:00:00.000Z",
    updatedAt: "2024-11-20T00:00:00.000Z",
  },
  {
    id: "c3",
    name: "Juliana Santos",
    email: "juliana@email.com",
    phone: "(11) 94567-8901",
    gender: "F",
    tags: ["Frequente"],
    loyaltyPoints: 620,
    totalSpent: 3100,
    lastVisit: "2024-11-28",
    createdAt: "2024-03-10T00:00:00.000Z",
    updatedAt: "2024-11-28T00:00:00.000Z",
  },
  {
    id: "c4",
    name: "Fernanda Lima",
    email: "fernanda@email.com",
    phone: "(11) 92345-6789",
    gender: "F",
    tags: ["VIP"],
    loyaltyPoints: 1200,
    totalSpent: 6000,
    lastVisit: "2024-11-27",
    createdAt: "2023-08-20T00:00:00.000Z",
    updatedAt: "2024-11-27T00:00:00.000Z",
  },
  {
    id: "c5",
    name: "Carla Oliveira",
    email: "carla@email.com",
    phone: "(11) 93456-7890",
    gender: "F",
    tags: [],
    loyaltyPoints: 280,
    totalSpent: 1400,
    lastVisit: "2024-11-15",
    createdAt: "2024-06-05T00:00:00.000Z",
    updatedAt: "2024-11-15T00:00:00.000Z",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")?.toLowerCase()
    const tag = searchParams.get("tag")
    const limit = Number.parseInt(searchParams.get("limit") || "100")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    let filteredClients = [...clients]

    if (search) {
      filteredClients = filteredClients.filter(
        (c) =>
          c.name.toLowerCase().includes(search) || c.email.toLowerCase().includes(search) || c.phone.includes(search),
      )
    }

    if (tag) {
      filteredClients = filteredClients.filter((c) => c.tags.includes(tag))
    }

    const total = filteredClients.length
    const paginatedClients = filteredClients.slice(offset, offset + limit)

    return NextResponse.json({
      success: true,
      data: paginatedClients,
      pagination: { total, limit, offset },
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao buscar clientes" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const newClient = {
      id: `c${Date.now()}`,
      ...body,
      tags: body.tags || [],
      loyaltyPoints: 0,
      totalSpent: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    clients.push(newClient)

    return NextResponse.json(
      {
        success: true,
        data: newClient,
      },
      { status: 201 },
    )
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao criar cliente" }, { status: 500 })
  }
}
