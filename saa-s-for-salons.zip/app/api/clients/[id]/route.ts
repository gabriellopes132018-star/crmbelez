import { type NextRequest, NextResponse } from "next/server"

// Dados em memória (compartilhados com a rota principal)
let clients = [
  {
    id: "c1",
    name: "Maria Silva",
    email: "maria@email.com",
    phone: "(11) 98765-4321",
    cpf: "123.456.789-00",
    birthDate: "1990-05-15",
    gender: "F",
    tags: ["VIP", "Frequente"],
    loyaltyPoints: 850,
    totalSpent: 4250,
    lastVisit: "2024-11-25",
    createdAt: "2024-01-15T00:00:00.000Z",
    updatedAt: "2024-11-25T00:00:00.000Z",
  },
  {
    id: "c2",
    name: "Ana Costa",
    email: "ana@email.com",
    phone: "(11) 91234-5678",
    gender: "F",
    tags: ["Nova"],
    loyaltyPoints: 150,
    totalSpent: 750,
    lastVisit: "2024-11-20",
    createdAt: "2024-10-01T00:00:00.000Z",
    updatedAt: "2024-11-20T00:00:00.000Z",
  },
  {
    id: "c3",
    name: "Juliana Santos",
    email: "juliana@email.com",
    phone: "(11) 94567-8901",
    gender: "F",
    tags: ["Frequente"],
    loyaltyPoints: 620,
    totalSpent: 3100,
    lastVisit: "2024-11-28",
    createdAt: "2024-03-10T00:00:00.000Z",
    updatedAt: "2024-11-28T00:00:00.000Z",
  },
  {
    id: "c4",
    name: "Fernanda Lima",
    email: "fernanda@email.com",
    phone: "(11) 92345-6789",
    gender: "F",
    tags: ["VIP"],
    loyaltyPoints: 1200,
    totalSpent: 6000,
    lastVisit: "2024-11-27",
    createdAt: "2023-08-20T00:00:00.000Z",
    updatedAt: "2024-11-27T00:00:00.000Z",
  },
  {
    id: "c5",
    name: "Carla Oliveira",
    email: "carla@email.com",
    phone: "(11) 93456-7890",
    gender: "F",
    tags: [],
    loyaltyPoints: 280,
    totalSpent: 1400,
    lastVisit: "2024-11-15",
    createdAt: "2024-06-05T00:00:00.000Z",
    updatedAt: "2024-11-15T00:00:00.000Z",
  },
]

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const client = clients.find((c) => c.id === id)

    if (!client) {
      return NextResponse.json({ success: false, error: "Cliente não encontrado" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      data: client,
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao buscar cliente" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()
    const index = clients.findIndex((c) => c.id === id)

    if (index === -1) {
      return NextResponse.json({ success: false, error: "Cliente não encontrado" }, { status: 404 })
    }

    clients[index] = {
      ...clients[index],
      ...body,
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      data: clients[index],
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao atualizar cliente" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const index = clients.findIndex((c) => c.id === id)

    if (index === -1) {
      return NextResponse.json({ success: false, error: "Cliente não encontrado" }, { status: 404 })
    }

    clients = clients.filter((c) => c.id !== id)

    return NextResponse.json({
      success: true,
      message: "Cliente removido com sucesso",
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao remover cliente" }, { status: 500 })
  }
}
