import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Estatísticas simuladas do dashboard
    const stats = {
      todayAppointments: 8,
      completedAppointments: 5,
      todayRevenue: 3180,
      monthRevenue: 47850,
      totalClients: 234,
      newClientsMonth: 18,
      occupancyRate: 78,
      averageTicket: 425,
      topServices: [
        { name: "Botox", count: 45, revenue: 54000 },
        { name: "Limpeza de Pele", count: 38, revenue: 6840 },
        { name: "Preenchimento", count: 22, revenue: 33000 },
        { name: "Drenagem", count: 52, revenue: 7800 },
      ],
      revenueByDay: [
        { day: "Seg", value: 4200 },
        { day: "Ter", value: 5800 },
        { day: "Qua", value: 4500 },
        { day: "Qui", value: 6200 },
        { day: "Sex", value: 7100 },
        { day: "Sáb", value: 8500 },
        { day: "Dom", value: 0 },
      ],
    }

    return NextResponse.json({
      success: true,
      data: stats,
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao buscar estatísticas" }, { status: 500 })
  }
}
