import { type NextRequest, NextResponse } from "next/server"

const products = [
  {
    id: "prod1",
    name: "Protetor Solar FPS 50",
    description: "Protetor solar facial com alta proteção UVA/UVB",
    category: "Cuidados com a Pele",
    brand: "La Roche-Posay",
    sku: "LRP-PS50-001",
    barcode: "7891234567890",
    costPrice: 65,
    salePrice: 120,
    stock: 25,
    minStock: 10,
    unit: "un",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "prod2",
    name: "Sérum Vitamina C",
    description: "Sérum antioxidante com 15% de vitamina C pura",
    category: "Tratamento",
    brand: "Skinceuticals",
    sku: "SKC-VC15-001",
    costPrice: 180,
    salePrice: 350,
    stock: 12,
    minStock: 5,
    unit: "un",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "prod3",
    name: "Ácido Hialurônico 1ml",
    description: "Preenchedor dérmico para procedimentos estéticos",
    category: "Injetáveis",
    brand: "Juvederm",
    sku: "JUV-AH1-001",
    costPrice: 450,
    salePrice: 800,
    stock: 8,
    minStock: 3,
    unit: "seringa",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "prod4",
    name: "Toxina Botulínica 50U",
    description: "Botox para procedimentos estéticos faciais",
    category: "Injetáveis",
    brand: "Botox",
    sku: "BTX-50U-001",
    costPrice: 380,
    salePrice: 650,
    stock: 15,
    minStock: 5,
    unit: "frasco",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "prod5",
    name: "Hidratante Facial",
    description: "Creme hidratante para pele sensível",
    category: "Cuidados com a Pele",
    brand: "Bioderma",
    sku: "BIO-HF-001",
    costPrice: 45,
    salePrice: 89,
    stock: 30,
    minStock: 15,
    unit: "un",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "prod6",
    name: "Óleo Corporal",
    description: "Óleo nutritivo para massagem e hidratação corporal",
    category: "Corporal",
    brand: "Nuxe",
    sku: "NUX-OC-001",
    costPrice: 85,
    salePrice: 165,
    stock: 18,
    minStock: 8,
    unit: "un",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const search = searchParams.get("search")?.toLowerCase()
    const lowStock = searchParams.get("lowStock") === "true"

    let filteredProducts = [...products]

    if (category) {
      filteredProducts = filteredProducts.filter((p) => p.category === category)
    }

    if (search) {
      filteredProducts = filteredProducts.filter(
        (p) =>
          p.name.toLowerCase().includes(search) ||
          p.sku.toLowerCase().includes(search) ||
          p.brand.toLowerCase().includes(search),
      )
    }

    if (lowStock) {
      filteredProducts = filteredProducts.filter((p) => p.stock <= p.minStock)
    }

    return NextResponse.json({
      success: true,
      data: filteredProducts,
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao buscar produtos" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const newProduct = {
      id: `prod${Date.now()}`,
      ...body,
      active: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    products.push(newProduct)

    return NextResponse.json(
      {
        success: true,
        data: newProduct,
      },
      { status: 201 },
    )
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao criar produto" }, { status: 500 })
  }
}
