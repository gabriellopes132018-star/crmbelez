import { type NextRequest, NextResponse } from "next/server"

let products = [
  {
    id: "prod1",
    name: "Protetor Solar FPS 50",
    description: "Protetor solar facial com alta proteção UVA/UVB",
    category: "Cuidados com a Pele",
    brand: "La Roche-Posay",
    sku: "LRP-PS50-001",
    barcode: "7891234567890",
    costPrice: 65,
    salePrice: 120,
    stock: 25,
    minStock: 10,
    unit: "un",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "prod2",
    name: "Sérum Vitamina C",
    description: "Sérum antioxidante com 15% de vitamina C pura",
    category: "Tratamento",
    brand: "Skinceuticals",
    sku: "SKC-VC15-001",
    costPrice: 180,
    salePrice: 350,
    stock: 12,
    minStock: 5,
    unit: "un",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "prod3",
    name: "Ácido Hialurônico 1ml",
    description: "Preenchedor dérmico para procedimentos estéticos",
    category: "Injetáveis",
    brand: "Juvederm",
    sku: "JUV-AH1-001",
    costPrice: 450,
    salePrice: 800,
    stock: 8,
    minStock: 3,
    unit: "seringa",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "prod4",
    name: "Toxina Botulínica 50U",
    description: "Botox para procedimentos estéticos faciais",
    category: "Injetáveis",
    brand: "Botox",
    sku: "BTX-50U-001",
    costPrice: 380,
    salePrice: 650,
    stock: 15,
    minStock: 5,
    unit: "frasco",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "prod5",
    name: "Hidratante Facial",
    description: "Creme hidratante para pele sensível",
    category: "Cuidados com a Pele",
    brand: "Bioderma",
    sku: "BIO-HF-001",
    costPrice: 45,
    salePrice: 89,
    stock: 30,
    minStock: 15,
    unit: "un",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "prod6",
    name: "Óleo Corporal",
    description: "Óleo nutritivo para massagem e hidratação corporal",
    category: "Corporal",
    brand: "Nuxe",
    sku: "NUX-OC-001",
    costPrice: 85,
    salePrice: 165,
    stock: 18,
    minStock: 8,
    unit: "un",
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
]

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const product = products.find((p) => p.id === id)

    if (!product) {
      return NextResponse.json({ success: false, error: "Produto não encontrado" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      data: product,
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao buscar produto" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()
    const index = products.findIndex((p) => p.id === id)

    if (index === -1) {
      return NextResponse.json({ success: false, error: "Produto não encontrado" }, { status: 404 })
    }

    products[index] = {
      ...products[index],
      ...body,
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      data: products[index],
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao atualizar produto" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const index = products.findIndex((p) => p.id === id)

    if (index === -1) {
      return NextResponse.json({ success: false, error: "Produto não encontrado" }, { status: 404 })
    }

    products = products.filter((p) => p.id !== id)

    return NextResponse.json({
      success: true,
      message: "Produto removido com sucesso",
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao remover produto" }, { status: 500 })
  }
}
