import { type NextRequest, NextResponse } from "next/server"

const today = new Date().toISOString().split("T")[0]
const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0]

const transactions = [
  {
    id: "t1",
    type: "income",
    category: "Serviços",
    description: "Botox - Maria Silva",
    amount: 1200,
    paymentMethod: "credit",
    status: "completed",
    clientId: "c1",
    clientName: "Maria Silva",
    professionalId: "p1",
    date: today,
    createdAt: today,
  },
  {
    id: "t2",
    type: "income",
    category: "Serviços",
    description: "Limpeza de Pele - Ana Costa",
    amount: 180,
    paymentMethod: "pix",
    status: "completed",
    clientId: "c2",
    clientName: "Ana Costa",
    professionalId: "p2",
    date: today,
    createdAt: today,
  },
  {
    id: "t3",
    type: "income",
    category: "Produtos",
    description: "Protetor Solar - Juliana Santos",
    amount: 120,
    paymentMethod: "debit",
    status: "completed",
    clientId: "c3",
    clientName: "Juliana Santos",
    date: yesterday,
    createdAt: yesterday,
  },
  {
    id: "t4",
    type: "expense",
    category: "Fornecedores",
    description: "Compra de produtos - Distribuidora XYZ",
    amount: 2500,
    paymentMethod: "transfer",
    status: "completed",
    date: yesterday,
    createdAt: yesterday,
  },
  {
    id: "t5",
    type: "expense",
    category: "Operacional",
    description: "Conta de luz",
    amount: 450,
    paymentMethod: "boleto",
    status: "pending",
    date: today,
    dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split("T")[0],
    createdAt: today,
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type")
    const status = searchParams.get("status")
    const startDate = searchParams.get("startDate")
    const endDate = searchParams.get("endDate")

    let filteredTransactions = [...transactions]

    if (type) {
      filteredTransactions = filteredTransactions.filter((t) => t.type === type)
    }

    if (status) {
      filteredTransactions = filteredTransactions.filter((t) => t.status === status)
    }

    if (startDate) {
      filteredTransactions = filteredTransactions.filter((t) => t.date >= startDate)
    }

    if (endDate) {
      filteredTransactions = filteredTransactions.filter((t) => t.date <= endDate)
    }

    return NextResponse.json({
      success: true,
      data: filteredTransactions,
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao buscar transações" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const newTransaction = {
      id: `t${Date.now()}`,
      ...body,
      createdAt: new Date().toISOString(),
    }

    transactions.push(newTransaction)

    return NextResponse.json(
      {
        success: true,
        data: newTransaction,
      },
      { status: 201 },
    )
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao criar transação" }, { status: 500 })
  }
}
