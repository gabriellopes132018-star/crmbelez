import { type NextRequest, NextResponse } from "next/server"

let professionals = [
  {
    id: "p1",
    name: "Dra. Camila Rocha",
    email: "camila@esthetiflow.com.br",
    phone: "(11) 97777-7777",
    role: "Dermatologista",
    specialties: ["Injetáveis", "Facial"],
    services: ["s2", "s3", "s5", "s7"],
    avatar: "/professional-woman-doctor.png",
    commission: 35,
    workingHours: {
      monday: { start: "09:00", end: "18:00", active: true },
      tuesday: { start: "09:00", end: "18:00", active: true },
      wednesday: { start: "09:00", end: "18:00", active: true },
      thursday: { start: "09:00", end: "18:00", active: true },
      friday: { start: "09:00", end: "17:00", active: true },
      saturday: { start: "09:00", end: "13:00", active: true },
      sunday: { start: "00:00", end: "00:00", active: false },
    },
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "p2",
    name: "Beatriz Mendes",
    email: "beatriz@esthetiflow.com.br",
    phone: "(11) 96666-6666",
    role: "Esteticista",
    specialties: ["Facial", "Corporal"],
    services: ["s1", "s4", "s8"],
    avatar: "/professional-woman-aesthetician.jpg",
    commission: 45,
    workingHours: {
      monday: { start: "08:00", end: "17:00", active: true },
      tuesday: { start: "08:00", end: "17:00", active: true },
      wednesday: { start: "08:00", end: "17:00", active: true },
      thursday: { start: "08:00", end: "17:00", active: true },
      friday: { start: "08:00", end: "16:00", active: true },
      saturday: { start: "08:00", end: "12:00", active: true },
      sunday: { start: "00:00", end: "00:00", active: false },
    },
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "p3",
    name: "Larissa Campos",
    email: "larissa@esthetiflow.com.br",
    phone: "(11) 95555-5555",
    role: "Técnica em Depilação",
    specialties: ["Depilação"],
    services: ["s6"],
    avatar: "/professional-woman-technician.jpg",
    commission: 30,
    workingHours: {
      monday: { start: "10:00", end: "19:00", active: true },
      tuesday: { start: "10:00", end: "19:00", active: true },
      wednesday: { start: "10:00", end: "19:00", active: true },
      thursday: { start: "10:00", end: "19:00", active: true },
      friday: { start: "10:00", end: "18:00", active: true },
      saturday: { start: "09:00", end: "14:00", active: true },
      sunday: { start: "00:00", end: "00:00", active: false },
    },
    active: true,
    createdAt: "2024-01-01T00:00:00.000Z",
  },
]

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const professional = professionals.find((p) => p.id === id)

    if (!professional) {
      return NextResponse.json({ success: false, error: "Profissional não encontrado" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      data: professional,
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao buscar profissional" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()
    const index = professionals.findIndex((p) => p.id === id)

    if (index === -1) {
      return NextResponse.json({ success: false, error: "Profissional não encontrado" }, { status: 404 })
    }

    professionals[index] = {
      ...professionals[index],
      ...body,
    }

    return NextResponse.json({
      success: true,
      data: professionals[index],
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao atualizar profissional" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const index = professionals.findIndex((p) => p.id === id)

    if (index === -1) {
      return NextResponse.json({ success: false, error: "Profissional não encontrado" }, { status: 404 })
    }

    professionals = professionals.filter((p) => p.id !== id)

    return NextResponse.json({
      success: true,
      message: "Profissional removido com sucesso",
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao remover profissional" }, { status: 500 })
  }
}
