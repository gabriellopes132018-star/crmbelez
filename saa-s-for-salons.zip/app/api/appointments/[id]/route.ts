import { type NextRequest, NextResponse } from "next/server"

const today = new Date().toISOString().split("T")[0]
const tomorrow = new Date(Date.now() + 86400000).toISOString().split("T")[0]

let appointments = [
  {
    id: "a1",
    clientId: "c1",
    clientName: "Maria Silva",
    professionalId: "p1",
    professionalName: "Dra. Camila Rocha",
    serviceId: "s2",
    serviceName: "Botox",
    date: today,
    startTime: "09:00",
    endTime: "09:30",
    duration: 30,
    price: 1200,
    status: "confirmed",
    createdAt: "2024-11-20T00:00:00.000Z",
    updatedAt: "2024-11-20T00:00:00.000Z",
  },
  {
    id: "a2",
    clientId: "c2",
    clientName: "Ana Costa",
    professionalId: "p2",
    professionalName: "Beatriz Mendes",
    serviceId: "s1",
    serviceName: "Limpeza de Pele Profunda",
    date: today,
    startTime: "10:00",
    endTime: "11:30",
    duration: 90,
    price: 180,
    status: "scheduled",
    createdAt: "2024-11-21T00:00:00.000Z",
    updatedAt: "2024-11-21T00:00:00.000Z",
  },
  {
    id: "a3",
    clientId: "c3",
    clientName: "Juliana Santos",
    professionalId: "p1",
    professionalName: "Dra. Camila Rocha",
    serviceId: "s3",
    serviceName: "Preenchimento Labial",
    date: today,
    startTime: "14:00",
    endTime: "14:45",
    duration: 45,
    price: 1500,
    status: "confirmed",
    createdAt: "2024-11-22T00:00:00.000Z",
    updatedAt: "2024-11-22T00:00:00.000Z",
  },
  {
    id: "a4",
    clientId: "c4",
    clientName: "Fernanda Lima",
    professionalId: "p2",
    professionalName: "Beatriz Mendes",
    serviceId: "s4",
    serviceName: "Drenagem Linfática",
    date: today,
    startTime: "15:00",
    endTime: "16:00",
    duration: 60,
    price: 150,
    status: "scheduled",
    createdAt: "2024-11-23T00:00:00.000Z",
    updatedAt: "2024-11-23T00:00:00.000Z",
  },
  {
    id: "a5",
    clientId: "c5",
    clientName: "Carla Oliveira",
    professionalId: "p3",
    professionalName: "Larissa Campos",
    serviceId: "s6",
    serviceName: "Depilação a Laser - Axilas",
    date: tomorrow,
    startTime: "10:00",
    endTime: "10:15",
    duration: 15,
    price: 120,
    status: "scheduled",
    createdAt: "2024-11-24T00:00:00.000Z",
    updatedAt: "2024-11-24T00:00:00.000Z",
  },
]

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const appointment = appointments.find((a) => a.id === id)

    if (!appointment) {
      return NextResponse.json({ success: false, error: "Agendamento não encontrado" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      data: appointment,
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao buscar agendamento" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()
    const index = appointments.findIndex((a) => a.id === id)

    if (index === -1) {
      return NextResponse.json({ success: false, error: "Agendamento não encontrado" }, { status: 404 })
    }

    appointments[index] = {
      ...appointments[index],
      ...body,
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      data: appointments[index],
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao atualizar agendamento" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const index = appointments.findIndex((a) => a.id === id)

    if (index === -1) {
      return NextResponse.json({ success: false, error: "Agendamento não encontrado" }, { status: 404 })
    }

    appointments = appointments.filter((a) => a.id !== id)

    return NextResponse.json({
      success: true,
      message: "Agendamento removido com sucesso",
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao remover agendamento" }, { status: 500 })
  }
}
