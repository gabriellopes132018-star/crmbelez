import { type NextRequest, NextResponse } from "next/server"

const today = new Date().toISOString().split("T")[0]
const tomorrow = new Date(Date.now() + 86400000).toISOString().split("T")[0]

const appointments = [
  {
    id: "a1",
    clientId: "c1",
    clientName: "Maria Silva",
    professionalId: "p1",
    professionalName: "Dra. Camila Rocha",
    serviceId: "s2",
    serviceName: "Botox",
    date: today,
    startTime: "09:00",
    endTime: "09:30",
    duration: 30,
    price: 1200,
    status: "confirmed",
    createdAt: "2024-11-20T00:00:00.000Z",
    updatedAt: "2024-11-20T00:00:00.000Z",
  },
  {
    id: "a2",
    clientId: "c2",
    clientName: "Ana Costa",
    professionalId: "p2",
    professionalName: "Beatriz Mendes",
    serviceId: "s1",
    serviceName: "Limpeza de Pele Profunda",
    date: today,
    startTime: "10:00",
    endTime: "11:30",
    duration: 90,
    price: 180,
    status: "scheduled",
    createdAt: "2024-11-21T00:00:00.000Z",
    updatedAt: "2024-11-21T00:00:00.000Z",
  },
  {
    id: "a3",
    clientId: "c3",
    clientName: "Juliana Santos",
    professionalId: "p1",
    professionalName: "Dra. Camila Rocha",
    serviceId: "s3",
    serviceName: "Preenchimento Labial",
    date: today,
    startTime: "14:00",
    endTime: "14:45",
    duration: 45,
    price: 1500,
    status: "confirmed",
    createdAt: "2024-11-22T00:00:00.000Z",
    updatedAt: "2024-11-22T00:00:00.000Z",
  },
  {
    id: "a4",
    clientId: "c4",
    clientName: "Fernanda Lima",
    professionalId: "p2",
    professionalName: "Beatriz Mendes",
    serviceId: "s4",
    serviceName: "Drenagem Linfática",
    date: today,
    startTime: "15:00",
    endTime: "16:00",
    duration: 60,
    price: 150,
    status: "scheduled",
    createdAt: "2024-11-23T00:00:00.000Z",
    updatedAt: "2024-11-23T00:00:00.000Z",
  },
  {
    id: "a5",
    clientId: "c5",
    clientName: "Carla Oliveira",
    professionalId: "p3",
    professionalName: "Larissa Campos",
    serviceId: "s6",
    serviceName: "Depilação a Laser - Axilas",
    date: tomorrow,
    startTime: "10:00",
    endTime: "10:15",
    duration: 15,
    price: 120,
    status: "scheduled",
    createdAt: "2024-11-24T00:00:00.000Z",
    updatedAt: "2024-11-24T00:00:00.000Z",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const date = searchParams.get("date")
    const professionalId = searchParams.get("professionalId")
    const clientId = searchParams.get("clientId")
    const status = searchParams.get("status")

    let filteredAppointments = [...appointments]

    if (date) {
      filteredAppointments = filteredAppointments.filter((a) => a.date === date)
    }

    if (professionalId) {
      filteredAppointments = filteredAppointments.filter((a) => a.professionalId === professionalId)
    }

    if (clientId) {
      filteredAppointments = filteredAppointments.filter((a) => a.clientId === clientId)
    }

    if (status) {
      filteredAppointments = filteredAppointments.filter((a) => a.status === status)
    }

    return NextResponse.json({
      success: true,
      data: filteredAppointments,
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao buscar agendamentos" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const newAppointment = {
      id: `a${Date.now()}`,
      ...body,
      status: body.status || "scheduled",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    appointments.push(newAppointment)

    return NextResponse.json(
      {
        success: true,
        data: newAppointment,
      },
      { status: 201 },
    )
  } catch {
    return NextResponse.json({ success: false, error: "Erro ao criar agendamento" }, { status: 500 })
  }
}
