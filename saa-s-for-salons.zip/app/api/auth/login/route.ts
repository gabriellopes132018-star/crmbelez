import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    // Simular validação de credenciais
    // Em produção, isso seria verificado em um banco de dados real
    if (email === "demo@esthetiflow.com.br" && password === "demo123") {
      return NextResponse.json({
        success: true,
        user: {
          id: "1",
          email: "demo@esthetiflow.com.br",
          name: "Admin Demo",
          role: "admin",
          avatar: "/admin-avatar.png",
        },
        token: `token_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      })
    }

    return NextResponse.json({ success: false, error: "Credenciais inválidas" }, { status: 401 })
  } catch {
    return NextResponse.json({ success: false, error: "Erro interno do servidor" }, { status: 500 })
  }
}
