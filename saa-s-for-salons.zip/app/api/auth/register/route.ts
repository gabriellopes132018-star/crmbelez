import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { name, email, password, phone, businessName } = await request.json()

    // Validações básicas
    if (!name || !email || !password) {
      return NextResponse.json({ success: false, error: "Campos obrigatórios não preenchidos" }, { status: 400 })
    }

    // Simular criação de usuário
    const newUser = {
      id: `user_${Date.now()}`,
      email,
      name,
      phone,
      businessName,
      role: "admin",
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      user: newUser,
      token: `token_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    })
  } catch {
    return NextResponse.json({ success: false, error: "Erro interno do servidor" }, { status: 500 })
  }
}
