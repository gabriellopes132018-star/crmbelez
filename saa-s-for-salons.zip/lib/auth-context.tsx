"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"

export interface User {
  id: string
  name: string
  email: string
  avatar?: string
  role: "admin" | "professional" | "receptionist"
  clinic: {
    id: string
    name: string
    plan: "start" | "pro" | "master" | "enterprise"
  }
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  register: (data: RegisterData) => Promise<{ success: boolean; error?: string }>
  logout: () => void
  forgotPassword: (email: string) => Promise<{ success: boolean; error?: string }>
}

interface RegisterData {
  name: string
  email: string
  password: string
  clinicName: string
  phone: string
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Usuário demo para demonstração
const DEMO_USER: User = {
  id: "1",
  name: "Maria Costa",
  email: "maria@clinicaderma.com.br",
  role: "admin",
  clinic: {
    id: "1",
    name: "Clínica Derma Beauty",
    plan: "pro",
  },
}

// Credenciais demo
const DEMO_CREDENTIALS = {
  email: "demo@esthetiflow.com.br",
  password: "demo123",
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Verificar se há sessão salva
    const savedUser = localStorage.getItem("esthetiflow_user")
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch {
        localStorage.removeItem("esthetiflow_user")
      }
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string) => {
    setIsLoading(true)

    // Simular delay de API
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Verificar credenciais demo
    if (email === DEMO_CREDENTIALS.email && password === DEMO_CREDENTIALS.password) {
      setUser(DEMO_USER)
      localStorage.setItem("esthetiflow_user", JSON.stringify(DEMO_USER))
      setIsLoading(false)
      router.push("/dashboard")
      return { success: true }
    }

    // Para qualquer outro email válido, criar usuário temporário (para demo)
    if (email.includes("@") && password.length >= 6) {
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        name: email
          .split("@")[0]
          .replace(/[._]/g, " ")
          .replace(/\b\w/g, (l) => l.toUpperCase()),
        email,
        role: "admin",
        clinic: {
          id: Math.random().toString(36).substr(2, 9),
          name: "Minha Clínica",
          plan: "start",
        },
      }
      setUser(newUser)
      localStorage.setItem("esthetiflow_user", JSON.stringify(newUser))
      setIsLoading(false)
      router.push("/dashboard")
      return { success: true }
    }

    setIsLoading(false)
    return { success: false, error: "E-mail ou senha inválidos" }
  }

  const register = async (data: RegisterData) => {
    setIsLoading(true)

    // Simular delay de API
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Validações básicas
    if (!data.email.includes("@")) {
      setIsLoading(false)
      return { success: false, error: "E-mail inválido" }
    }

    if (data.password.length < 6) {
      setIsLoading(false)
      return { success: false, error: "Senha deve ter pelo menos 6 caracteres" }
    }

    // Criar novo usuário
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: data.name,
      email: data.email,
      role: "admin",
      clinic: {
        id: Math.random().toString(36).substr(2, 9),
        name: data.clinicName,
        plan: "start",
      },
    }

    setUser(newUser)
    localStorage.setItem("esthetiflow_user", JSON.stringify(newUser))
    setIsLoading(false)
    router.push("/dashboard")
    return { success: true }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("esthetiflow_user")
    router.push("/login")
  }

  const forgotPassword = async (email: string) => {
    // Simular envio de email
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (!email.includes("@")) {
      return { success: false, error: "E-mail inválido" }
    }

    return { success: true }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        register,
        logout,
        forgotPassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
