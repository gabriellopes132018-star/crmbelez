"use client"

import useSWR, { mutate } from "swr"

const fetcher = async (url: string) => {
  const res = await fetch(url)
  if (!res.ok) {
    throw new Error("Erro na requisição")
  }
  const data = await res.json()
  return data.data
}

// Hook genérico para GET
export function useApi<T>(endpoint: string | null) {
  const { data, error, isLoading, mutate: revalidate } = useSWR<T>(endpoint ? `/api${endpoint}` : null, fetcher)

  return {
    data,
    error,
    isLoading,
    revalidate,
  }
}

// Funções de API para mutations
export const api = {
  // Clients
  async getClients(params?: Record<string, string>) {
    const query = params ? "?" + new URLSearchParams(params).toString() : ""
    const res = await fetch(`/api/clients${query}`)
    return res.json()
  },
  async getClient(id: string) {
    const res = await fetch(`/api/clients/${id}`)
    return res.json()
  },
  async createClient(data: Record<string, unknown>) {
    const res = await fetch("/api/clients", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    mutate("/api/clients")
    return res.json()
  },
  async updateClient(id: string, data: Record<string, unknown>) {
    const res = await fetch(`/api/clients/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    mutate("/api/clients")
    mutate(`/api/clients/${id}`)
    return res.json()
  },
  async deleteClient(id: string) {
    const res = await fetch(`/api/clients/${id}`, { method: "DELETE" })
    mutate("/api/clients")
    return res.json()
  },

  // Services
  async getServices(params?: Record<string, string>) {
    const query = params ? "?" + new URLSearchParams(params).toString() : ""
    const res = await fetch(`/api/services${query}`)
    return res.json()
  },
  async createService(data: Record<string, unknown>) {
    const res = await fetch("/api/services", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    mutate("/api/services")
    return res.json()
  },
  async updateService(id: string, data: Record<string, unknown>) {
    const res = await fetch(`/api/services/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    mutate("/api/services")
    return res.json()
  },
  async deleteService(id: string) {
    const res = await fetch(`/api/services/${id}`, { method: "DELETE" })
    mutate("/api/services")
    return res.json()
  },

  // Professionals
  async getProfessionals() {
    const res = await fetch("/api/professionals")
    return res.json()
  },
  async createProfessional(data: Record<string, unknown>) {
    const res = await fetch("/api/professionals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    mutate("/api/professionals")
    return res.json()
  },
  async updateProfessional(id: string, data: Record<string, unknown>) {
    const res = await fetch(`/api/professionals/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    mutate("/api/professionals")
    return res.json()
  },
  async deleteProfessional(id: string) {
    const res = await fetch(`/api/professionals/${id}`, { method: "DELETE" })
    mutate("/api/professionals")
    return res.json()
  },

  // Appointments
  async getAppointments(params?: Record<string, string>) {
    const query = params ? "?" + new URLSearchParams(params).toString() : ""
    const res = await fetch(`/api/appointments${query}`)
    return res.json()
  },
  async createAppointment(data: Record<string, unknown>) {
    const res = await fetch("/api/appointments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    mutate((key: string) => typeof key === "string" && key.startsWith("/api/appointments"), undefined, {
      revalidate: true,
    })
    return res.json()
  },
  async updateAppointment(id: string, data: Record<string, unknown>) {
    const res = await fetch(`/api/appointments/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    mutate((key: string) => typeof key === "string" && key.startsWith("/api/appointments"), undefined, {
      revalidate: true,
    })
    return res.json()
  },
  async deleteAppointment(id: string) {
    const res = await fetch(`/api/appointments/${id}`, { method: "DELETE" })
    mutate((key: string) => typeof key === "string" && key.startsWith("/api/appointments"), undefined, {
      revalidate: true,
    })
    return res.json()
  },

  // Products
  async getProducts(params?: Record<string, string>) {
    const query = params ? "?" + new URLSearchParams(params).toString() : ""
    const res = await fetch(`/api/products${query}`)
    return res.json()
  },
  async createProduct(data: Record<string, unknown>) {
    const res = await fetch("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    mutate("/api/products")
    return res.json()
  },
  async updateProduct(id: string, data: Record<string, unknown>) {
    const res = await fetch(`/api/products/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    mutate("/api/products")
    return res.json()
  },
  async deleteProduct(id: string) {
    const res = await fetch(`/api/products/${id}`, { method: "DELETE" })
    mutate("/api/products")
    return res.json()
  },

  // Transactions
  async getTransactions(params?: Record<string, string>) {
    const query = params ? "?" + new URLSearchParams(params).toString() : ""
    const res = await fetch(`/api/transactions${query}`)
    return res.json()
  },
  async createTransaction(data: Record<string, unknown>) {
    const res = await fetch("/api/transactions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    mutate("/api/transactions")
    return res.json()
  },

  // Dashboard
  async getDashboardStats() {
    const res = await fetch("/api/dashboard/stats")
    return res.json()
  },
}

// Hooks específicos
export function useClients(params?: Record<string, string>) {
  const query = params ? "?" + new URLSearchParams(params).toString() : ""
  return useApi(`/clients${query}`)
}

export function useClient(id: string | null) {
  return useApi(id ? `/clients/${id}` : null)
}

export function useServices(params?: Record<string, string>) {
  const query = params ? "?" + new URLSearchParams(params).toString() : ""
  return useApi(`/services${query}`)
}

export function useProfessionals() {
  return useApi("/professionals")
}

export function useAppointments(params?: Record<string, string>) {
  const query = params ? "?" + new URLSearchParams(params).toString() : ""
  return useApi(`/appointments${query}`)
}

export function useProducts(params?: Record<string, string>) {
  const query = params ? "?" + new URLSearchParams(params).toString() : ""
  return useApi(`/products${query}`)
}

export function useTransactions(params?: Record<string, string>) {
  const query = params ? "?" + new URLSearchParams(params).toString() : ""
  return useApi(`/transactions${query}`)
}

export function useDashboardStats() {
  return useApi("/dashboard/stats")
}
