// EsthetiFlow Database Layer - Simulação de banco de dados com localStorage

export interface User {
  id: string
  email: string
  password: string
  name: string
  role: "admin" | "manager" | "professional" | "receptionist"
  avatar?: string
  phone?: string
  createdAt: string
}

export interface Client {
  id: string
  name: string
  email: string
  phone: string
  cpf?: string
  birthDate?: string
  gender?: "M" | "F" | "O"
  address?: {
    street: string
    number: string
    complement?: string
    neighborhood: string
    city: string
    state: string
    zipCode: string
  }
  avatar?: string
  notes?: string
  tags: string[]
  loyaltyPoints: number
  totalSpent: number
  lastVisit?: string
  createdAt: string
  updatedAt: string
}

export interface Service {
  id: string
  name: string
  description: string
  category: string
  duration: number // em minutos
  price: number
  commission: number // percentual
  active: boolean
  color: string
  createdAt: string
}

export interface Professional {
  id: string
  userId?: string
  name: string
  email: string
  phone: string
  cpf?: string
  role: string
  specialties: string[]
  services: string[] // IDs dos serviços
  avatar?: string
  commission: number // percentual padrão
  workingHours: {
    [key: string]: { start: string; end: string; active: boolean }
  }
  active: boolean
  createdAt: string
}

export interface Appointment {
  id: string
  clientId: string
  clientName: string
  professionalId: string
  professionalName: string
  serviceId: string
  serviceName: string
  date: string
  startTime: string
  endTime: string
  duration: number
  price: number
  status: "scheduled" | "confirmed" | "in-progress" | "completed" | "cancelled" | "no-show"
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface Product {
  id: string
  name: string
  description: string
  category: string
  brand: string
  sku: string
  barcode?: string
  costPrice: number
  salePrice: number
  stock: number
  minStock: number
  unit: string
  active: boolean
  image?: string
  createdAt: string
  updatedAt: string
}

export interface Transaction {
  id: string
  type: "income" | "expense"
  category: string
  description: string
  amount: number
  paymentMethod: "cash" | "credit" | "debit" | "pix" | "transfer" | "boleto"
  status: "pending" | "completed" | "cancelled"
  clientId?: string
  clientName?: string
  appointmentId?: string
  professionalId?: string
  date: string
  dueDate?: string
  createdAt: string
}

export interface Campaign {
  id: string
  name: string
  type: "whatsapp" | "email" | "sms"
  status: "draft" | "scheduled" | "active" | "completed" | "paused"
  message: string
  targetAudience: string
  sentCount: number
  openRate: number
  clickRate: number
  scheduledDate?: string
  createdAt: string
}

export interface MedicalRecord {
  id: string
  clientId: string
  anamnesis: {
    allergies: string[]
    medications: string[]
    healthConditions: string[]
    skinType?: string
    observations?: string
  }
  procedures: {
    id: string
    date: string
    serviceId: string
    serviceName: string
    professionalId: string
    professionalName: string
    notes: string
    photos?: { before?: string; after?: string }
  }[]
  consent: {
    signed: boolean
    signedAt?: string
    signature?: string
  }
  createdAt: string
  updatedAt: string
}

// Classe do banco de dados
class Database {
  private getItem<T>(key: string, defaultValue: T): T {
    if (typeof window === "undefined") return defaultValue
    const item = localStorage.getItem(`esthetiflow_${key}`)
    return item ? JSON.parse(item) : defaultValue
  }

  private setItem<T>(key: string, value: T): void {
    if (typeof window === "undefined") return
    localStorage.setItem(`esthetiflow_${key}`, JSON.stringify(value))
  }

  // Users
  getUsers(): User[] {
    return this.getItem<User[]>("users", this.getDefaultUsers())
  }

  getUserByEmail(email: string): User | undefined {
    return this.getUsers().find((u) => u.email === email)
  }

  getUserById(id: string): User | undefined {
    return this.getUsers().find((u) => u.id === id)
  }

  createUser(user: Omit<User, "id" | "createdAt">): User {
    const users = this.getUsers()
    const newUser: User = {
      ...user,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
    }
    users.push(newUser)
    this.setItem("users", users)
    return newUser
  }

  // Clients
  getClients(): Client[] {
    return this.getItem<Client[]>("clients", this.getDefaultClients())
  }

  getClientById(id: string): Client | undefined {
    return this.getClients().find((c) => c.id === id)
  }

  createClient(client: Omit<Client, "id" | "createdAt" | "updatedAt" | "loyaltyPoints" | "totalSpent">): Client {
    const clients = this.getClients()
    const newClient: Client = {
      ...client,
      id: this.generateId(),
      loyaltyPoints: 0,
      totalSpent: 0,
      tags: client.tags || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    clients.push(newClient)
    this.setItem("clients", clients)
    return newClient
  }

  updateClient(id: string, data: Partial<Client>): Client | undefined {
    const clients = this.getClients()
    const index = clients.findIndex((c) => c.id === id)
    if (index === -1) return undefined
    clients[index] = { ...clients[index], ...data, updatedAt: new Date().toISOString() }
    this.setItem("clients", clients)
    return clients[index]
  }

  deleteClient(id: string): boolean {
    const clients = this.getClients()
    const filtered = clients.filter((c) => c.id !== id)
    if (filtered.length === clients.length) return false
    this.setItem("clients", filtered)
    return true
  }

  // Services
  getServices(): Service[] {
    return this.getItem<Service[]>("services", this.getDefaultServices())
  }

  getServiceById(id: string): Service | undefined {
    return this.getServices().find((s) => s.id === id)
  }

  createService(service: Omit<Service, "id" | "createdAt">): Service {
    const services = this.getServices()
    const newService: Service = {
      ...service,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
    }
    services.push(newService)
    this.setItem("services", services)
    return newService
  }

  updateService(id: string, data: Partial<Service>): Service | undefined {
    const services = this.getServices()
    const index = services.findIndex((s) => s.id === id)
    if (index === -1) return undefined
    services[index] = { ...services[index], ...data }
    this.setItem("services", services)
    return services[index]
  }

  deleteService(id: string): boolean {
    const services = this.getServices()
    const filtered = services.filter((s) => s.id !== id)
    if (filtered.length === services.length) return false
    this.setItem("services", filtered)
    return true
  }

  // Professionals
  getProfessionals(): Professional[] {
    return this.getItem<Professional[]>("professionals", this.getDefaultProfessionals())
  }

  getProfessionalById(id: string): Professional | undefined {
    return this.getProfessionals().find((p) => p.id === id)
  }

  createProfessional(professional: Omit<Professional, "id" | "createdAt">): Professional {
    const professionals = this.getProfessionals()
    const newProfessional: Professional = {
      ...professional,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
    }
    professionals.push(newProfessional)
    this.setItem("professionals", professionals)
    return newProfessional
  }

  updateProfessional(id: string, data: Partial<Professional>): Professional | undefined {
    const professionals = this.getProfessionals()
    const index = professionals.findIndex((p) => p.id === id)
    if (index === -1) return undefined
    professionals[index] = { ...professionals[index], ...data }
    this.setItem("professionals", professionals)
    return professionals[index]
  }

  deleteProfessional(id: string): boolean {
    const professionals = this.getProfessionals()
    const filtered = professionals.filter((p) => p.id !== id)
    if (filtered.length === professionals.length) return false
    this.setItem("professionals", filtered)
    return true
  }

  // Appointments
  getAppointments(): Appointment[] {
    return this.getItem<Appointment[]>("appointments", this.getDefaultAppointments())
  }

  getAppointmentById(id: string): Appointment | undefined {
    return this.getAppointments().find((a) => a.id === id)
  }

  getAppointmentsByDate(date: string): Appointment[] {
    return this.getAppointments().filter((a) => a.date === date)
  }

  getAppointmentsByClient(clientId: string): Appointment[] {
    return this.getAppointments().filter((a) => a.clientId === clientId)
  }

  getAppointmentsByProfessional(professionalId: string): Appointment[] {
    return this.getAppointments().filter((a) => a.professionalId === professionalId)
  }

  createAppointment(appointment: Omit<Appointment, "id" | "createdAt" | "updatedAt">): Appointment {
    const appointments = this.getAppointments()
    const newAppointment: Appointment = {
      ...appointment,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    appointments.push(newAppointment)
    this.setItem("appointments", appointments)
    return newAppointment
  }

  updateAppointment(id: string, data: Partial<Appointment>): Appointment | undefined {
    const appointments = this.getAppointments()
    const index = appointments.findIndex((a) => a.id === id)
    if (index === -1) return undefined
    appointments[index] = { ...appointments[index], ...data, updatedAt: new Date().toISOString() }
    this.setItem("appointments", appointments)
    return appointments[index]
  }

  deleteAppointment(id: string): boolean {
    const appointments = this.getAppointments()
    const filtered = appointments.filter((a) => a.id !== id)
    if (filtered.length === appointments.length) return false
    this.setItem("appointments", filtered)
    return true
  }

  // Products
  getProducts(): Product[] {
    return this.getItem<Product[]>("products", this.getDefaultProducts())
  }

  getProductById(id: string): Product | undefined {
    return this.getProducts().find((p) => p.id === id)
  }

  createProduct(product: Omit<Product, "id" | "createdAt" | "updatedAt">): Product {
    const products = this.getProducts()
    const newProduct: Product = {
      ...product,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    products.push(newProduct)
    this.setItem("products", products)
    return newProduct
  }

  updateProduct(id: string, data: Partial<Product>): Product | undefined {
    const products = this.getProducts()
    const index = products.findIndex((p) => p.id === id)
    if (index === -1) return undefined
    products[index] = { ...products[index], ...data, updatedAt: new Date().toISOString() }
    this.setItem("products", products)
    return products[index]
  }

  deleteProduct(id: string): boolean {
    const products = this.getProducts()
    const filtered = products.filter((p) => p.id !== id)
    if (filtered.length === products.length) return false
    this.setItem("products", filtered)
    return true
  }

  // Transactions
  getTransactions(): Transaction[] {
    return this.getItem<Transaction[]>("transactions", this.getDefaultTransactions())
  }

  getTransactionById(id: string): Transaction | undefined {
    return this.getTransactions().find((t) => t.id === id)
  }

  createTransaction(transaction: Omit<Transaction, "id" | "createdAt">): Transaction {
    const transactions = this.getTransactions()
    const newTransaction: Transaction = {
      ...transaction,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
    }
    transactions.push(newTransaction)
    this.setItem("transactions", transactions)
    return newTransaction
  }

  updateTransaction(id: string, data: Partial<Transaction>): Transaction | undefined {
    const transactions = this.getTransactions()
    const index = transactions.findIndex((t) => t.id === id)
    if (index === -1) return undefined
    transactions[index] = { ...transactions[index], ...data }
    this.setItem("transactions", transactions)
    return transactions[index]
  }

  // Campaigns
  getCampaigns(): Campaign[] {
    return this.getItem<Campaign[]>("campaigns", this.getDefaultCampaigns())
  }

  createCampaign(campaign: Omit<Campaign, "id" | "createdAt">): Campaign {
    const campaigns = this.getCampaigns()
    const newCampaign: Campaign = {
      ...campaign,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
    }
    campaigns.push(newCampaign)
    this.setItem("campaigns", campaigns)
    return newCampaign
  }

  // Medical Records
  getMedicalRecords(): MedicalRecord[] {
    return this.getItem<MedicalRecord[]>("medicalRecords", [])
  }

  getMedicalRecordByClientId(clientId: string): MedicalRecord | undefined {
    return this.getMedicalRecords().find((r) => r.clientId === clientId)
  }

  createOrUpdateMedicalRecord(clientId: string, data: Partial<MedicalRecord>): MedicalRecord {
    const records = this.getMedicalRecords()
    const index = records.findIndex((r) => r.clientId === clientId)

    if (index === -1) {
      const newRecord: MedicalRecord = {
        id: this.generateId(),
        clientId,
        anamnesis: data.anamnesis || { allergies: [], medications: [], healthConditions: [] },
        procedures: data.procedures || [],
        consent: data.consent || { signed: false },
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
      records.push(newRecord)
      this.setItem("medicalRecords", records)
      return newRecord
    }

    records[index] = { ...records[index], ...data, updatedAt: new Date().toISOString() }
    this.setItem("medicalRecords", records)
    return records[index]
  }

  // Dashboard Stats
  getDashboardStats() {
    const today = new Date().toISOString().split("T")[0]
    const appointments = this.getAppointments()
    const transactions = this.getTransactions()
    const clients = this.getClients()

    const todayAppointments = appointments.filter((a) => a.date === today)
    const completedToday = todayAppointments.filter((a) => a.status === "completed")
    const todayRevenue = transactions
      .filter((t) => t.date === today && t.type === "income" && t.status === "completed")
      .reduce((sum, t) => sum + t.amount, 0)

    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split("T")[0]
    const monthRevenue = transactions
      .filter((t) => t.date >= monthStart && t.type === "income" && t.status === "completed")
      .reduce((sum, t) => sum + t.amount, 0)

    return {
      todayAppointments: todayAppointments.length,
      completedAppointments: completedToday.length,
      todayRevenue,
      monthRevenue,
      totalClients: clients.length,
      newClientsMonth: clients.filter((c) => c.createdAt >= monthStart).length,
      occupancyRate:
        todayAppointments.length > 0 ? Math.round((completedToday.length / todayAppointments.length) * 100) : 0,
    }
  }

  // Utility methods
  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
  }

  // Default data
  private getDefaultUsers(): User[] {
    return [
      {
        id: "1",
        email: "demo@esthetiflow.com.br",
        password: "demo123",
        name: "Admin Demo",
        role: "admin",
        avatar: "/admin-avatar.png",
        phone: "(11) 99999-9999",
        createdAt: "2024-01-01T00:00:00.000Z",
      },
    ]
  }

  private getDefaultClients(): Client[] {
    return [
      {
        id: "c1",
        name: "Maria Silva",
        email: "maria@email.com",
        phone: "(11) 98765-4321",
        cpf: "123.456.789-00",
        birthDate: "1990-05-15",
        gender: "F",
        tags: ["VIP", "Frequente"],
        loyaltyPoints: 850,
        totalSpent: 4250,
        lastVisit: "2024-11-25",
        createdAt: "2024-01-15T00:00:00.000Z",
        updatedAt: "2024-11-25T00:00:00.000Z",
      },
      {
        id: "c2",
        name: "Ana Costa",
        email: "ana@email.com",
        phone: "(11) 91234-5678",
        gender: "F",
        tags: ["Nova"],
        loyaltyPoints: 150,
        totalSpent: 750,
        lastVisit: "2024-11-20",
        createdAt: "2024-10-01T00:00:00.000Z",
        updatedAt: "2024-11-20T00:00:00.000Z",
      },
      {
        id: "c3",
        name: "Juliana Santos",
        email: "juliana@email.com",
        phone: "(11) 94567-8901",
        gender: "F",
        tags: ["Frequente"],
        loyaltyPoints: 620,
        totalSpent: 3100,
        lastVisit: "2024-11-28",
        createdAt: "2024-03-10T00:00:00.000Z",
        updatedAt: "2024-11-28T00:00:00.000Z",
      },
      {
        id: "c4",
        name: "Fernanda Lima",
        email: "fernanda@email.com",
        phone: "(11) 92345-6789",
        gender: "F",
        tags: ["VIP"],
        loyaltyPoints: 1200,
        totalSpent: 6000,
        lastVisit: "2024-11-27",
        createdAt: "2023-08-20T00:00:00.000Z",
        updatedAt: "2024-11-27T00:00:00.000Z",
      },
      {
        id: "c5",
        name: "Carla Oliveira",
        email: "carla@email.com",
        phone: "(11) 93456-7890",
        gender: "F",
        tags: [],
        loyaltyPoints: 280,
        totalSpent: 1400,
        lastVisit: "2024-11-15",
        createdAt: "2024-06-05T00:00:00.000Z",
        updatedAt: "2024-11-15T00:00:00.000Z",
      },
    ]
  }

  private getDefaultServices(): Service[] {
    return [
      {
        id: "s1",
        name: "Limpeza de Pele Profunda",
        description: "Limpeza completa com extração, peeling e máscara hidratante",
        category: "Facial",
        duration: 90,
        price: 180,
        commission: 40,
        active: true,
        color: "#10b981",
        createdAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "s2",
        name: "Botox",
        description: "Aplicação de toxina botulínica para redução de rugas",
        category: "Injetáveis",
        duration: 30,
        price: 1200,
        commission: 35,
        active: true,
        color: "#8b5cf6",
        createdAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "s3",
        name: "Preenchimento Labial",
        description: "Preenchimento com ácido hialurônico para volumização dos lábios",
        category: "Injetáveis",
        duration: 45,
        price: 1500,
        commission: 35,
        active: true,
        color: "#ec4899",
        createdAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "s4",
        name: "Drenagem Linfática",
        description: "Massagem especializada para redução de inchaço e retenção de líquidos",
        category: "Corporal",
        duration: 60,
        price: 150,
        commission: 45,
        active: true,
        color: "#06b6d4",
        createdAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "s5",
        name: "Microagulhamento",
        description: "Tratamento para estímulo de colágeno e renovação celular",
        category: "Facial",
        duration: 60,
        price: 350,
        commission: 40,
        active: true,
        color: "#f59e0b",
        createdAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "s6",
        name: "Depilação a Laser - Axilas",
        description: "Depilação definitiva com tecnologia laser de diodo",
        category: "Depilação",
        duration: 15,
        price: 120,
        commission: 30,
        active: true,
        color: "#ef4444",
        createdAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "s7",
        name: "Peeling Químico",
        description: "Tratamento para renovação da pele com ácidos",
        category: "Facial",
        duration: 45,
        price: 280,
        commission: 40,
        active: true,
        color: "#84cc16",
        createdAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "s8",
        name: "Massagem Relaxante",
        description: "Massagem corporal para alívio de tensões",
        category: "Corporal",
        duration: 60,
        price: 180,
        commission: 45,
        active: true,
        color: "#6366f1",
        createdAt: "2024-01-01T00:00:00.000Z",
      },
    ]
  }

  private getDefaultProfessionals(): Professional[] {
    return [
      {
        id: "p1",
        name: "Dra. Camila Rocha",
        email: "camila@esthetiflow.com.br",
        phone: "(11) 97777-7777",
        role: "Dermatologista",
        specialties: ["Injetáveis", "Facial"],
        services: ["s2", "s3", "s5", "s7"],
        avatar: "/professional-woman-doctor.png",
        commission: 35,
        workingHours: {
          monday: { start: "09:00", end: "18:00", active: true },
          tuesday: { start: "09:00", end: "18:00", active: true },
          wednesday: { start: "09:00", end: "18:00", active: true },
          thursday: { start: "09:00", end: "18:00", active: true },
          friday: { start: "09:00", end: "17:00", active: true },
          saturday: { start: "09:00", end: "13:00", active: true },
          sunday: { start: "00:00", end: "00:00", active: false },
        },
        active: true,
        createdAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "p2",
        name: "Beatriz Mendes",
        email: "beatriz@esthetiflow.com.br",
        phone: "(11) 96666-6666",
        role: "Esteticista",
        specialties: ["Facial", "Corporal"],
        services: ["s1", "s4", "s8"],
        avatar: "/professional-woman-aesthetician.jpg",
        commission: 45,
        workingHours: {
          monday: { start: "08:00", end: "17:00", active: true },
          tuesday: { start: "08:00", end: "17:00", active: true },
          wednesday: { start: "08:00", end: "17:00", active: true },
          thursday: { start: "08:00", end: "17:00", active: true },
          friday: { start: "08:00", end: "16:00", active: true },
          saturday: { start: "08:00", end: "12:00", active: true },
          sunday: { start: "00:00", end: "00:00", active: false },
        },
        active: true,
        createdAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "p3",
        name: "Larissa Campos",
        email: "larissa@esthetiflow.com.br",
        phone: "(11) 95555-5555",
        role: "Técnica em Depilação",
        specialties: ["Depilação"],
        services: ["s6"],
        avatar: "/professional-woman-technician.jpg",
        commission: 30,
        workingHours: {
          monday: { start: "10:00", end: "19:00", active: true },
          tuesday: { start: "10:00", end: "19:00", active: true },
          wednesday: { start: "10:00", end: "19:00", active: true },
          thursday: { start: "10:00", end: "19:00", active: true },
          friday: { start: "10:00", end: "18:00", active: true },
          saturday: { start: "09:00", end: "14:00", active: true },
          sunday: { start: "00:00", end: "00:00", active: false },
        },
        active: true,
        createdAt: "2024-01-01T00:00:00.000Z",
      },
    ]
  }

  private getDefaultAppointments(): Appointment[] {
    const today = new Date().toISOString().split("T")[0]
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split("T")[0]

    return [
      {
        id: "a1",
        clientId: "c1",
        clientName: "Maria Silva",
        professionalId: "p1",
        professionalName: "Dra. Camila Rocha",
        serviceId: "s2",
        serviceName: "Botox",
        date: today,
        startTime: "09:00",
        endTime: "09:30",
        duration: 30,
        price: 1200,
        status: "confirmed",
        createdAt: "2024-11-20T00:00:00.000Z",
        updatedAt: "2024-11-20T00:00:00.000Z",
      },
      {
        id: "a2",
        clientId: "c2",
        clientName: "Ana Costa",
        professionalId: "p2",
        professionalName: "Beatriz Mendes",
        serviceId: "s1",
        serviceName: "Limpeza de Pele Profunda",
        date: today,
        startTime: "10:00",
        endTime: "11:30",
        duration: 90,
        price: 180,
        status: "scheduled",
        createdAt: "2024-11-21T00:00:00.000Z",
        updatedAt: "2024-11-21T00:00:00.000Z",
      },
      {
        id: "a3",
        clientId: "c3",
        clientName: "Juliana Santos",
        professionalId: "p1",
        professionalName: "Dra. Camila Rocha",
        serviceId: "s3",
        serviceName: "Preenchimento Labial",
        date: today,
        startTime: "14:00",
        endTime: "14:45",
        duration: 45,
        price: 1500,
        status: "confirmed",
        createdAt: "2024-11-22T00:00:00.000Z",
        updatedAt: "2024-11-22T00:00:00.000Z",
      },
      {
        id: "a4",
        clientId: "c4",
        clientName: "Fernanda Lima",
        professionalId: "p2",
        professionalName: "Beatriz Mendes",
        serviceId: "s4",
        serviceName: "Drenagem Linfática",
        date: today,
        startTime: "15:00",
        endTime: "16:00",
        duration: 60,
        price: 150,
        status: "scheduled",
        createdAt: "2024-11-23T00:00:00.000Z",
        updatedAt: "2024-11-23T00:00:00.000Z",
      },
      {
        id: "a5",
        clientId: "c5",
        clientName: "Carla Oliveira",
        professionalId: "p3",
        professionalName: "Larissa Campos",
        serviceId: "s6",
        serviceName: "Depilação a Laser - Axilas",
        date: tomorrow,
        startTime: "10:00",
        endTime: "10:15",
        duration: 15,
        price: 120,
        status: "scheduled",
        createdAt: "2024-11-24T00:00:00.000Z",
        updatedAt: "2024-11-24T00:00:00.000Z",
      },
    ]
  }

  private getDefaultProducts(): Product[] {
    return [
      {
        id: "prod1",
        name: "Protetor Solar FPS 50",
        description: "Protetor solar facial com alta proteção UVA/UVB",
        category: "Cuidados com a Pele",
        brand: "La Roche-Posay",
        sku: "LRP-PS50-001",
        barcode: "7891234567890",
        costPrice: 65,
        salePrice: 120,
        stock: 25,
        minStock: 10,
        unit: "un",
        active: true,
        createdAt: "2024-01-01T00:00:00.000Z",
        updatedAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "prod2",
        name: "Sérum Vitamina C",
        description: "Sérum antioxidante com 15% de vitamina C pura",
        category: "Tratamento",
        brand: "Skinceuticals",
        sku: "SKC-VC15-001",
        costPrice: 180,
        salePrice: 350,
        stock: 12,
        minStock: 5,
        unit: "un",
        active: true,
        createdAt: "2024-01-01T00:00:00.000Z",
        updatedAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "prod3",
        name: "Ácido Hialurônico 1ml",
        description: "Preenchedor dérmico para procedimentos estéticos",
        category: "Injetáveis",
        brand: "Juvederm",
        sku: "JUV-AH1-001",
        costPrice: 450,
        salePrice: 800,
        stock: 8,
        minStock: 3,
        unit: "seringa",
        active: true,
        createdAt: "2024-01-01T00:00:00.000Z",
        updatedAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "prod4",
        name: "Toxina Botulínica 50U",
        description: "Botox para procedimentos estéticos faciais",
        category: "Injetáveis",
        brand: "Botox",
        sku: "BTX-50U-001",
        costPrice: 380,
        salePrice: 650,
        stock: 15,
        minStock: 5,
        unit: "frasco",
        active: true,
        createdAt: "2024-01-01T00:00:00.000Z",
        updatedAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "prod5",
        name: "Hidratante Facial",
        description: "Creme hidratante para pele sensível",
        category: "Cuidados com a Pele",
        brand: "Bioderma",
        sku: "BIO-HF-001",
        costPrice: 45,
        salePrice: 89,
        stock: 30,
        minStock: 15,
        unit: "un",
        active: true,
        createdAt: "2024-01-01T00:00:00.000Z",
        updatedAt: "2024-01-01T00:00:00.000Z",
      },
      {
        id: "prod6",
        name: "Óleo Corporal",
        description: "Óleo nutritivo para massagem e hidratação corporal",
        category: "Corporal",
        brand: "Nuxe",
        sku: "NUX-OC-001",
        costPrice: 85,
        salePrice: 165,
        stock: 18,
        minStock: 8,
        unit: "un",
        active: true,
        createdAt: "2024-01-01T00:00:00.000Z",
        updatedAt: "2024-01-01T00:00:00.000Z",
      },
    ]
  }

  private getDefaultTransactions(): Transaction[] {
    const today = new Date().toISOString().split("T")[0]
    const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0]

    return [
      {
        id: "t1",
        type: "income",
        category: "Serviços",
        description: "Botox - Maria Silva",
        amount: 1200,
        paymentMethod: "credit",
        status: "completed",
        clientId: "c1",
        clientName: "Maria Silva",
        professionalId: "p1",
        date: today,
        createdAt: today,
      },
      {
        id: "t2",
        type: "income",
        category: "Serviços",
        description: "Limpeza de Pele - Ana Costa",
        amount: 180,
        paymentMethod: "pix",
        status: "completed",
        clientId: "c2",
        clientName: "Ana Costa",
        professionalId: "p2",
        date: today,
        createdAt: today,
      },
      {
        id: "t3",
        type: "income",
        category: "Produtos",
        description: "Protetor Solar - Juliana Santos",
        amount: 120,
        paymentMethod: "debit",
        status: "completed",
        clientId: "c3",
        clientName: "Juliana Santos",
        date: yesterday,
        createdAt: yesterday,
      },
      {
        id: "t4",
        type: "expense",
        category: "Fornecedores",
        description: "Compra de produtos - Distribuidora XYZ",
        amount: 2500,
        paymentMethod: "transfer",
        status: "completed",
        date: yesterday,
        createdAt: yesterday,
      },
      {
        id: "t5",
        type: "expense",
        category: "Operacional",
        description: "Conta de luz",
        amount: 450,
        paymentMethod: "boleto",
        status: "pending",
        date: today,
        dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split("T")[0],
        createdAt: today,
      },
    ]
  }

  private getDefaultCampaigns(): Campaign[] {
    return [
      {
        id: "camp1",
        name: "Promoção de Verão",
        type: "whatsapp",
        status: "active",
        message: "Olá {nome}! Aproveite 20% de desconto em todos os tratamentos faciais este mês!",
        targetAudience: "Todos os clientes",
        sentCount: 156,
        openRate: 78,
        clickRate: 32,
        createdAt: "2024-11-01T00:00:00.000Z",
      },
      {
        id: "camp2",
        name: "Lembrete de Retorno",
        type: "email",
        status: "completed",
        message: "Sentimos sua falta! Que tal agendar seu próximo horário?",
        targetAudience: "Clientes inativos há 30 dias",
        sentCount: 89,
        openRate: 45,
        clickRate: 18,
        createdAt: "2024-10-15T00:00:00.000Z",
      },
    ]
  }

  // Reset database
  resetDatabase(): void {
    if (typeof window === "undefined") return
    const keys = [
      "users",
      "clients",
      "services",
      "professionals",
      "appointments",
      "products",
      "transactions",
      "campaigns",
      "medicalRecords",
    ]
    keys.forEach((key) => localStorage.removeItem(`esthetiflow_${key}`))
  }
}

export const db = new Database()
