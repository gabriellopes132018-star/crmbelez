"use client"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

interface CalendarDayViewProps {
  currentDate: Date
  onSelectAppointment: (id: number) => void
}

const hours = Array.from({ length: 13 }, (_, i) => i + 7)

const appointments = [
  {
    id: 1,
    startHour: 9,
    duration: 1,
    client: "Maria Silva",
    service: "Limpeza de Pele",
    professional: "Dra. Ana",
    status: "confirmed",
    avatar: "MS",
  },
  {
    id: 2,
    startHour: 10.5,
    duration: 1.5,
    client: "Ana Costa",
    service: "Massagem Relaxante",
    professional: "Carla",
    status: "confirmed",
    avatar: "AC",
  },
  {
    id: 3,
    startHour: 12,
    duration: 0.75,
    client: "Julia Santos",
    service: "Design Sobrancelhas",
    professional: "Paula",
    status: "pending",
    avatar: "JS",
  },
  {
    id: 4,
    startHour: 14,
    duration: 2,
    client: "Fernanda Oliveira",
    service: "Pacote Noiva Completo",
    professional: "Dra. Ana",
    status: "confirmed",
    avatar: "FO",
  },
  {
    id: 5,
    startHour: 16.5,
    duration: 1,
    client: "Patrícia Lima",
    service: "Peeling Químico",
    professional: "Dra. Ana",
    status: "pending",
    avatar: "PL",
  },
  {
    id: 6,
    startHour: 18,
    duration: 1.5,
    client: "Camila Rocha",
    service: "Tratamento Facial",
    professional: "Carla",
    status: "confirmed",
    avatar: "CR",
  },
]

const statusColors = {
  confirmed: "bg-green-500/20 border-green-500/50",
  pending: "bg-yellow-500/20 border-yellow-500/50",
  cancelled: "bg-red-500/20 border-red-500/50",
}

const statusLabels = {
  confirmed: { label: "Confirmado", color: "text-green-500" },
  pending: { label: "Pendente", color: "text-yellow-500" },
  cancelled: { label: "Cancelado", color: "text-red-500" },
}

export function CalendarDayView({ currentDate, onSelectAppointment }: CalendarDayViewProps) {
  return (
    <div className="flex h-full border border-border rounded-xl overflow-hidden bg-card">
      {/* Time grid */}
      <div className="flex-1 overflow-auto">
        <div className="grid grid-cols-[80px_1fr] min-h-[800px]">
          {/* Hours column */}
          <div className="border-r border-border bg-secondary/20">
            {hours.map((hour) => (
              <div key={hour} className="h-20 border-b border-border/50 px-3 py-2 flex items-start">
                <span className="text-sm font-medium text-muted-foreground">{hour.toString().padStart(2, "0")}:00</span>
              </div>
            ))}
          </div>

          {/* Main area */}
          <div className="relative">
            {hours.map((hour) => (
              <div
                key={hour}
                className="h-20 border-b border-border/50 hover:bg-secondary/20 cursor-pointer transition-colors"
              />
            ))}

            {/* Appointments */}
            {appointments.map((apt) => {
              const top = (apt.startHour - 7) * 80
              const height = apt.duration * 80
              const status = statusLabels[apt.status as keyof typeof statusLabels]

              return (
                <div
                  key={apt.id}
                  className={cn(
                    "absolute left-2 right-2 rounded-xl border-2 p-4 cursor-pointer transition-all hover:scale-[1.01] hover:shadow-xl",
                    statusColors[apt.status as keyof typeof statusColors],
                  )}
                  style={{ top: `${top}px`, height: `${height}px` }}
                  onClick={() => onSelectAppointment(apt.id)}
                >
                  <div className="flex items-start gap-4 h-full">
                    <Avatar className="h-12 w-12 border-2 border-background">
                      <AvatarFallback className="bg-primary/20 text-primary font-medium">{apt.avatar}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-foreground">{apt.client}</span>
                        <Badge variant="outline" className={cn("text-xs", status.color)}>
                          {status.label}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">{apt.service}</div>
                      <div className="text-sm text-muted-foreground/70 mt-1">
                        {apt.professional} • {apt.duration}h
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-lg font-bold text-primary">
                        {apt.startHour.toString().split(".")[0].padStart(2, "0")}:
                        {apt.startHour % 1 === 0 ? "00" : "30"}
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
