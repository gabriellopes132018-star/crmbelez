"use client"
import { format, addDays, startOfWeek, isToday } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"

interface CalendarWeekViewProps {
  currentDate: Date
  onSelectAppointment: (id: number) => void
}

const hours = Array.from({ length: 13 }, (_, i) => i + 7) // 7:00 to 19:00

const appointments = [
  {
    id: 1,
    day: 0,
    startHour: 9,
    duration: 1,
    client: "Maria Silva",
    service: "Limpeza de Pele",
    professional: "Dra. Ana",
    status: "confirmed",
  },
  {
    id: 2,
    day: 0,
    startHour: 10.5,
    duration: 1.5,
    client: "Ana Costa",
    service: "Massagem",
    professional: "Carla",
    status: "confirmed",
  },
  {
    id: 3,
    day: 0,
    startHour: 14,
    duration: 2,
    client: "Julia Santos",
    service: "Pacote Noiva",
    professional: "Dra. Ana",
    status: "pending",
  },
  {
    id: 4,
    day: 1,
    startHour: 8,
    duration: 1,
    client: "Fernanda Lima",
    service: "Design Sobrancelhas",
    professional: "Paula",
    status: "confirmed",
  },
  {
    id: 5,
    day: 1,
    startHour: 11,
    duration: 1.5,
    client: "Camila Rocha",
    service: "Peeling",
    professional: "Dra. Ana",
    status: "confirmed",
  },
  {
    id: 6,
    day: 2,
    startHour: 9,
    duration: 1,
    client: "Patrícia Souza",
    service: "Limpeza de Pele",
    professional: "Carla",
    status: "pending",
  },
  {
    id: 7,
    day: 2,
    startHour: 15,
    duration: 2,
    client: "Amanda Costa",
    service: "Tratamento Facial",
    professional: "Dra. Ana",
    status: "confirmed",
  },
  {
    id: 8,
    day: 3,
    startHour: 10,
    duration: 1,
    client: "Beatriz Lima",
    service: "Manicure",
    professional: "Julia",
    status: "confirmed",
  },
  {
    id: 9,
    day: 4,
    startHour: 14,
    duration: 1.5,
    client: "Carolina Silva",
    service: "Massagem",
    professional: "Carla",
    status: "pending",
  },
  {
    id: 10,
    day: 5,
    startHour: 9,
    duration: 1,
    client: "Diana Ferreira",
    service: "Design Sobrancelhas",
    professional: "Paula",
    status: "confirmed",
  },
]

const statusColors = {
  confirmed: "bg-green-500/20 border-green-500/50 text-green-100",
  pending: "bg-yellow-500/20 border-yellow-500/50 text-yellow-100",
  cancelled: "bg-red-500/20 border-red-500/50 text-red-100",
}

export function CalendarWeekView({ currentDate, onSelectAppointment }: CalendarWeekViewProps) {
  const weekStart = startOfWeek(currentDate, { locale: ptBR })
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i))

  return (
    <div className="flex flex-col h-full border border-border rounded-xl overflow-hidden bg-card">
      {/* Header with days */}
      <div className="grid grid-cols-8 border-b border-border bg-secondary/30">
        <div className="p-3 text-center text-xs text-muted-foreground border-r border-border">Horário</div>
        {weekDays.map((day, i) => (
          <div
            key={i}
            className={cn("p-3 text-center border-r border-border last:border-r-0", isToday(day) && "bg-primary/10")}
          >
            <div className="text-xs text-muted-foreground uppercase">{format(day, "EEE", { locale: ptBR })}</div>
            <div className={cn("text-lg font-semibold mt-1", isToday(day) && "text-primary")}>{format(day, "dd")}</div>
          </div>
        ))}
      </div>

      {/* Time grid */}
      <div className="flex-1 overflow-auto">
        <div className="grid grid-cols-8 min-h-[800px]">
          {/* Hours column */}
          <div className="border-r border-border">
            {hours.map((hour) => (
              <div key={hour} className="h-16 border-b border-border/50 px-2 py-1">
                <span className="text-xs text-muted-foreground">{hour.toString().padStart(2, "0")}:00</span>
              </div>
            ))}
          </div>

          {/* Days columns */}
          {weekDays.map((day, dayIndex) => (
            <div
              key={dayIndex}
              className={cn("relative border-r border-border last:border-r-0", isToday(day) && "bg-primary/5")}
            >
              {hours.map((hour) => (
                <div
                  key={hour}
                  className="h-16 border-b border-border/50 hover:bg-secondary/30 cursor-pointer transition-colors"
                />
              ))}

              {/* Appointments */}
              {appointments
                .filter((apt) => apt.day === dayIndex)
                .map((apt) => {
                  const top = (apt.startHour - 7) * 64 // 64px per hour
                  const height = apt.duration * 64
                  return (
                    <div
                      key={apt.id}
                      className={cn(
                        "absolute left-1 right-1 rounded-lg border p-2 cursor-pointer transition-all hover:scale-[1.02] hover:shadow-lg",
                        statusColors[apt.status as keyof typeof statusColors],
                      )}
                      style={{ top: `${top}px`, height: `${height}px` }}
                      onClick={() => onSelectAppointment(apt.id)}
                    >
                      <div className="text-xs font-medium truncate">{apt.client}</div>
                      <div className="text-xs opacity-80 truncate">{apt.service}</div>
                      <div className="text-xs opacity-60 truncate mt-1">{apt.professional}</div>
                    </div>
                  )
                })}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
