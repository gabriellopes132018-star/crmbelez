"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { CalendarIcon, Search, User } from "lucide-react"
import { cn } from "@/lib/utils"

interface NewAppointmentModalProps {
  open: boolean
  onClose: () => void
}

const clients = [
  { id: 1, name: "Maria Silva", phone: "(11) 99999-0001" },
  { id: 2, name: "Ana Costa", phone: "(11) 99999-0002" },
  { id: 3, name: "Julia Santos", phone: "(11) 99999-0003" },
]

const services = [
  { id: 1, name: "Limpeza de Pele", duration: "1h", price: "R$ 180,00" },
  { id: 2, name: "Massagem Relaxante", duration: "1h30", price: "R$ 220,00" },
  { id: 3, name: "Design de Sobrancelhas", duration: "45min", price: "R$ 80,00" },
  { id: 4, name: "Peeling Químico", duration: "1h", price: "R$ 250,00" },
  { id: 5, name: "Tratamento Facial", duration: "1h30", price: "R$ 300,00" },
]

const professionals = [
  { id: 1, name: "Dra. Ana Paula" },
  { id: 2, name: "Carla Mendes" },
  { id: 3, name: "Paula Silva" },
]

const timeSlots = [
  "08:00",
  "08:30",
  "09:00",
  "09:30",
  "10:00",
  "10:30",
  "11:00",
  "11:30",
  "12:00",
  "12:30",
  "13:00",
  "13:30",
  "14:00",
  "14:30",
  "15:00",
  "15:30",
  "16:00",
  "16:30",
  "17:00",
  "17:30",
  "18:00",
  "18:30",
  "19:00",
]

export function NewAppointmentModal({ open, onClose }: NewAppointmentModalProps) {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [searchClient, setSearchClient] = useState("")

  const filteredClients = clients.filter(
    (c) => c.name.toLowerCase().includes(searchClient.toLowerCase()) || c.phone.includes(searchClient),
  )

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Novo Agendamento</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Client Search */}
          <div className="space-y-2">
            <Label>Cliente</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome ou telefone..."
                className="pl-10"
                value={searchClient}
                onChange={(e) => setSearchClient(e.target.value)}
              />
            </div>
            {searchClient && (
              <div className="border border-border rounded-lg divide-y divide-border">
                {filteredClients.map((client) => (
                  <div
                    key={client.id}
                    className="flex items-center gap-3 p-3 hover:bg-secondary/50 cursor-pointer transition-colors"
                    onClick={() => setSearchClient(client.name)}
                  >
                    <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                      <User className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <div className="font-medium text-sm">{client.name}</div>
                      <div className="text-xs text-muted-foreground">{client.phone}</div>
                    </div>
                  </div>
                ))}
                <div
                  className="p-3 text-sm text-primary cursor-pointer hover:bg-secondary/50 transition-colors"
                  onClick={() => {}}
                >
                  + Cadastrar novo cliente
                </div>
              </div>
            )}
          </div>

          {/* Service */}
          <div className="space-y-2">
            <Label>Serviço</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o serviço" />
              </SelectTrigger>
              <SelectContent>
                {services.map((service) => (
                  <SelectItem key={service.id} value={service.id.toString()}>
                    <div className="flex items-center justify-between w-full gap-4">
                      <span>{service.name}</span>
                      <span className="text-muted-foreground text-xs">
                        {service.duration} • {service.price}
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Professional */}
          <div className="space-y-2">
            <Label>Profissional</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o profissional" />
              </SelectTrigger>
              <SelectContent>
                {professionals.map((prof) => (
                  <SelectItem key={prof.id} value={prof.id.toString()}>
                    {prof.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Date & Time */}
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Data</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP", { locale: ptBR }) : "Selecione a data"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={date} onSelect={setDate} locale={ptBR} initialFocus />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Horário</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o horário" />
                </SelectTrigger>
                <SelectContent>
                  {timeSlots.map((time) => (
                    <SelectItem key={time} value={time}>
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label>Observações (opcional)</Label>
            <Textarea placeholder="Adicione observações sobre o agendamento..." rows={3} />
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t border-border">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Criar Agendamento</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
