"use client"

import { useMemo } from "react"
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, isSameMonth, isToday } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"

interface CalendarMonthViewProps {
  currentDate: Date
  setCurrentDate: (date: Date) => void
  onSelectAppointment: (id: number) => void
}

const appointmentsByDay: Record<string, Array<{ id: number; client: string; time: string; status: string }>> = {
  "2025-11-29": [
    { id: 1, client: "Maria Silva", time: "09:00", status: "confirmed" },
    { id: 2, client: "Ana Costa", time: "10:30", status: "confirmed" },
    { id: 3, client: "Julia Santos", time: "14:00", status: "pending" },
  ],
  "2025-11-30": [
    { id: 4, client: "Fernanda Lima", time: "08:00", status: "confirmed" },
    { id: 5, client: "Camila Rocha", time: "11:00", status: "confirmed" },
  ],
  "2025-12-01": [
    { id: 6, client: "Patrícia Souza", time: "09:00", status: "pending" },
    { id: 7, client: "Amanda Costa", time: "15:00", status: "confirmed" },
    { id: 8, client: "Beatriz Lima", time: "17:00", status: "confirmed" },
    { id: 9, client: "Carolina Silva", time: "18:00", status: "pending" },
  ],
  "2025-12-02": [{ id: 10, client: "Diana Ferreira", time: "10:00", status: "confirmed" }],
  "2025-12-03": [
    { id: 11, client: "Elena Martins", time: "09:00", status: "confirmed" },
    { id: 12, client: "Flávia Costa", time: "14:00", status: "pending" },
  ],
  "2025-12-05": [
    { id: 13, client: "Gabriela Lima", time: "08:00", status: "confirmed" },
    { id: 14, client: "Helena Souza", time: "10:00", status: "confirmed" },
    { id: 15, client: "Isabela Rocha", time: "15:00", status: "confirmed" },
  ],
}

const statusDot = {
  confirmed: "bg-green-500",
  pending: "bg-yellow-500",
  cancelled: "bg-red-500",
}

export function CalendarMonthView({ currentDate, setCurrentDate, onSelectAppointment }: CalendarMonthViewProps) {
  const days = useMemo(() => {
    const monthStart = startOfMonth(currentDate)
    const monthEnd = endOfMonth(currentDate)
    const start = startOfWeek(monthStart, { locale: ptBR })
    const end = endOfWeek(monthEnd, { locale: ptBR })

    const daysArray = []
    let day = start
    while (day <= end) {
      daysArray.push(day)
      day = addDays(day, 1)
    }
    return daysArray
  }, [currentDate])

  const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"]

  return (
    <div className="border border-border rounded-xl overflow-hidden bg-card">
      {/* Header */}
      <div className="grid grid-cols-7 bg-secondary/30">
        {weekDays.map((day) => (
          <div key={day} className="p-3 text-center text-sm font-medium text-muted-foreground border-b border-border">
            {day}
          </div>
        ))}
      </div>

      {/* Days grid */}
      <div className="grid grid-cols-7">
        {days.map((day, i) => {
          const dateKey = format(day, "yyyy-MM-dd")
          const dayAppointments = appointmentsByDay[dateKey] || []
          const isCurrentMonth = isSameMonth(day, currentDate)

          return (
            <div
              key={i}
              className={cn(
                "min-h-[120px] p-2 border-b border-r border-border/50 hover:bg-secondary/20 cursor-pointer transition-colors",
                !isCurrentMonth && "bg-secondary/10 opacity-50",
                isToday(day) && "bg-primary/5",
              )}
              onClick={() => setCurrentDate(day)}
            >
              <div className="flex items-center justify-between mb-2">
                <span
                  className={cn(
                    "h-7 w-7 flex items-center justify-center rounded-full text-sm font-medium",
                    isToday(day) && "bg-primary text-primary-foreground",
                    !isToday(day) && !isCurrentMonth && "text-muted-foreground/50",
                  )}
                >
                  {format(day, "d")}
                </span>
                {dayAppointments.length > 0 && (
                  <Badge variant="outline" className="text-xs">
                    {dayAppointments.length}
                  </Badge>
                )}
              </div>

              <div className="space-y-1">
                {dayAppointments.slice(0, 3).map((apt) => (
                  <div
                    key={apt.id}
                    className="flex items-center gap-1.5 text-xs p-1 rounded bg-secondary/50 hover:bg-secondary transition-colors"
                    onClick={(e) => {
                      e.stopPropagation()
                      onSelectAppointment(apt.id)
                    }}
                  >
                    <div className={cn("h-1.5 w-1.5 rounded-full", statusDot[apt.status as keyof typeof statusDot])} />
                    <span className="text-muted-foreground">{apt.time}</span>
                    <span className="truncate">{apt.client}</span>
                  </div>
                ))}
                {dayAppointments.length > 3 && (
                  <div className="text-xs text-muted-foreground pl-1">+{dayAppointments.length - 3} mais</div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
