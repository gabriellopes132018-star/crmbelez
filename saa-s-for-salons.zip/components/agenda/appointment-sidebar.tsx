"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { X, Phone, MessageSquare, Clock, User, Scissors, DollarSign, Edit, CheckCircle, XCircle } from "lucide-react"

interface AppointmentSidebarProps {
  appointmentId: number
  onClose: () => void
}

const appointmentData = {
  id: 1,
  client: {
    name: "Maria Silva",
    email: "maria@email.com",
    phone: "(11) 99999-0001",
    avatar: "MS",
    visits: 12,
  },
  service: "Limpeza de Pele Profunda",
  professional: "Dra. Ana Paula",
  date: "29 de Novembro, 2025",
  time: "09:00 - 10:00",
  duration: "1 hora",
  price: "R$ 180,00",
  status: "confirmed",
  notes: "Cliente com pele sensível. Usar produtos hipoalergênicos.",
}

export function AppointmentSidebar({ appointmentId, onClose }: AppointmentSidebarProps) {
  const apt = appointmentData

  return (
    <div className="w-80 border-l border-border bg-card flex flex-col h-full ml-4">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h3 className="font-semibold">Detalhes do Agendamento</h3>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4 space-y-6">
        {/* Status */}
        <div className="flex items-center justify-between">
          <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/50">
            <CheckCircle className="h-3 w-3 mr-1" />
            Confirmado
          </Badge>
          <span className="text-sm text-muted-foreground">#{apt.id}</span>
        </div>

        {/* Client */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-muted-foreground">Cliente</h4>
          <div className="flex items-center gap-3">
            <Avatar className="h-12 w-12">
              <AvatarFallback className="bg-primary/20 text-primary">{apt.client.avatar}</AvatarFallback>
            </Avatar>
            <div>
              <div className="font-medium">{apt.client.name}</div>
              <div className="text-sm text-muted-foreground">{apt.client.visits} visitas</div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="flex-1 bg-transparent">
              <Phone className="h-4 w-4 mr-2" />
              Ligar
            </Button>
            <Button variant="outline" size="sm" className="flex-1 bg-transparent">
              <MessageSquare className="h-4 w-4 mr-2" />
              WhatsApp
            </Button>
          </div>
        </div>

        <Separator />

        {/* Details */}
        <div className="space-y-4">
          <h4 className="text-sm font-medium text-muted-foreground">Detalhes</h4>

          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center">
                <Scissors className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <div className="text-sm font-medium">{apt.service}</div>
                <div className="text-xs text-muted-foreground">Serviço</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center">
                <User className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <div className="text-sm font-medium">{apt.professional}</div>
                <div className="text-xs text-muted-foreground">Profissional</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center">
                <Clock className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <div className="text-sm font-medium">{apt.date}</div>
                <div className="text-xs text-muted-foreground">
                  {apt.time} ({apt.duration})
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center">
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <div className="text-sm font-medium text-primary">{apt.price}</div>
                <div className="text-xs text-muted-foreground">Valor</div>
              </div>
            </div>
          </div>
        </div>

        <Separator />

        {/* Notes */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-muted-foreground">Observações</h4>
          <p className="text-sm bg-secondary/50 rounded-lg p-3">{apt.notes}</p>
        </div>
      </div>

      {/* Actions */}
      <div className="p-4 border-t border-border space-y-2">
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" className="w-full bg-transparent">
            <Edit className="h-4 w-4 mr-2" />
            Editar
          </Button>
          <Button variant="outline" className="w-full text-destructive hover:text-destructive bg-transparent">
            <XCircle className="h-4 w-4 mr-2" />
            Cancelar
          </Button>
        </div>
        <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
          <CheckCircle className="h-4 w-4 mr-2" />
          Marcar como Concluído
        </Button>
      </div>
    </div>
  )
}
