"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChevronLeft, ChevronRight, Plus, Filter } from "lucide-react"
import { format, addDays, addWeeks, addMonths, subDays, subWeeks, subMonths } from "date-fns"
import { ptBR } from "date-fns/locale"
import type { ViewType } from "@/app/dashboard/agenda/page"

interface CalendarHeaderProps {
  view: ViewType
  setView: (view: ViewType) => void
  currentDate: Date
  setCurrentDate: (date: Date) => void
  onNewAppointment: () => void
}

export function CalendarHeader({ view, setView, currentDate, setCurrentDate, onNewAppointment }: CalendarHeaderProps) {
  const navigatePrev = () => {
    if (view === "day") setCurrentDate(subDays(currentDate, 1))
    if (view === "week") setCurrentDate(subWeeks(currentDate, 1))
    if (view === "month") setCurrentDate(subMonths(currentDate, 1))
  }

  const navigateNext = () => {
    if (view === "day") setCurrentDate(addDays(currentDate, 1))
    if (view === "week") setCurrentDate(addWeeks(currentDate, 1))
    if (view === "month") setCurrentDate(addMonths(currentDate, 1))
  }

  const goToToday = () => setCurrentDate(new Date())

  const getTitle = () => {
    if (view === "day") return format(currentDate, "dd 'de' MMMM, yyyy", { locale: ptBR })
    if (view === "week") {
      const start = format(currentDate, "dd MMM", { locale: ptBR })
      const end = format(addDays(currentDate, 6), "dd MMM", { locale: ptBR })
      return `${start} - ${end}`
    }
    return format(currentDate, "MMMM yyyy", { locale: ptBR })
  }

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={navigatePrev}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={navigateNext}>
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={goToToday}>
            Hoje
          </Button>
        </div>

        <h2 className="text-xl font-semibold capitalize">{getTitle()}</h2>

        <Badge variant="outline" className="hidden sm:flex">
          12 agendamentos
        </Badge>
      </div>

      <div className="flex items-center gap-2 w-full sm:w-auto">
        <div className="flex rounded-lg border border-border p-1">
          {(["day", "week", "month"] as ViewType[]).map((v) => (
            <Button
              key={v}
              variant={view === v ? "default" : "ghost"}
              size="sm"
              className={view === v ? "bg-primary text-primary-foreground" : ""}
              onClick={() => setView(v)}
            >
              {v === "day" ? "Dia" : v === "week" ? "Semana" : "Mês"}
            </Button>
          ))}
        </div>

        <Select defaultValue="all">
          <SelectTrigger className="w-[140px]">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Filtrar" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="confirmed">Confirmados</SelectItem>
            <SelectItem value="pending">Pendentes</SelectItem>
            <SelectItem value="cancelled">Cancelados</SelectItem>
          </SelectContent>
        </Select>

        <Button className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={onNewAppointment}>
          <Plus className="h-4 w-4 mr-2" />
          <span className="hidden sm:inline">Novo Agendamento</span>
          <span className="sm:hidden">Novo</span>
        </Button>
      </div>
    </div>
  )
}
