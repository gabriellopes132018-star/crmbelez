import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Dra. Marina Costa",
    role: "Clínica Derma Beauty",
    location: "São Paulo, SP",
    content:
      "O EsthetiFlow transformou minha clínica. A agenda online reduziu faltas em 60% e o prontuário digital economiza horas por semana.",
    rating: 5,
  },
  {
    name: "Carlos Mendes",
    role: "Studio Hair & Beauty",
    location: "Rio de Janeiro, RJ",
    content:
      "Melhor investimento que fiz. O sistema de comissões e relatórios me deu controle total sobre o negócio. Recomendo!",
    rating: 5,
  },
  {
    name: "Ana Paula Silva",
    role: "Spa Essence",
    location: "Belo Horizonte, MG",
    content:
      "A integração com WhatsApp é perfeita. Meus clientes adoram receber lembretes e confirmar pelo celular. Zero faltas!",
    rating: 5,
  },
  {
    name: "Juliana Ferreira",
    role: "Nail Art Studio",
    location: "Curitiba, PR",
    content:
      "Simples, bonito e funcional. Consegui organizar minha agenda, controlar estoque e ainda vender online. Tudo em um só lugar.",
    rating: 5,
  },
  {
    name: "Dr. Roberto Lima",
    role: "Clínica Estética Plus",
    location: "Brasília, DF",
    content:
      "O prontuário com fotos antes/depois é sensacional. Meus pacientes ficam impressionados e eu tenho tudo documentado.",
    rating: 5,
  },
  {
    name: "Fernanda Oliveira",
    role: "Beauty Center",
    location: "Salvador, BA",
    content:
      "Migrei de outro sistema e foi a melhor decisão. O suporte é incrível e o sistema é muito mais completo. 5 estrelas!",
    rating: 5,
  },
]

export function TestimonialsSection() {
  return (
    <section id="depoimentos" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h2 className="font-serif text-3xl font-bold tracking-tight sm:text-4xl">
            Quem usa, <span className="text-primary">recomenda</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Mais de 5.000 clínicas e salões já transformaram seus negócios com o EsthetiFlow.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, i) => (
            <div
              key={i}
              className="rounded-2xl border border-border/50 bg-card/50 p-6 transition-all hover:border-primary/30"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, j) => (
                  <Star key={j} className="h-4 w-4 fill-primary text-primary" />
                ))}
              </div>

              <p className="text-muted-foreground mb-6 leading-relaxed">
                {'"'}
                {testimonial.content}
                {'"'}
              </p>

              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <span className="text-sm font-medium text-primary">
                    {testimonial.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </span>
                </div>
                <div>
                  <div className="font-medium text-sm">{testimonial.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {testimonial.role} • {testimonial.location}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
