import { Badge } from "@/components/ui/badge"

const integrations = [
  { name: "WhatsApp Business", category: "Comunicação", status: "Nativo" },
  { name: "Pagar.me", category: "Pagamentos", status: "Nativo" },
  { name: "Mercado Pago", category: "Pagamentos", status: "Nativo" },
  { name: "Stripe", category: "Pagamentos", status: "Nativo" },
  { name: "Instagram", category: "Marketing", status: "Nativo" },
  { name: "Telegram", category: "Comunicação", status: "Nativo" },
  { name: "Google Calendar", category: "Agenda", status: "Integração" },
  { name: "Zapier", category: "Automação", status: "Integração" },
  { name: "RD Station", category: "Marketing", status: "Integração" },
  { name: "Mailchimp", category: "Marketing", status: "Integração" },
  { name: "Hotmart", category: "Vendas", status: "Integração" },
  { name: "Nota Fiscal", category: "Fiscal", status: "Nativo" },
]

export function IntegrationsSection() {
  return (
    <section id="integracoes" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h2 className="font-serif text-3xl font-bold tracking-tight sm:text-4xl">
            Integrações que <span className="text-primary">funcionam</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Conecte com as ferramentas que você já usa. API pública e webhooks completos para desenvolvedores.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {integrations.map((integration, i) => (
            <div
              key={i}
              className="flex items-center justify-between rounded-xl border border-border/50 bg-card/50 p-4 transition-all hover:border-primary/50 hover:bg-card"
            >
              <div>
                <div className="font-medium">{integration.name}</div>
                <div className="text-xs text-muted-foreground">{integration.category}</div>
              </div>
              <Badge
                variant={integration.status === "Nativo" ? "default" : "outline"}
                className={integration.status === "Nativo" ? "bg-primary text-primary-foreground" : ""}
              >
                {integration.status}
              </Badge>
            </div>
          ))}
        </div>

        <div className="mt-12 rounded-2xl border border-border/50 bg-card/50 p-8 text-center">
          <h3 className="text-xl font-semibold mb-2">API Pública & Webhooks</h3>
          <p className="text-muted-foreground mb-4">
            Documentação completa para desenvolvedores. Crie suas próprias integrações.
          </p>
          <Badge variant="outline" className="text-primary border-primary/50">
            Em breve
          </Badge>
        </div>
      </div>
    </section>
  )
}
