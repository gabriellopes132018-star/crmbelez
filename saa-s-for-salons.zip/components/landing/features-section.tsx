import { Calendar, CreditCard, MessageSquare, Users, FileText, BarChart3, Smartphone, Shield, Zap } from "lucide-react"

const features = [
  {
    icon: Calendar,
    title: "Agenda Inteligente",
    description: "Visualize em dia, semana ou mês. Agendamento online 24h com link personalizado para seus clientes.",
  },
  {
    icon: MessageSquare,
    title: "WhatsApp Nativo",
    description: "Lembretes automáticos, confirmações via bot e recuperação de faltas integrados ao WhatsApp Business.",
  },
  {
    icon: CreditCard,
    title: "Pagamentos Integrados",
    description: "Pagar.me, Mercado Pago, Stripe, PIX automático e boletos. Receba de qualquer forma.",
  },
  {
    icon: Users,
    title: "Gestão de Clientes",
    description: "Cadastro completo, histórico de procedimentos, fotos antes/depois e prontuário estético.",
  },
  {
    icon: FileText,
    title: "Prontuário Digital",
    description: "Anamnese completa, assinatura digital e histórico de todos os procedimentos realizados.",
  },
  {
    icon: BarChart3,
    title: "Dashboard & KPIs",
    description: "Métricas em tempo real, relatórios avançados e controle de metas por profissional.",
  },
  {
    icon: Smartphone,
    title: "Mobile First",
    description: "Acesse de qualquer lugar. App do cliente para agendamento, carteira e histórico.",
  },
  {
    icon: Shield,
    title: "LGPD Compliant",
    description: "Auditoria completa, consentimento, exclusão e portabilidade de dados garantidos.",
  },
  {
    icon: Zap,
    title: "Automação Total",
    description: "Pipelines de marketing, funis de vendas e mensagens pré-definidas automatizadas.",
  },
]

export function FeaturesSection() {
  return (
    <section id="funcionalidades" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h2 className="font-serif text-3xl font-bold tracking-tight sm:text-4xl">
            Tudo que você precisa em <span className="text-primary">um só lugar</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Do agendamento ao pós-atendimento, o EsthetiFlow cuida de cada detalhe para você focar no que importa: seus
            clientes.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <div
              key={i}
              className="group relative rounded-2xl border border-border/50 bg-card/50 p-6 transition-all hover:border-primary/50 hover:bg-card"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
