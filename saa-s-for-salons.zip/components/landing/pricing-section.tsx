import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check } from "lucide-react"
import Link from "next/link"

const plans = [
  {
    name: "Start",
    price: "79",
    description: "Para quem está começando",
    features: ["1 usuário", "Agenda completa", "Pagamentos online", "Lembretes simples", "Relatórios básicos"],
    cta: "Começar grátis",
    popular: false,
  },
  {
    name: "Pro",
    price: "199",
    description: "Para salões em crescimento",
    features: [
      "5 usuários",
      "WhatsApp Business API",
      "Prontuário completo",
      "Pacotes e planos",
      "PDV completo",
      "Estoque básico",
      "Relatórios avançados",
    ],
    cta: "Começar grátis",
    popular: true,
  },
  {
    name: "Master",
    price: "399",
    description: "Para clínicas completas",
    features: [
      "20 usuários",
      "Multi-unidades",
      "Automação completa",
      "Marketing avançado",
      "Análise de fotos por IA",
      "Teleconsulta",
      "Suporte prioritário",
    ],
    cta: "Começar grátis",
    popular: false,
  },
  {
    name: "Enterprise",
    price: "999",
    description: "Para franquias e redes",
    features: [
      "Usuários ilimitados",
      "SLA garantido",
      "API avançada",
      "Treinamento exclusivo",
      "Suporte dedicado",
      "White-label",
      "Customizações",
    ],
    cta: "Falar com vendas",
    popular: false,
  },
]

export function PricingSection() {
  return (
    <section id="precos" className="py-24 lg:py-32 bg-card/30">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h2 className="font-serif text-3xl font-bold tracking-tight sm:text-4xl">
            Planos para cada <span className="text-primary">momento</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Comece gratuitamente e escale conforme seu negócio cresce. Sem taxas ocultas.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {plans.map((plan, i) => (
            <div
              key={i}
              className={`relative rounded-2xl border p-6 flex flex-col ${
                plan.popular ? "border-primary bg-card shadow-lg shadow-primary/10" : "border-border/50 bg-card/50"
              }`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground">
                  Mais popular
                </Badge>
              )}

              <div className="mb-6">
                <h3 className="text-xl font-semibold">{plan.name}</h3>
                <p className="text-sm text-muted-foreground mt-1">{plan.description}</p>
              </div>

              <div className="mb-6">
                <span className="text-4xl font-bold">R$ {plan.price}</span>
                <span className="text-muted-foreground">/mês</span>
              </div>

              <ul className="space-y-3 mb-8 flex-1">
                {plan.features.map((feature, j) => (
                  <li key={j} className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-primary flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>

              <Button
                className={`w-full ${plan.popular ? "bg-primary text-primary-foreground hover:bg-primary/90" : ""}`}
                variant={plan.popular ? "default" : "outline"}
                asChild
              >
                <Link href="/registro">{plan.cta}</Link>
              </Button>
            </div>
          ))}
        </div>

        <p className="text-center text-sm text-muted-foreground mt-8">
          Todos os planos incluem 14 dias grátis. Sem cartão de crédito.
        </p>
      </div>
    </section>
  )
}
