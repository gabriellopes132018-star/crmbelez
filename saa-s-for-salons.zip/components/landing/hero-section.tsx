import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Play, Calendar, CreditCard, Users, TrendingUp } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden pt-32 pb-20 lg:pt-40 lg:pb-32">
      {/* Background effects */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-1/4 left-1/4 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 h-96 w-96 rounded-full bg-accent/10 blur-3xl" />
      </div>

      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-4xl text-center">
          <Badge variant="outline" className="mb-6 border-primary/30 text-primary">
            Novo: Análise de fotos por IA agora disponível
          </Badge>

          <h1 className="font-serif text-4xl font-bold tracking-tight sm:text-6xl lg:text-7xl text-balance">
            A Plataforma <span className="text-primary">Nº1</span> para Clínicas e Salões{" "}
            <span className="text-primary">Modernos</span>
          </h1>

          <p className="mt-6 text-lg leading-8 text-muted-foreground max-w-2xl mx-auto text-pretty">
            Agende. Atenda. Venda. Cresça. Tudo em um só sistema. Gerencie sua clínica de estética ou salão com a
            plataforma mais completa do mercado brasileiro.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 h-12 px-8 text-base"
              asChild
            >
              <Link href="/registro">
                Teste grátis por 14 dias
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="h-12 px-8 text-base bg-transparent" asChild>
              <Link href="#demo">
                <Play className="mr-2 h-4 w-4" />
                Ver demonstração
              </Link>
            </Button>
          </div>

          <p className="mt-4 text-sm text-muted-foreground">Sem cartão de crédito. Cancele quando quiser.</p>
        </div>

        {/* Dashboard Preview */}
        <div className="mt-16 relative">
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent z-10 pointer-events-none" />
          <div className="relative rounded-2xl border border-border/50 bg-card/50 backdrop-blur-sm overflow-hidden shadow-2xl">
            <div className="flex items-center gap-2 border-b border-border px-4 py-3">
              <div className="flex gap-1.5">
                <div className="h-3 w-3 rounded-full bg-red-500" />
                <div className="h-3 w-3 rounded-full bg-yellow-500" />
                <div className="h-3 w-3 rounded-full bg-green-500" />
              </div>
              <div className="flex-1 text-center">
                <span className="text-xs text-muted-foreground">app.esthetiflow.com.br</span>
              </div>
            </div>
            <div className="p-6 lg:p-8">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {[
                  { icon: Calendar, label: "Agendamentos Hoje", value: "24", change: "+12%" },
                  { icon: Users, label: "Novos Clientes", value: "156", change: "+8%" },
                  { icon: CreditCard, label: "Faturamento", value: "R$ 45.890", change: "+23%" },
                  { icon: TrendingUp, label: "Taxa de Retorno", value: "78%", change: "+5%" },
                ].map((stat, i) => (
                  <div key={i} className="rounded-xl bg-secondary/50 p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <stat.icon className="h-4 w-4 text-primary" />
                      <span className="text-xs text-muted-foreground">{stat.label}</span>
                    </div>
                    <div className="flex items-end justify-between">
                      <span className="text-2xl font-bold">{stat.value}</span>
                      <span className="text-xs text-green-500">{stat.change}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="grid lg:grid-cols-3 gap-4">
                <div className="lg:col-span-2 rounded-xl bg-secondary/30 p-4 h-48">
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-medium">Próximos Agendamentos</span>
                    <Badge variant="secondary">Hoje</Badge>
                  </div>
                  <div className="space-y-3">
                    {[
                      { time: "09:00", client: "Maria Silva", service: "Limpeza de Pele" },
                      { time: "10:30", client: "Ana Costa", service: "Massagem Relaxante" },
                      { time: "14:00", client: "Julia Santos", service: "Design de Sobrancelhas" },
                    ].map((apt, i) => (
                      <div key={i} className="flex items-center gap-4 text-sm">
                        <span className="text-primary font-mono">{apt.time}</span>
                        <span className="flex-1">{apt.client}</span>
                        <span className="text-muted-foreground">{apt.service}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="rounded-xl bg-secondary/30 p-4 h-48">
                  <span className="font-medium">Performance Semanal</span>
                  <div className="mt-4 space-y-3">
                    {[
                      { label: "Confirmados", value: 85 },
                      { label: "Concluídos", value: 92 },
                      { label: "Satisfação", value: 98 },
                    ].map((item, i) => (
                      <div key={i}>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-muted-foreground">{item.label}</span>
                          <span>{item.value}%</span>
                        </div>
                        <div className="h-2 rounded-full bg-secondary">
                          <div className="h-full rounded-full bg-primary" style={{ width: `${item.value}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
