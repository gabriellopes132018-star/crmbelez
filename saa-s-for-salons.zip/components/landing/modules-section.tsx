"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { Calendar, Users, CreditCard, FileText, Package, BarChart3, Megaphone, Video, Brain } from "lucide-react"

const modules = [
  {
    id: "agenda",
    icon: Calendar,
    title: "Agenda Completa",
    badge: "MVP",
    description:
      "Sistema de agendamento completo com visualização em dia, semana e mês. Agendamento online 24h com link personalizado.",
    features: ["Day/Week/Month view", "Agendamento online 24h", "Link personalizado", "Confirmação automática"],
  },
  {
    id: "clientes",
    icon: Users,
    title: "Gestão de Clientes",
    badge: "MVP",
    description: "Cadastro completo com histórico, prontuário estético, fotos antes/depois e anamnese digital.",
    features: ["Histórico completo", "Fotos antes/depois", "Anamnese digital", "Assinatura digital"],
  },
  {
    id: "financeiro",
    icon: CreditCard,
    title: "Financeiro",
    badge: "Core",
    description: "Controle financeiro completo com fluxo de caixa, contas a pagar/receber, boletos e PIX automático.",
    features: ["PDV completo", "Fluxo de caixa", "Boletos e PIX", "Multi-unidades"],
  },
  {
    id: "prontuario",
    icon: FileText,
    title: "Prontuário Estético",
    badge: "Core",
    description:
      "Prontuário digital completo com anamnese, fotos antes/depois, slider comparativo e histórico de procedimentos.",
    features: ["Anamnese completa", "Slider antes/depois", "Histórico digital", "Assinatura tablet"],
  },
  {
    id: "estoque",
    icon: Package,
    title: "Estoque & Produtos",
    badge: "Avançado",
    description: "Controle avançado de estoque com validação, fornecedores, compras e marketplace de produtos.",
    features: ["Controle avançado", "Fornecedores", "Loja online", "Marketplace"],
  },
  {
    id: "relatorios",
    icon: BarChart3,
    title: "Relatórios & KPIs",
    badge: "Core",
    description: "Dashboard inteligente com KPIs principais, metas por profissional e análise de performance.",
    features: ["Dashboard BI", "Metas individuais", "Comissões", "Analytics"],
  },
  {
    id: "marketing",
    icon: Megaphone,
    title: "Marketing",
    badge: "Core",
    description: "Módulo completo de marketing com campanhas, funis, mensagens pré-definidas e automação.",
    features: ["Campanhas", "Funis de vendas", "Automação", "Instagram DM"],
  },
  {
    id: "telecon",
    icon: Video,
    title: "Teleconsulta",
    badge: "Avançado",
    description: "Teleatendimento e videoconsulta integrada para avaliações e acompanhamentos remotos.",
    features: ["Videochamada HD", "Gravação", "Compartilhamento", "Agendamento"],
  },
  {
    id: "ia",
    icon: Brain,
    title: "Inteligência Artificial",
    badge: "Avançado",
    description: "Análise automática de fotos, ML para previsão de no-show e sugestão de melhor horário.",
    features: ["Análise de fotos", "Previsão no-show", "Melhor horário", "Recomendações"],
  },
]

export function ModulesSection() {
  const [activeModule, setActiveModule] = useState(modules[0])

  return (
    <section id="modulos" className="py-24 lg:py-32 bg-card/30">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h2 className="font-serif text-3xl font-bold tracking-tight sm:text-4xl">
            Módulos <span className="text-primary">poderosos</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Do básico ao avançado, escolha os módulos que fazem sentido para o seu negócio.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-2">
            {modules.map((module) => (
              <button
                key={module.id}
                onClick={() => setActiveModule(module)}
                className={cn(
                  "w-full flex items-center gap-3 rounded-xl p-4 text-left transition-all",
                  activeModule.id === module.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-card/50 hover:bg-card text-foreground",
                )}
              >
                <module.icon className="h-5 w-5 flex-shrink-0" />
                <span className="font-medium">{module.title}</span>
                <Badge variant={activeModule.id === module.id ? "secondary" : "outline"} className="ml-auto text-xs">
                  {module.badge}
                </Badge>
              </button>
            ))}
          </div>

          <div className="lg:col-span-2">
            <div className="rounded-2xl border border-border/50 bg-card p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                  <activeModule.icon className="h-7 w-7" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">{activeModule.title}</h3>
                  <Badge variant="outline" className="mt-1">
                    {activeModule.badge}
                  </Badge>
                </div>
              </div>

              <p className="text-muted-foreground mb-6 leading-relaxed">{activeModule.description}</p>

              <div className="grid sm:grid-cols-2 gap-3">
                {activeModule.features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                    {feature}
                  </div>
                ))}
              </div>

              <div className="mt-8 rounded-xl bg-secondary/50 p-4">
                <div className="aspect-video rounded-lg bg-background/50 flex items-center justify-center">
                  <span className="text-muted-foreground">Preview do módulo {activeModule.title}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
