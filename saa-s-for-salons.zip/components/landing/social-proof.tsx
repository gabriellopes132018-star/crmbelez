export function SocialProof() {
  const stats = [
    { value: "5.000+", label: "Clínicas e Salões" },
    { value: "2M+", label: "Agendamentos/mês" },
    { value: "R$ 500M+", label: "Processados/ano" },
    { value: "98%", label: "Satisfação" },
  ]

  const logos = ["Studio Bella", "Espaço Zen", "Beauty Center", "Clínica Derma", "Spa Essence", "Nail Art Pro"]

  return (
    <section className="border-y border-border/50 bg-card/30 py-12">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {stats.map((stat, i) => (
            <div key={i} className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-primary">{stat.value}</div>
              <div className="mt-1 text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="flex flex-col items-center">
          <p className="text-sm text-muted-foreground mb-6">Utilizado por clínicas e salões de todo o Brasil</p>
          <div className="flex flex-wrap justify-center gap-x-12 gap-y-4">
            {logos.map((logo, i) => (
              <span
                key={i}
                className="text-lg font-medium text-muted-foreground/60 hover:text-muted-foreground transition-colors"
              >
                {logo}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
