import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles } from "lucide-react"

export function CTASection() {
  return (
    <section className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-primary px-6 py-20 sm:px-12 sm:py-28">
          {/* Background decoration */}
          <div className="absolute inset-0 -z-10">
            <div className="absolute top-0 right-0 h-96 w-96 rounded-full bg-white/10 blur-3xl" />
            <div className="absolute bottom-0 left-0 h-96 w-96 rounded-full bg-black/10 blur-3xl" />
          </div>

          <div className="mx-auto max-w-2xl text-center">
            <div className="flex justify-center mb-6">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20">
                <Sparkles className="h-8 w-8 text-white" />
              </div>
            </div>

            <h2 className="font-serif text-3xl font-bold tracking-tight text-primary-foreground sm:text-4xl">
              Pronto para transformar seu negócio?
            </h2>

            <p className="mt-4 text-lg text-primary-foreground/80">
              Junte-se a mais de 5.000 clínicas e salões que já usam o EsthetiFlow. Comece seu teste grátis de 14 dias
              hoje mesmo.
            </p>

            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 h-12 px-8 text-base" asChild>
                <Link href="/registro">
                  Começar teste grátis
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 h-12 px-8 text-base bg-transparent"
                asChild
              >
                <Link href="#demo">Ver demonstração</Link>
              </Button>
            </div>

            <p className="mt-4 text-sm text-primary-foreground/60">Sem cartão de crédito • Cancele quando quiser</p>
          </div>
        </div>
      </div>
    </section>
  )
}
