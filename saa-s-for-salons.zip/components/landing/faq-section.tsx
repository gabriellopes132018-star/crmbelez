import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  {
    question: "Posso testar antes de assinar?",
    answer:
      "Sim! Oferecemos 14 dias de teste grátis em todos os planos, sem necessidade de cartão de crédito. Você pode explorar todas as funcionalidades antes de decidir.",
  },
  {
    question: "Como funciona a integração com WhatsApp?",
    answer:
      "Utilizamos a API oficial do WhatsApp Business. Você conecta seu número e nosso sistema envia automaticamente lembretes, confirmações e mensagens de pós-atendimento para seus clientes.",
  },
  {
    question: "Posso migrar meus dados de outro sistema?",
    answer:
      "Claro! Nossa equipe de sucesso do cliente auxilia na migração gratuita dos seus dados. Importamos clientes, histórico e agendamentos do seu sistema anterior.",
  },
  {
    question: "O sistema funciona em celular e tablet?",
    answer:
      "Sim! O EsthetiFlow é 100% responsivo e funciona perfeitamente em qualquer dispositivo. Além disso, oferecemos um app mobile para seus clientes agendarem online.",
  },
  {
    question: "Como funciona o suporte?",
    answer:
      "Oferecemos suporte por chat e WhatsApp em horário comercial para todos os planos. Planos Master e Enterprise têm acesso a suporte prioritário e videochamadas com especialistas.",
  },
  {
    question: "Posso cancelar a qualquer momento?",
    answer:
      "Sim, não há fidelidade. Você pode cancelar sua assinatura quando quiser, sem multas ou taxas adicionais. Seus dados ficam disponíveis para exportação por 30 dias.",
  },
  {
    question: "O sistema emite nota fiscal?",
    answer:
      "Sim! Temos integração nativa com os principais sistemas de emissão de NFS-e do Brasil. Configure uma vez e as notas são emitidas automaticamente.",
  },
  {
    question: "Vocês estão em conformidade com a LGPD?",
    answer:
      "Absolutamente! O EsthetiFlow foi desenvolvido com a LGPD em mente. Oferecemos consentimento, exclusão e portabilidade de dados, além de logs completos de auditoria.",
  },
]

export function FAQSection() {
  return (
    <section id="faq" className="py-24 lg:py-32 bg-card/30">
      <div className="mx-auto max-w-3xl px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-serif text-3xl font-bold tracking-tight sm:text-4xl">
            Perguntas <span className="text-primary">frequentes</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">Tudo que você precisa saber sobre o EsthetiFlow.</p>
        </div>

        <Accordion type="single" collapsible className="space-y-4">
          {faqs.map((faq, i) => (
            <AccordionItem
              key={i}
              value={`item-${i}`}
              className="rounded-xl border border-border/50 bg-card/50 px-6 data-[state=open]:border-primary/50"
            >
              <AccordionTrigger className="text-left hover:no-underline py-4">{faq.question}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-4">{faq.answer}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  )
}
