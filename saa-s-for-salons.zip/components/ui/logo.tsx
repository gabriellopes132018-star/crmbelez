import { cn } from "@/lib/utils"
import { Sparkles } from "lucide-react"

interface LogoProps {
  className?: string
  iconOnly?: boolean
  size?: "sm" | "md" | "lg"
}

export function Logo({ className, iconOnly = false, size = "md" }: LogoProps) {
  const sizes = {
    sm: { icon: "h-8 w-8", iconInner: "h-4 w-4", text: "text-lg" },
    md: { icon: "h-10 w-10", iconInner: "h-5 w-5", text: "text-xl" },
    lg: { icon: "h-14 w-14", iconInner: "h-7 w-7", text: "text-2xl" },
  }

  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <div
        className={cn(
          "relative flex items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary/80 shadow-lg glow-primary",
          sizes[size].icon,
        )}
      >
        <Sparkles className={cn("text-primary-foreground", sizes[size].iconInner)} />
        <div className="absolute inset-0 rounded-xl bg-gradient-to-t from-black/10 to-white/10" />
      </div>
      {!iconOnly && (
        <span className={cn("font-semibold tracking-tight", sizes[size].text)}>
          Estheti<span className="gradient-text">Flow</span>
        </span>
      )}
    </div>
  )
}
