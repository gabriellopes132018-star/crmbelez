import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { ArrowUpRight, ArrowDownRight, type LucideIcon } from "lucide-react"

interface StatCardProps {
  title: string
  value: string
  change?: string
  trend?: "up" | "down" | "neutral"
  description?: string
  icon: LucideIcon
  className?: string
}

export function StatCard({
  title,
  value,
  change,
  trend = "neutral",
  description,
  icon: Icon,
  className,
}: StatCardProps) {
  return (
    <Card
      className={cn(
        "group relative overflow-hidden border-border/50 bg-card/80 backdrop-blur-sm transition-all duration-300 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5",
        className,
      )}
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center transition-transform group-hover:scale-110">
            <Icon className="h-6 w-6 text-primary" />
          </div>
          {change && (
            <div
              className={cn(
                "flex items-center gap-1 text-sm font-semibold px-2 py-1 rounded-full",
                trend === "up" && "text-success bg-success/10",
                trend === "down" && "text-destructive bg-destructive/10",
                trend === "neutral" && "text-muted-foreground bg-muted",
              )}
            >
              {change}
              {trend === "up" && <ArrowUpRight className="h-3.5 w-3.5" />}
              {trend === "down" && <ArrowDownRight className="h-3.5 w-3.5" />}
            </div>
          )}
        </div>
        <div className="space-y-1">
          <h3 className="text-3xl font-bold tracking-tight">{value}</h3>
          <p className="text-sm font-medium text-foreground/80">{title}</p>
          {description && <p className="text-xs text-muted-foreground">{description}</p>}
        </div>
        {/* Decorative gradient */}
        <div className="absolute -bottom-10 -right-10 h-32 w-32 rounded-full bg-primary/5 blur-2xl transition-opacity group-hover:opacity-100 opacity-0" />
      </CardContent>
    </Card>
  )
}
