import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Download, Eye, ArrowUpCircle, ArrowDownCircle, ShoppingCart } from "lucide-react"

const transactions = [
  {
    id: "V001",
    time: "09:15",
    client: "Maria Silva",
    items: ["Limpeza de Pele", "Protetor Solar"],
    total: "R$ 269,90",
    method: "PIX",
    type: "sale",
    professional: "Dra. Ana",
  },
  {
    id: "V002",
    time: "10:30",
    client: "Ana Costa",
    items: ["Massagem Relaxante"],
    total: "R$ 220,00",
    method: "Cartão Crédito",
    type: "sale",
    professional: "Carla",
  },
  {
    id: "S001",
    time: "11:00",
    client: "-",
    items: ["Sangria"],
    total: "R$ 500,00",
    method: "Dinheiro",
    type: "withdrawal",
    professional: "Maria Costa",
  },
  {
    id: "V003",
    time: "11:45",
    client: "Julia Santos",
    items: ["Design Sobrancelhas"],
    total: "R$ 80,00",
    method: "Dinheiro",
    type: "sale",
    professional: "Paula",
  },
  {
    id: "V004",
    time: "14:00",
    client: "Fernanda Oliveira",
    items: ["Tratamento Facial", "Sérum Vitamina C"],
    total: "R$ 420,00",
    method: "PIX",
    type: "sale",
    professional: "Dra. Ana",
  },
  {
    id: "SUP001",
    time: "14:30",
    client: "-",
    items: ["Suprimento"],
    total: "R$ 200,00",
    method: "Dinheiro",
    type: "deposit",
    professional: "Maria Costa",
  },
]

const typeConfig = {
  sale: { label: "Venda", icon: ShoppingCart, color: "text-green-500", bgColor: "bg-green-500/10" },
  withdrawal: { label: "Sangria", icon: ArrowDownCircle, color: "text-red-500", bgColor: "bg-red-500/10" },
  deposit: { label: "Suprimento", icon: ArrowUpCircle, color: "text-blue-500", bgColor: "bg-blue-500/10" },
}

export function TransactionsList() {
  return (
    <Card className="border-border/50">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg">Movimentações do Dia</CardTitle>
        <div className="flex items-center gap-2">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Buscar..." className="pl-10" />
          </div>
          <Select defaultValue="all">
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="sale">Vendas</SelectItem>
              <SelectItem value="withdrawal">Sangrias</SelectItem>
              <SelectItem value="deposit">Suprimentos</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {transactions.map((tx) => {
            const config = typeConfig[tx.type as keyof typeof typeConfig]
            const Icon = config.icon
            return (
              <div
                key={tx.id}
                className="flex items-center gap-4 p-4 bg-secondary/30 rounded-xl hover:bg-secondary/50 transition-colors"
              >
                <div className={`h-10 w-10 rounded-lg ${config.bgColor} flex items-center justify-center`}>
                  <Icon className={`h-5 w-5 ${config.color}`} />
                </div>

                <div className="min-w-[60px]">
                  <div className="font-mono text-sm">{tx.time}</div>
                  <div className="text-xs text-muted-foreground">{tx.id}</div>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="font-medium">{tx.client}</div>
                  <div className="text-sm text-muted-foreground truncate">{tx.items.join(", ")}</div>
                </div>

                <div className="text-sm text-muted-foreground">{tx.professional}</div>

                <Badge variant="outline">{tx.method}</Badge>

                <div
                  className={`font-bold min-w-[100px] text-right ${
                    tx.type === "withdrawal"
                      ? "text-red-500"
                      : tx.type === "deposit"
                        ? "text-blue-500"
                        : "text-green-500"
                  }`}
                >
                  {tx.type === "withdrawal" ? "-" : tx.type === "deposit" ? "+" : ""}
                  {tx.total}
                </div>

                <Button variant="ghost" size="icon">
                  <Eye className="h-4 w-4" />
                </Button>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
