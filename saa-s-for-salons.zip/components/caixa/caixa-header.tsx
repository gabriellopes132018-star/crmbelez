import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, ArrowDownCircle, ArrowUpCircle, FileText } from "lucide-react"

export function CaixaHeader() {
  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div>
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold tracking-tight">Caixa & PDV</h1>
          <Badge className="bg-green-500/20 text-green-500 border-green-500/50">Aberto</Badge>
        </div>
        <p className="text-muted-foreground">Aberto às 08:00 por Maria Costa</p>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm">
          <ArrowDownCircle className="h-4 w-4 mr-2" />
          Sangria
        </Button>
        <Button variant="outline" size="sm">
          <ArrowUpCircle className="h-4 w-4 mr-2" />
          Suprimento
        </Button>
        <Button variant="outline" size="sm">
          <FileText className="h-4 w-4 mr-2" />
          Relatório
        </Button>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Plus className="h-4 w-4 mr-2" />
          Nova Venda
        </Button>
      </div>
    </div>
  )
}
