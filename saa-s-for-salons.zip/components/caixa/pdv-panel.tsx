"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Search, Plus, Minus, User, Percent, CreditCard, Banknote, QrCode, FileText, X } from "lucide-react"
import { cn } from "@/lib/utils"

const services = [
  { id: 1, name: "Limpeza de Pele", price: 180, category: "Facial" },
  { id: 2, name: "Massagem Relaxante", price: 220, category: "Corporal" },
  { id: 3, name: "Design Sobrancelhas", price: 80, category: "Sobrancelhas" },
  { id: 4, name: "Peeling Químico", price: 250, category: "Facial" },
  { id: 5, name: "Tratamento Facial", price: 300, category: "Facial" },
  { id: 6, name: "Depilação Completa", price: 150, category: "Depilação" },
  { id: 7, name: "Manicure + Pedicure", price: 90, category: "Unhas" },
  { id: 8, name: "Hidratação Capilar", price: 120, category: "Cabelo" },
]

const products = [
  { id: 101, name: "Protetor Solar FPS 50", price: 89.9, category: "Produto" },
  { id: 102, name: "Creme Hidratante", price: 65.0, category: "Produto" },
  { id: 103, name: "Sérum Vitamina C", price: 120.0, category: "Produto" },
]

const paymentMethods = [
  { id: "pix", name: "PIX", icon: QrCode },
  { id: "credit", name: "Crédito", icon: CreditCard },
  { id: "debit", name: "Débito", icon: CreditCard },
  { id: "cash", name: "Dinheiro", icon: Banknote },
  { id: "boleto", name: "Boleto", icon: FileText },
]

interface CartItem {
  id: number
  name: string
  price: number
  quantity: number
}

export function PDVPanel() {
  const [cart, setCart] = useState<CartItem[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPayment, setSelectedPayment] = useState<string | null>(null)
  const [discount, setDiscount] = useState(0)

  const allItems = [...services, ...products]
  const filteredItems = allItems.filter((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()))

  const addToCart = (item: (typeof allItems)[0]) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === item.id)
      if (existing) {
        return prev.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i))
      }
      return [...prev, { ...item, quantity: 1 }]
    })
  }

  const updateQuantity = (id: number, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => (item.id === id ? { ...item, quantity: Math.max(0, item.quantity + delta) } : item))
        .filter((item) => item.quantity > 0),
    )
  }

  const removeFromCart = (id: number) => {
    setCart((prev) => prev.filter((item) => item.id !== id))
  }

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const discountValue = (subtotal * discount) / 100
  const total = subtotal - discountValue

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      {/* Products/Services Grid */}
      <div className="lg:col-span-2 space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar serviços ou produtos..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
          {filteredItems.map((item) => (
            <Card
              key={item.id}
              className="border-border/50 cursor-pointer hover:border-primary/50 hover:bg-secondary/30 transition-all"
              onClick={() => addToCart(item)}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{item.name}</div>
                    <Badge variant="outline" className="mt-1 text-xs">
                      {item.category}
                    </Badge>
                  </div>
                  <div className="text-primary font-bold">R$ {item.price.toFixed(2).replace(".", ",")}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Cart */}
      <div>
        <Card className="border-border/50 sticky top-24">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Carrinho</CardTitle>
              <Button variant="ghost" size="sm" className="text-muted-foreground">
                <User className="h-4 w-4 mr-2" />
                Selecionar Cliente
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Cart Items */}
            <div className="space-y-3 max-h-[300px] overflow-auto">
              {cart.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">Carrinho vazio</div>
              ) : (
                cart.map((item) => (
                  <div key={item.id} className="flex items-center gap-3 p-3 bg-secondary/30 rounded-lg">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">{item.name}</div>
                      <div className="text-xs text-muted-foreground">
                        R$ {item.price.toFixed(2).replace(".", ",")} cada
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-7 w-7 bg-transparent"
                        onClick={() => updateQuantity(item.id, -1)}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-6 text-center font-medium">{item.quantity}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-7 w-7 bg-transparent"
                        onClick={() => updateQuantity(item.id, 1)}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="text-right min-w-[80px]">
                      <div className="font-medium">R$ {(item.price * item.quantity).toFixed(2).replace(".", ",")}</div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-destructive"
                      onClick={() => removeFromCart(item.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))
              )}
            </div>

            <Separator />

            {/* Discount */}
            <div className="flex items-center gap-2">
              <Percent className="h-4 w-4 text-muted-foreground" />
              <Input
                type="number"
                placeholder="Desconto %"
                className="w-24"
                value={discount || ""}
                onChange={(e) => setDiscount(Number(e.target.value))}
              />
              <span className="text-sm text-muted-foreground">- R$ {discountValue.toFixed(2).replace(".", ",")}</span>
            </div>

            {/* Totals */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span>R$ {subtotal.toFixed(2).replace(".", ",")}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-sm text-green-500">
                  <span>Desconto ({discount}%)</span>
                  <span>- R$ {discountValue.toFixed(2).replace(".", ",")}</span>
                </div>
              )}
              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span className="text-primary">R$ {total.toFixed(2).replace(".", ",")}</span>
              </div>
            </div>

            <Separator />

            {/* Payment Methods */}
            <div className="space-y-2">
              <div className="text-sm font-medium">Forma de Pagamento</div>
              <div className="grid grid-cols-3 gap-2">
                {paymentMethods.map((method) => (
                  <Button
                    key={method.id}
                    variant={selectedPayment === method.id ? "default" : "outline"}
                    size="sm"
                    className={cn(
                      "flex-col h-auto py-3",
                      selectedPayment === method.id && "bg-primary text-primary-foreground",
                    )}
                    onClick={() => setSelectedPayment(method.id)}
                  >
                    <method.icon className="h-5 w-5 mb-1" />
                    <span className="text-xs">{method.name}</span>
                  </Button>
                ))}
              </div>
            </div>

            {/* Finalize */}
            <Button
              className="w-full h-12 text-lg bg-primary text-primary-foreground hover:bg-primary/90"
              disabled={cart.length === 0 || !selectedPayment}
            >
              Finalizar Venda
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
