import { Card, CardContent } from "@/components/ui/card"
import { DollarSign, TrendingUp, CreditCard, Banknote, ArrowUpRight, ArrowDownRight } from "lucide-react"

const stats = [
  {
    title: "Vendas Hoje",
    value: "R$ 8.630,00",
    change: "+18%",
    trend: "up",
    icon: DollarSign,
  },
  {
    title: "Ticket Médio",
    value: "R$ 215,75",
    change: "+5%",
    trend: "up",
    icon: TrendingUp,
  },
  {
    title: "Vendas (Qtd)",
    value: "40",
    change: "+12%",
    trend: "up",
    icon: CreditCard,
  },
  {
    title: "Dinheiro em Caixa",
    value: "R$ 1.450,00",
    change: null,
    trend: null,
    icon: Banknote,
  },
]

export function CaixaSummary() {
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, i) => (
        <Card key={i} className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <stat.icon className="h-5 w-5 text-primary" />
              </div>
              {stat.change && (
                <div
                  className={`flex items-center gap-1 text-sm font-medium ${
                    stat.trend === "up" ? "text-green-500" : "text-red-500"
                  }`}
                >
                  {stat.change}
                  {stat.trend === "up" ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
                </div>
              )}
            </div>
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="text-sm text-muted-foreground">{stat.title}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
