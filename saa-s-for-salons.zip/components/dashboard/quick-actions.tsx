import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, UserPlus, CreditCard, MessageSquare, FileText, Package } from "lucide-react"
import Link from "next/link"

const actions = [
  { icon: Calendar, label: "Novo Agendamento", href: "/dashboard/agenda/novo", color: "bg-blue-500/10 text-blue-500" },
  { icon: UserPlus, label: "Novo Cliente", href: "/dashboard/clientes/novo", color: "bg-green-500/10 text-green-500" },
  { icon: CreditCard, label: "Nova Venda", href: "/dashboard/caixa/venda", color: "bg-purple-500/10 text-purple-500" },
  {
    icon: MessageSquare,
    label: "Enviar Mensagem",
    href: "/dashboard/marketing/mensagem",
    color: "bg-orange-500/10 text-orange-500",
  },
  {
    icon: FileText,
    label: "Novo Prontuário",
    href: "/dashboard/prontuarios/novo",
    color: "bg-pink-500/10 text-pink-500",
  },
  {
    icon: Package,
    label: "Entrada Estoque",
    href: "/dashboard/estoque/entrada",
    color: "bg-cyan-500/10 text-cyan-500",
  },
]

export function QuickActions() {
  return (
    <Card className="bg-card border-border/50">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold">Ações Rápidas</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-2">
          {actions.map((action, i) => (
            <Button
              key={i}
              variant="outline"
              className="h-auto flex-col gap-2 py-4 border-border/50 hover:bg-secondary/50 bg-transparent"
              asChild
            >
              <Link href={action.href}>
                <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${action.color}`}>
                  <action.icon className="h-5 w-5" />
                </div>
                <span className="text-xs text-center">{action.label}</span>
              </Link>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
