import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MoreHorizontal, Phone } from "lucide-react"

const clients = [
  {
    id: 1,
    name: "Maria Silva",
    email: "maria@email.com",
    phone: "(11) 99999-0001",
    visits: 12,
    lastVisit: "Hoje",
    totalSpent: "R$ 2.450",
    avatar: "MS",
  },
  {
    id: 2,
    name: "Ana Costa",
    email: "ana@email.com",
    phone: "(11) 99999-0002",
    visits: 8,
    lastVisit: "Ontem",
    totalSpent: "R$ 1.890",
    avatar: "AC",
  },
  {
    id: 3,
    name: "Julia Santos",
    email: "julia@email.com",
    phone: "(11) 99999-0003",
    visits: 5,
    lastVisit: "3 dias",
    totalSpent: "R$ 980",
    avatar: "JS",
  },
  {
    id: 4,
    name: "Fernanda Oliveira",
    email: "fernanda@email.com",
    phone: "(11) 99999-0004",
    visits: 15,
    lastVisit: "1 semana",
    totalSpent: "R$ 4.200",
    avatar: "FO",
  },
]

export function RecentClients() {
  return (
    <Card className="bg-card border-border/50">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold">Clientes Recentes</CardTitle>
        <Button variant="ghost" size="sm">
          Ver todos
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {clients.map((client) => (
            <div
              key={client.id}
              className="flex items-center gap-4 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
            >
              <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-medium text-primary">{client.avatar}</span>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium">{client.name}</span>
                  <Badge variant="outline" className="text-xs">
                    {client.visits} visitas
                  </Badge>
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Phone className="h-3 w-3" />
                    {client.phone}
                  </span>
                  <span>Última: {client.lastVisit}</span>
                </div>
              </div>

              <div className="text-right flex-shrink-0">
                <div className="font-medium text-primary">{client.totalSpent}</div>
                <div className="text-xs text-muted-foreground">total gasto</div>
              </div>

              <Button variant="ghost" size="icon" className="flex-shrink-0">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
