import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, AlertTriangle, CheckCircle, MessageSquare } from "lucide-react"

const notifications = [
  {
    id: 1,
    type: "appointment",
    title: "Novo agendamento",
    message: "Maria Silva agendou para amanhã às 14:00",
    time: "2 min",
    icon: Calendar,
    color: "text-blue-500",
  },
  {
    id: 2,
    type: "alert",
    title: "Confirmação pendente",
    message: "3 clientes ainda não confirmaram",
    time: "1h",
    icon: AlertTriangle,
    color: "text-yellow-500",
  },
  {
    id: 3,
    type: "success",
    title: "Pagamento recebido",
    message: "R$ 350,00 de Ana Costa",
    time: "2h",
    icon: CheckCircle,
    color: "text-green-500",
  },
  {
    id: 4,
    type: "message",
    title: "Nova mensagem",
    message: "Julia perguntou sobre disponibilidade",
    time: "3h",
    icon: MessageSquare,
    color: "text-purple-500",
  },
]

export function NotificationsPanel() {
  return (
    <Card className="bg-card border-border/50">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold">Notificações</CardTitle>
        <Badge variant="outline" className="bg-primary/10 text-primary border-0">
          {notifications.length} novas
        </Badge>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              className="flex items-start gap-3 p-2 rounded-lg hover:bg-secondary/30 transition-colors cursor-pointer"
            >
              <div className={`mt-0.5 ${notif.color}`}>
                <notif.icon className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-medium truncate">{notif.title}</span>
                  <span className="text-xs text-muted-foreground flex-shrink-0">{notif.time}</span>
                </div>
                <p className="text-xs text-muted-foreground truncate">{notif.message}</p>
              </div>
            </div>
          ))}
        </div>
        <Button variant="ghost" className="w-full mt-4 text-primary">
          Ver todas as notificações
        </Button>
      </CardContent>
    </Card>
  )
}
