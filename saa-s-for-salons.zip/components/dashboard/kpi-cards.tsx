import { Card, CardContent } from "@/components/ui/card"
import { Calendar, Users, CreditCard, TrendingUp, ArrowUpRight, ArrowDownRight } from "lucide-react"

const kpis = [
  {
    title: "Agendamentos Hoje",
    value: "24",
    change: "+12%",
    trend: "up",
    icon: Calendar,
    description: "vs. semana passada",
  },
  {
    title: "Novos Clientes",
    value: "156",
    change: "+8%",
    trend: "up",
    icon: Users,
    description: "este mês",
  },
  {
    title: "Faturamento",
    value: "R$ 45.890",
    change: "+23%",
    trend: "up",
    icon: CreditCard,
    description: "este mês",
  },
  {
    title: "Taxa de Retorno",
    value: "78%",
    change: "-2%",
    trend: "down",
    icon: TrendingUp,
    description: "últimos 30 dias",
  },
]

export function KPICards() {
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {kpis.map((kpi, i) => (
        <Card key={i} className="bg-card border-border/50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <kpi.icon className="h-5 w-5 text-primary" />
              </div>
              <div
                className={`flex items-center gap-1 text-sm font-medium ${
                  kpi.trend === "up" ? "text-green-500" : "text-red-500"
                }`}
              >
                {kpi.change}
                {kpi.trend === "up" ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
              </div>
            </div>
            <div className="space-y-1">
              <h3 className="text-2xl font-bold">{kpi.value}</h3>
              <p className="text-sm text-muted-foreground">{kpi.title}</p>
              <p className="text-xs text-muted-foreground/70">{kpi.description}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
