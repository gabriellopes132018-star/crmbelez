"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Sparkles,
  LayoutDashboard,
  Calendar,
  Users,
  CreditCard,
  FileText,
  Package,
  BarChart3,
  Megaphone,
  Settings,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
  Building2,
  Video,
  Brain,
  LogOut,
} from "lucide-react"

const navigation = [
  {
    title: "Principal",
    items: [
      { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
      { name: "Agenda", href: "/dashboard/agenda", icon: Calendar, badge: "12" },
      { name: "Clientes", href: "/dashboard/clientes", icon: Users },
    ],
  },
  {
    title: "Gestão",
    items: [
      { name: "Caixa & PDV", href: "/dashboard/caixa", icon: CreditCard },
      { name: "Prontuários", href: "/dashboard/prontuarios", icon: FileText },
      { name: "Estoque", href: "/dashboard/estoque", icon: Package },
      { name: "Financeiro", href: "/dashboard/financeiro", icon: BarChart3 },
    ],
  },
  {
    title: "Marketing",
    items: [
      { name: "Campanhas", href: "/dashboard/marketing", icon: Megaphone },
      { name: "Teleconsulta", href: "/dashboard/teleconsulta", icon: Video, badge: "Novo" },
      { name: "IA & Análises", href: "/dashboard/ia", icon: Brain, badge: "Beta" },
    ],
  },
  {
    title: "Configurações",
    items: [
      { name: "Unidades", href: "/dashboard/unidades", icon: Building2 },
      { name: "Configurações", href: "/dashboard/configuracoes", icon: Settings },
      { name: "Ajuda", href: "/dashboard/ajuda", icon: HelpCircle },
    ],
  },
]

export function DashboardSidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)
  const { user, logout } = useAuth()

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={cn(
          "fixed left-0 top-0 z-40 hidden h-screen border-r border-sidebar-border bg-sidebar-background transition-all duration-300 lg:block",
          collapsed ? "w-20" : "w-72",
        )}
      >
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="flex h-16 items-center justify-between border-b border-sidebar-border px-4">
            <Link href="/dashboard" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sidebar-primary">
                <Sparkles className="h-5 w-5 text-sidebar-primary-foreground" />
              </div>
              {!collapsed && (
                <span className="text-lg font-semibold text-sidebar-foreground">
                  Estheti<span className="text-sidebar-primary">Flow</span>
                </span>
              )}
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-sidebar-foreground hover:bg-sidebar-accent"
              onClick={() => setCollapsed(!collapsed)}
            >
              {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
            </Button>
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 px-3 py-4">
            <nav className="space-y-6">
              {navigation.map((section) => (
                <div key={section.title}>
                  {!collapsed && (
                    <h3 className="mb-2 px-3 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/50">
                      {section.title}
                    </h3>
                  )}
                  <div className="space-y-1">
                    {section.items.map((item) => {
                      const isActive = pathname === item.href
                      return (
                        <Link
                          key={item.name}
                          href={item.href}
                          className={cn(
                            "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                            isActive
                              ? "bg-sidebar-primary text-sidebar-primary-foreground"
                              : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground",
                          )}
                        >
                          <item.icon className="h-5 w-5 flex-shrink-0" />
                          {!collapsed && (
                            <>
                              <span className="flex-1">{item.name}</span>
                              {item.badge && (
                                <Badge
                                  variant={isActive ? "secondary" : "outline"}
                                  className={cn("text-xs", isActive && "bg-white/20 text-white border-0")}
                                >
                                  {item.badge}
                                </Badge>
                              )}
                            </>
                          )}
                        </Link>
                      )
                    })}
                  </div>
                </div>
              ))}
            </nav>
          </ScrollArea>

          {/* User Section - Dados dinâmicos do usuário e logout funcional */}
          <div className="border-t border-sidebar-border p-4">
            <div className={cn("flex items-center gap-3", collapsed && "justify-center")}>
              <div className="h-10 w-10 rounded-full bg-sidebar-primary/20 flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-medium text-sidebar-primary">
                  {user?.name
                    ?.split(" ")
                    .map((n) => n[0])
                    .join("")
                    .slice(0, 2)
                    .toUpperCase() || "US"}
                </span>
              </div>
              {!collapsed && (
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-sidebar-foreground truncate">{user?.name || "Usuário"}</p>
                  <p className="text-xs text-sidebar-foreground/50 truncate">{user?.clinic?.name || "Minha Clínica"}</p>
                </div>
              )}
              {!collapsed && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-sidebar-foreground/50 hover:text-sidebar-foreground hover:bg-sidebar-accent"
                  onClick={logout}
                  title="Sair"
                >
                  <LogOut className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 lg:hidden">
        <div className="flex items-center justify-around py-2">
          {[
            { name: "Home", href: "/dashboard", icon: LayoutDashboard },
            { name: "Agenda", href: "/dashboard/agenda", icon: Calendar },
            { name: "Clientes", href: "/dashboard/clientes", icon: Users },
            { name: "Caixa", href: "/dashboard/caixa", icon: CreditCard },
            { name: "Menu", href: "/dashboard/configuracoes", icon: Settings },
          ].map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "flex flex-col items-center gap-1 px-3 py-1",
                  isActive ? "text-primary" : "text-muted-foreground",
                )}
              >
                <item.icon className="h-5 w-5" />
                <span className="text-xs">{item.name}</span>
              </Link>
            )
          })}
        </div>
      </nav>
    </>
  )
}
