"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command"
import { Calendar, Users, CreditCard, FileText, Package, BarChart3, Settings, Plus } from "lucide-react"

export function CommandMenu() {
  const [open, setOpen] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault()
        setOpen((open) => !open)
      }
    }

    document.addEventListener("keydown", down)
    return () => document.removeEventListener("keydown", down)
  }, [])

  const runCommand = (command: () => void) => {
    setOpen(false)
    command()
  }

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="Digite um comando ou busque..." />
      <CommandList>
        <CommandEmpty>Nenhum resultado encontrado.</CommandEmpty>
        <CommandGroup heading="Ações Rápidas">
          <CommandItem onSelect={() => runCommand(() => router.push("/dashboard/agenda/novo"))}>
            <Plus className="mr-2 h-4 w-4" />
            Novo Agendamento
          </CommandItem>
          <CommandItem onSelect={() => runCommand(() => router.push("/dashboard/clientes/novo"))}>
            <Plus className="mr-2 h-4 w-4" />
            Novo Cliente
          </CommandItem>
          <CommandItem onSelect={() => runCommand(() => router.push("/dashboard/caixa/venda"))}>
            <Plus className="mr-2 h-4 w-4" />
            Nova Venda
          </CommandItem>
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Navegação">
          <CommandItem onSelect={() => runCommand(() => router.push("/dashboard"))}>
            <BarChart3 className="mr-2 h-4 w-4" />
            Dashboard
          </CommandItem>
          <CommandItem onSelect={() => runCommand(() => router.push("/dashboard/agenda"))}>
            <Calendar className="mr-2 h-4 w-4" />
            Agenda
          </CommandItem>
          <CommandItem onSelect={() => runCommand(() => router.push("/dashboard/clientes"))}>
            <Users className="mr-2 h-4 w-4" />
            Clientes
          </CommandItem>
          <CommandItem onSelect={() => runCommand(() => router.push("/dashboard/caixa"))}>
            <CreditCard className="mr-2 h-4 w-4" />
            Caixa & PDV
          </CommandItem>
          <CommandItem onSelect={() => runCommand(() => router.push("/dashboard/prontuarios"))}>
            <FileText className="mr-2 h-4 w-4" />
            Prontuários
          </CommandItem>
          <CommandItem onSelect={() => runCommand(() => router.push("/dashboard/estoque"))}>
            <Package className="mr-2 h-4 w-4" />
            Estoque
          </CommandItem>
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Configurações">
          <CommandItem onSelect={() => runCommand(() => router.push("/dashboard/configuracoes"))}>
            <Settings className="mr-2 h-4 w-4" />
            Configurações
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  )
}
