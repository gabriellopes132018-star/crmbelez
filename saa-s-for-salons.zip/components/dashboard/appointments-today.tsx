"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MoreHorizontal, CheckCircle2, XCircle, Clock3 } from "lucide-react"

const appointments = [
  {
    id: 1,
    time: "09:00",
    duration: "1h",
    client: "Maria Silva",
    service: "Limpeza de Pele",
    professional: "Dra. Ana",
    status: "confirmed",
    avatar: "MS",
  },
  {
    id: 2,
    time: "10:30",
    duration: "1h30",
    client: "Ana Costa",
    service: "Massagem Relaxante",
    professional: "Carla",
    status: "confirmed",
    avatar: "AC",
  },
  {
    id: 3,
    time: "12:00",
    duration: "45min",
    client: "Julia Santos",
    service: "Design de Sobrancelhas",
    professional: "Paula",
    status: "pending",
    avatar: "JS",
  },
  {
    id: 4,
    time: "14:00",
    duration: "2h",
    client: "Fernanda Oliveira",
    service: "Pacote Noiva",
    professional: "Dra. Ana",
    status: "confirmed",
    avatar: "FO",
  },
  {
    id: 5,
    time: "16:30",
    duration: "1h",
    client: "Patrícia Lima",
    service: "Peeling Químico",
    professional: "Dra. Ana",
    status: "pending",
    avatar: "PL",
  },
  {
    id: 6,
    time: "18:00",
    duration: "1h30",
    client: "Camila Rocha",
    service: "Tratamento Facial",
    professional: "Carla",
    status: "cancelled",
    avatar: "CR",
  },
]

const statusConfig = {
  confirmed: { label: "Confirmado", color: "bg-green-500/10 text-green-500", icon: CheckCircle2 },
  pending: { label: "Pendente", color: "bg-yellow-500/10 text-yellow-500", icon: Clock3 },
  cancelled: { label: "Cancelado", color: "bg-red-500/10 text-red-500", icon: XCircle },
}

export function AppointmentsToday() {
  return (
    <Card className="bg-card border-border/50">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold">Agendamentos de Hoje</CardTitle>
        <div className="flex items-center gap-2">
          <Badge variant="outline">{appointments.length} total</Badge>
          <Button variant="ghost" size="sm">
            Ver todos
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[320px] pr-4">
          <div className="space-y-3">
            {appointments.map((apt) => {
              const status = statusConfig[apt.status as keyof typeof statusConfig]
              const StatusIcon = status.icon
              return (
                <div
                  key={apt.id}
                  className="flex items-center gap-4 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
                >
                  <div className="text-center min-w-[60px]">
                    <div className="text-lg font-bold text-primary">{apt.time}</div>
                    <div className="text-xs text-muted-foreground">{apt.duration}</div>
                  </div>

                  <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-medium text-primary">{apt.avatar}</span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium truncate">{apt.client}</span>
                      <Badge variant="outline" className={status.color}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {status.label}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground truncate">
                      {apt.service} • {apt.professional}
                    </div>
                  </div>

                  <Button variant="ghost" size="icon" className="flex-shrink-0">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              )
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
