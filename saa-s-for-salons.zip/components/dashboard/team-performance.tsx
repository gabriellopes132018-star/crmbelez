import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

const team = [
  {
    id: 1,
    name: "Dra. Ana Paula",
    role: "Dermatologista",
    appointments: 45,
    target: 50,
    revenue: "R$ 18.500",
    avatar: "AP",
  },
  {
    id: 2,
    name: "Carla Mendes",
    role: "Esteticista",
    appointments: 38,
    target: 40,
    revenue: "R$ 12.200",
    avatar: "CM",
  },
  {
    id: 3,
    name: "Paula Silva",
    role: "Designer Sobrancelhas",
    appointments: 52,
    target: 45,
    revenue: "R$ 8.900",
    avatar: "PS",
  },
  {
    id: 4,
    name: "Juliana Costa",
    role: "Massagista",
    appointments: 28,
    target: 35,
    revenue: "R$ 6.290",
    avatar: "JC",
  },
]

export function TeamPerformance() {
  return (
    <Card className="bg-card border-border/50">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold">Performance da Equipe</CardTitle>
        <Badge variant="outline">Este mês</Badge>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {team.map((member) => {
            const progress = (member.appointments / member.target) * 100
            const isOverTarget = progress >= 100
            return (
              <div key={member.id} className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-medium text-primary">{member.avatar}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">{member.name}</span>
                      <span className="text-sm font-medium text-primary">{member.revenue}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{member.role}</span>
                      <span>
                        {member.appointments}/{member.target} agendamentos
                      </span>
                    </div>
                  </div>
                </div>
                <Progress value={Math.min(progress, 100)} className="h-2" />
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
