"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, Camera, ChevronLeft, ChevronRight, ZoomIn, Calendar } from "lucide-react"
import { cn } from "@/lib/utils"

interface ClientPhotosProps {
  clientId: string
}

const photoSets = [
  {
    id: 1,
    date: "29/11/2025",
    treatment: "Limpeza de Pele",
    before: "/face-before-treatment.jpg",
    after: "/face-after-treatment-clean-skin.jpg",
  },
  {
    id: 2,
    date: "15/11/2025",
    treatment: "Peeling Químico",
    before: "/face-with-acne-before.jpg",
    after: "/face-clear-skin-after-peeling.jpg",
  },
  {
    id: 3,
    date: "01/11/2025",
    treatment: "Tratamento Anti-idade",
    before: "/face-with-wrinkles-before.jpg",
    after: "/face-smoother-skin-after-treatment.jpg",
  },
]

export function ClientPhotos({ clientId }: ClientPhotosProps) {
  const [selectedSet, setSelectedSet] = useState(photoSets[0])
  const [sliderPosition, setSliderPosition] = useState(50)

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      {/* Main Comparison */}
      <div className="lg:col-span-2">
        <Card className="border-border/50">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg">Comparativo Antes/Depois</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                {selectedSet.treatment} - {selectedSet.date}
              </p>
            </div>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Camera className="h-4 w-4 mr-2" />
              Nova Foto
            </Button>
          </CardHeader>
          <CardContent>
            {/* Slider Comparison */}
            <div className="relative aspect-square rounded-xl overflow-hidden bg-secondary/30">
              {/* Before Image */}
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${selectedSet.before})` }}
              />

              {/* After Image with clip */}
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{
                  backgroundImage: `url(${selectedSet.after})`,
                  clipPath: `inset(0 0 0 ${sliderPosition}%)`,
                }}
              />

              {/* Slider control */}
              <div
                className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize"
                style={{ left: `${sliderPosition}%` }}
              >
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white shadow-lg flex items-center justify-center">
                  <ChevronLeft className="h-4 w-4 text-black -mr-1" />
                  <ChevronRight className="h-4 w-4 text-black -ml-1" />
                </div>
              </div>

              {/* Labels */}
              <div className="absolute top-4 left-4">
                <Badge className="bg-black/50 text-white border-0">Antes</Badge>
              </div>
              <div className="absolute top-4 right-4">
                <Badge className="bg-black/50 text-white border-0">Depois</Badge>
              </div>

              {/* Slider input */}
              <input
                type="range"
                min="0"
                max="100"
                value={sliderPosition}
                onChange={(e) => setSliderPosition(Number(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize"
              />
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-4 mt-4">
              <Button variant="outline" size="sm">
                <ZoomIn className="h-4 w-4 mr-2" />
                Ampliar
              </Button>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span>Arraste para comparar</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Photo Sets List */}
      <div>
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="text-lg">Sessões de Fotos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {photoSets.map((set) => (
              <div
                key={set.id}
                className={cn(
                  "p-3 rounded-xl cursor-pointer transition-colors",
                  selectedSet.id === set.id
                    ? "bg-primary/20 border border-primary/50"
                    : "bg-secondary/30 hover:bg-secondary/50",
                )}
                onClick={() => setSelectedSet(set)}
              >
                <div className="flex items-center gap-3">
                  <div className="flex gap-1">
                    <div
                      className="h-12 w-12 rounded-lg bg-cover bg-center"
                      style={{ backgroundImage: `url(${set.before})` }}
                    />
                    <div
                      className="h-12 w-12 rounded-lg bg-cover bg-center"
                      style={{ backgroundImage: `url(${set.after})` }}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">{set.treatment}</div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      {set.date}
                    </div>
                  </div>
                </div>
              </div>
            ))}

            <Button variant="outline" className="w-full bg-transparent">
              <Plus className="h-4 w-4 mr-2" />
              Nova Sessão
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
