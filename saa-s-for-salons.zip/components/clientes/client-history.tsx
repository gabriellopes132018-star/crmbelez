import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, User, MoreHorizontal } from "lucide-react"

interface ClientHistoryProps {
  clientId: string
}

const history = [
  {
    id: 1,
    date: "29/11/2025",
    time: "09:00",
    service: "Limpeza de Pele Profunda",
    professional: "Dra. Ana Paula",
    duration: "1h",
    price: "R$ 180,00",
    status: "completed",
  },
  {
    id: 2,
    date: "15/11/2025",
    time: "14:00",
    service: "Massagem Relaxante",
    professional: "Carla Mendes",
    duration: "1h30",
    price: "R$ 220,00",
    status: "completed",
  },
  {
    id: 3,
    date: "01/11/2025",
    time: "10:00",
    service: "Peeling Químico",
    professional: "Dra. Ana Paula",
    duration: "1h",
    price: "R$ 250,00",
    status: "completed",
  },
  {
    id: 4,
    date: "18/10/2025",
    time: "09:30",
    service: "Tratamento Facial Completo",
    professional: "Dra. Ana Paula",
    duration: "2h",
    price: "R$ 380,00",
    status: "completed",
  },
  {
    id: 5,
    date: "05/10/2025",
    time: "15:00",
    service: "Design de Sobrancelhas",
    professional: "Paula Silva",
    duration: "45min",
    price: "R$ 80,00",
    status: "cancelled",
  },
]

export function ClientHistory({ clientId }: ClientHistoryProps) {
  return (
    <Card className="border-border/50">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg">Histórico de Atendimentos</CardTitle>
        <Badge variant="outline">{history.length} registros</Badge>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {history.map((item) => (
            <div
              key={item.id}
              className="flex items-center gap-4 p-4 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-colors"
            >
              <div className="text-center min-w-[80px]">
                <div className="text-sm font-medium">{item.date}</div>
                <div className="text-xs text-muted-foreground">{item.time}</div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium">{item.service}</span>
                  <Badge
                    variant="outline"
                    className={
                      item.status === "completed"
                        ? "bg-green-500/10 text-green-500 border-green-500/50"
                        : "bg-red-500/10 text-red-500 border-red-500/50"
                    }
                  >
                    {item.status === "completed" ? "Concluído" : "Cancelado"}
                  </Badge>
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <User className="h-3 w-3" />
                    {item.professional}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {item.duration}
                  </span>
                </div>
              </div>

              <div className="text-right">
                <div className="font-medium text-primary">{item.price}</div>
              </div>

              <Button variant="ghost" size="icon">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
