"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Plus, FileText, AlertTriangle, Heart, Droplet, Edit, Save, PenLine } from "lucide-react"

interface ClientProntuarioProps {
  clientId: string
}

const prontuarioData = {
  skinType: "Mista",
  allergies: ["Parabenos", "Fragrâncias sintéticas"],
  conditions: ["Rosácea leve", "Poros dilatados zona T"],
  treatments: [
    { date: "29/11/2025", treatment: "Limpeza de pele", notes: "Extração suave, pele sensível" },
    { date: "15/11/2025", treatment: "Peeling enzimático", notes: "Boa resposta, sem irritação" },
    { date: "01/11/2025", treatment: "Hidratação profunda", notes: "Pele muito desidratada" },
  ],
  observations: "Cliente com histórico de sensibilidade. Evitar ácidos fortes. Prefere produtos naturais e veganos.",
  lastUpdate: "29/11/2025 às 10:30",
}

export function ClientProntuario({ clientId }: ClientProntuarioProps) {
  const [isEditing, setIsEditing] = useState(false)

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      {/* Main Info */}
      <div className="lg:col-span-2 space-y-6">
        <Card className="border-border/50">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Anamnese
            </CardTitle>
            <Button variant="outline" size="sm" onClick={() => setIsEditing(!isEditing)}>
              {isEditing ? (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Salvar
                </>
              ) : (
                <>
                  <Edit className="h-4 w-4 mr-2" />
                  Editar
                </>
              )}
            </Button>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Skin Type */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Droplet className="h-4 w-4 text-blue-500" />
                Tipo de Pele
              </Label>
              <div className="flex gap-2">
                {["Normal", "Seca", "Oleosa", "Mista", "Sensível"].map((type) => (
                  <Badge
                    key={type}
                    variant={type === prontuarioData.skinType ? "default" : "outline"}
                    className={
                      type === prontuarioData.skinType ? "bg-primary text-primary-foreground" : "cursor-pointer"
                    }
                  >
                    {type}
                  </Badge>
                ))}
              </div>
            </div>

            <Separator />

            {/* Allergies */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-red-500" />
                Alergias e Sensibilidades
              </Label>
              <div className="flex flex-wrap gap-2">
                {prontuarioData.allergies.map((allergy) => (
                  <Badge key={allergy} variant="outline" className="bg-red-500/10 text-red-400 border-red-500/50">
                    {allergy}
                  </Badge>
                ))}
                {isEditing && (
                  <Button variant="outline" size="sm" className="h-6 px-2 bg-transparent">
                    <Plus className="h-3 w-3 mr-1" />
                    Adicionar
                  </Button>
                )}
              </div>
            </div>

            <Separator />

            {/* Conditions */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Heart className="h-4 w-4 text-pink-500" />
                Condições da Pele
              </Label>
              <div className="flex flex-wrap gap-2">
                {prontuarioData.conditions.map((condition) => (
                  <Badge key={condition} variant="outline" className="bg-pink-500/10 text-pink-400 border-pink-500/50">
                    {condition}
                  </Badge>
                ))}
                {isEditing && (
                  <Button variant="outline" size="sm" className="h-6 px-2 bg-transparent">
                    <Plus className="h-3 w-3 mr-1" />
                    Adicionar
                  </Button>
                )}
              </div>
            </div>

            <Separator />

            {/* Observations */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <PenLine className="h-4 w-4 text-yellow-500" />
                Observações Gerais
              </Label>
              {isEditing ? (
                <Textarea defaultValue={prontuarioData.observations} rows={4} />
              ) : (
                <p className="text-sm text-muted-foreground bg-secondary/30 rounded-lg p-3">
                  {prontuarioData.observations}
                </p>
              )}
            </div>

            <div className="text-xs text-muted-foreground">Última atualização: {prontuarioData.lastUpdate}</div>
          </CardContent>
        </Card>

        {/* Treatment History */}
        <Card className="border-border/50">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Histórico de Tratamentos</CardTitle>
            <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Plus className="h-4 w-4 mr-2" />
              Novo Registro
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {prontuarioData.treatments.map((treatment, i) => (
                <div key={i} className="flex gap-4 p-4 rounded-xl bg-secondary/30">
                  <div className="text-sm font-medium text-primary min-w-[90px]">{treatment.date}</div>
                  <div className="flex-1">
                    <div className="font-medium">{treatment.treatment}</div>
                    <div className="text-sm text-muted-foreground mt-1">{treatment.notes}</div>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sidebar */}
      <div className="space-y-6">
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="text-lg">Assinatura Digital</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="aspect-[4/3] rounded-xl bg-secondary/30 border-2 border-dashed border-border flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <PenLine className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Clique para assinar</p>
              </div>
            </div>
            <Button variant="outline" className="w-full mt-4 bg-transparent">
              Solicitar Assinatura
            </Button>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="text-lg">Documentos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {["Termo de Consentimento", "Ficha de Anamnese", "Contrato de Pacote"].map((doc, i) => (
              <div
                key={i}
                className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 cursor-pointer transition-colors"
              >
                <FileText className="h-4 w-4 text-primary" />
                <span className="text-sm">{doc}</span>
              </div>
            ))}
            <Button variant="outline" className="w-full mt-2 bg-transparent">
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Documento
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
