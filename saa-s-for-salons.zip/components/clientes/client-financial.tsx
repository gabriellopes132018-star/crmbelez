import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { DollarSign, TrendingUp, CreditCard, Receipt, Download } from "lucide-react"

interface ClientFinancialProps {
  clientId: string
}

const transactions = [
  { id: 1, date: "29/11/2025", description: "Limpeza de Pele", amount: "R$ 180,00", method: "PIX", status: "paid" },
  {
    id: 2,
    date: "15/11/2025",
    description: "Massagem Relaxante",
    amount: "R$ 220,00",
    method: "Cartão Crédito",
    status: "paid",
  },
  { id: 3, date: "01/11/2025", description: "Peeling Químico", amount: "R$ 250,00", method: "PIX", status: "paid" },
  {
    id: 4,
    date: "18/10/2025",
    description: "Tratamento Facial",
    amount: "R$ 380,00",
    method: "Cartão Débito",
    status: "paid",
  },
  { id: 5, date: "05/12/2025", description: "Pacote Mensal", amount: "R$ 450,00", method: "Boleto", status: "pending" },
]

export function ClientFinancial({ clientId }: ClientFinancialProps) {
  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Gasto", value: "R$ 4.850,00", icon: DollarSign, change: "+23%" },
          { label: "Ticket Médio", value: "R$ 202,08", icon: TrendingUp, change: "+5%" },
          { label: "Em Aberto", value: "R$ 450,00", icon: Receipt, change: null },
          { label: "Pontos", value: "1.250", icon: CreditCard, change: "+125" },
        ].map((stat, i) => (
          <Card key={i} className="border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <stat.icon className="h-5 w-5 text-primary" />
                {stat.change && <span className="text-xs text-green-500">{stat.change}</span>}
              </div>
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="text-xs text-muted-foreground">{stat.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Transactions */}
      <Card className="border-border/50">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg">Transações</CardTitle>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {transactions.map((tx) => (
              <div key={tx.id} className="flex items-center gap-4 p-4 rounded-xl bg-secondary/30">
                <div className="text-sm text-muted-foreground min-w-[90px]">{tx.date}</div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium">{tx.description}</div>
                  <div className="text-sm text-muted-foreground">{tx.method}</div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-primary">{tx.amount}</div>
                  <Badge
                    variant="outline"
                    className={
                      tx.status === "paid"
                        ? "bg-green-500/10 text-green-500 border-green-500/50"
                        : "bg-yellow-500/10 text-yellow-500 border-yellow-500/50"
                    }
                  >
                    {tx.status === "paid" ? "Pago" : "Pendente"}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
