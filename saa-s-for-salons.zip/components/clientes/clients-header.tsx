"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { UserPlus, Download, Upload } from "lucide-react"

interface ClientsHeaderProps {
  onNewClient: () => void
}

export function ClientsHeader({ onNewClient }: ClientsHeaderProps) {
  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Clientes</h1>
        <p className="text-muted-foreground">Gerencie sua base de clientes e prontuários</p>
      </div>
      <div className="flex items-center gap-2">
        <Badge variant="outline" className="hidden sm:flex">
          1.248 clientes
        </Badge>
        <Button variant="outline" size="sm">
          <Download className="h-4 w-4 mr-2" />
          Exportar
        </Button>
        <Button variant="outline" size="sm">
          <Upload className="h-4 w-4 mr-2" />
          Importar
        </Button>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={onNewClient}>
          <UserPlus className="h-4 w-4 mr-2" />
          Novo Cliente
        </Button>
      </div>
    </div>
  )
}
