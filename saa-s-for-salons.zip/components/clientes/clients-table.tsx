"use client"

import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { MoreHorizontal, Eye, Edit, Calendar, FileText, Trash2, Phone, Mail } from "lucide-react"

interface ClientsTableProps {
  searchQuery: string
}

const clients = [
  {
    id: "1",
    name: "Maria Silva",
    email: "maria@email.com",
    phone: "(11) 99999-0001",
    avatar: "MS",
    visits: 24,
    lastVisit: "29/11/2025",
    totalSpent: "R$ 4.850,00",
    status: "active",
    tags: ["VIP", "Fidelidade"],
  },
  {
    id: "2",
    name: "Ana Costa",
    email: "ana@email.com",
    phone: "(11) 99999-0002",
    avatar: "AC",
    visits: 18,
    lastVisit: "28/11/2025",
    totalSpent: "R$ 3.200,00",
    status: "active",
    tags: ["Pacote Mensal"],
  },
  {
    id: "3",
    name: "Julia Santos",
    email: "julia@email.com",
    phone: "(11) 99999-0003",
    avatar: "JS",
    visits: 8,
    lastVisit: "25/11/2025",
    totalSpent: "R$ 1.450,00",
    status: "active",
    tags: [],
  },
  {
    id: "4",
    name: "Fernanda Oliveira",
    email: "fernanda@email.com",
    phone: "(11) 99999-0004",
    avatar: "FO",
    visits: 32,
    lastVisit: "20/11/2025",
    totalSpent: "R$ 8.900,00",
    status: "active",
    tags: ["VIP", "Aniversariante"],
  },
  {
    id: "5",
    name: "Patrícia Lima",
    email: "patricia@email.com",
    phone: "(11) 99999-0005",
    avatar: "PL",
    visits: 3,
    lastVisit: "15/10/2025",
    totalSpent: "R$ 450,00",
    status: "inactive",
    tags: ["Novo"],
  },
  {
    id: "6",
    name: "Camila Rocha",
    email: "camila@email.com",
    phone: "(11) 99999-0006",
    avatar: "CR",
    visits: 12,
    lastVisit: "27/11/2025",
    totalSpent: "R$ 2.100,00",
    status: "active",
    tags: [],
  },
]

export function ClientsTable({ searchQuery }: ClientsTableProps) {
  const filteredClients = clients.filter(
    (client) =>
      client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.phone.includes(searchQuery),
  )

  return (
    <Card className="border-border/50">
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="w-[300px]">Cliente</TableHead>
              <TableHead>Contato</TableHead>
              <TableHead className="text-center">Visitas</TableHead>
              <TableHead>Última Visita</TableHead>
              <TableHead className="text-right">Total Gasto</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredClients.map((client) => (
              <TableRow key={client.id} className="cursor-pointer hover:bg-secondary/30">
                <TableCell>
                  <Link href={`/dashboard/clientes/${client.id}`} className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary/20 text-primary font-medium">
                        {client.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{client.name}</div>
                      <div className="flex gap-1 mt-1">
                        {client.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs px-1.5 py-0">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </Link>
                </TableCell>
                <TableCell>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-3 w-3 text-muted-foreground" />
                      {client.email}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Phone className="h-3 w-3" />
                      {client.phone}
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-center">
                  <span className="font-medium">{client.visits}</span>
                </TableCell>
                <TableCell className="text-muted-foreground">{client.lastVisit}</TableCell>
                <TableCell className="text-right font-medium text-primary">{client.totalSpent}</TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={
                      client.status === "active"
                        ? "bg-green-500/10 text-green-500 border-green-500/50"
                        : "bg-muted text-muted-foreground"
                    }
                  >
                    {client.status === "active" ? "Ativo" : "Inativo"}
                  </Badge>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link href={`/dashboard/clientes/${client.id}`}>
                          <Eye className="mr-2 h-4 w-4" />
                          Ver perfil
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Edit className="mr-2 h-4 w-4" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Calendar className="mr-2 h-4 w-4" />
                        Agendar
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <FileText className="mr-2 h-4 w-4" />
                        Prontuário
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Excluir
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
