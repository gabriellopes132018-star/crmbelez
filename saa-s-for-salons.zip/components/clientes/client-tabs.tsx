"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ClientHistory } from "@/components/clientes/client-history"
import { ClientProntuario } from "@/components/clientes/client-prontuario"
import { ClientPhotos } from "@/components/clientes/client-photos"
import { ClientFinancial } from "@/components/clientes/client-financial"

interface ClientTabsProps {
  clientId: string
}

export function ClientTabs({ clientId }: ClientTabsProps) {
  return (
    <Tabs defaultValue="history" className="space-y-4">
      <TabsList className="bg-secondary/50 p-1">
        <TabsTrigger value="history">Histórico</TabsTrigger>
        <TabsTrigger value="prontuario">Prontuário</TabsTrigger>
        <TabsTrigger value="photos">Fotos</TabsTrigger>
        <TabsTrigger value="financial">Financeiro</TabsTrigger>
      </TabsList>
      <TabsContent value="history">
        <ClientHistory clientId={clientId} />
      </TabsContent>
      <TabsContent value="prontuario">
        <ClientProntuario clientId={clientId} />
      </TabsContent>
      <TabsContent value="photos">
        <ClientPhotos clientId={clientId} />
      </TabsContent>
      <TabsContent value="financial">
        <ClientFinancial clientId={clientId} />
      </TabsContent>
    </Tabs>
  )
}
