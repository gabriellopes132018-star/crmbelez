"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, Edit, Calendar, MessageSquare, Phone, Mail, MapPin, Cake, Star } from "lucide-react"

interface ClientProfileProps {
  clientId: string
}

const clientData = {
  id: "1",
  name: "Maria Silva",
  email: "maria.silva@email.com",
  phone: "(11) 99999-0001",
  whatsapp: "(11) 99999-0001",
  avatar: "MS",
  birthdate: "15/03/1990",
  address: "Rua das Flores, 123 - Jardins, São Paulo - SP",
  cpf: "123.456.789-00",
  tags: ["VIP", "Fidelidade"],
  visits: 24,
  totalSpent: "R$ 4.850,00",
  averageTicket: "R$ 202,08",
  lastVisit: "29/11/2025",
  memberSince: "Janeiro 2024",
  points: 1250,
  notes: "Cliente preferencial. Prefere horários pela manhã. Alérgica a parabenos.",
}

export function ClientProfile({ clientId }: ClientProfileProps) {
  return (
    <div className="space-y-6">
      {/* Back button */}
      <Button variant="ghost" size="sm" asChild>
        <Link href="/dashboard/clientes">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar para clientes
        </Link>
      </Button>

      {/* Profile Card */}
      <Card className="border-border/50">
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Avatar and main info */}
            <div className="flex flex-col sm:flex-row items-start gap-6">
              <Avatar className="h-24 w-24">
                <AvatarFallback className="bg-primary/20 text-primary text-2xl font-semibold">
                  {clientData.avatar}
                </AvatarFallback>
              </Avatar>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <h1 className="text-2xl font-bold">{clientData.name}</h1>
                  <div className="flex gap-1">
                    {clientData.tags.map((tag) => (
                      <Badge key={tag} className="bg-primary/20 text-primary border-0">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Mail className="h-4 w-4" />
                    {clientData.email}
                  </span>
                  <span className="flex items-center gap-1">
                    <Phone className="h-4 w-4" />
                    {clientData.phone}
                  </span>
                  <span className="flex items-center gap-1">
                    <Cake className="h-4 w-4" />
                    {clientData.birthdate}
                  </span>
                </div>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  {clientData.address}
                </div>
                <div className="flex items-center gap-2 pt-2">
                  <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
                    <Calendar className="h-4 w-4 mr-2" />
                    Agendar
                  </Button>
                  <Button size="sm" variant="outline">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    WhatsApp
                  </Button>
                  <Button size="sm" variant="outline">
                    <Edit className="h-4 w-4 mr-2" />
                    Editar
                  </Button>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="flex-1 grid grid-cols-2 sm:grid-cols-4 gap-4 lg:ml-auto">
              {[
                { label: "Visitas", value: clientData.visits },
                { label: "Total Gasto", value: clientData.totalSpent },
                { label: "Ticket Médio", value: clientData.averageTicket },
                { label: "Pontos", value: clientData.points, icon: Star },
              ].map((stat, i) => (
                <div key={i} className="text-center p-4 rounded-xl bg-secondary/30">
                  <div className="text-2xl font-bold text-primary flex items-center justify-center gap-1">
                    {stat.icon && <stat.icon className="h-5 w-5" />}
                    {stat.value}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Notes */}
          {clientData.notes && (
            <div className="mt-6 p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
              <div className="text-sm font-medium text-yellow-500 mb-1">Observações</div>
              <div className="text-sm text-yellow-200/80">{clientData.notes}</div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
